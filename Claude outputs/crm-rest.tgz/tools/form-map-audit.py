#!/usr/bin/env python3
"""
Audit — and draft — the provider form maps from the highlighted source PDFs.

The provider marks the fields we are expected to fill in yellow. Those marks
are real PDF Highlight annotations, so their positions can be read exactly
rather than estimated from a screenshot.

Two modes:

  (default)   Report highlights that no field is placed inside — data we
              silently never print — and fields whose anchor sits outside every
              highlight.

  --suggest   Additionally guess a field name for each highlight, from the
              label text inside or beside it and the section it falls under,
              and print pasteable JSON.

On the guesses: treat them as a starting point, not an answer. A missing field
leaves an obvious blank on the form; a *wrong* field prints the customer's name
in the contact-person box and looks perfectly fine until the provider rejects
the application. Confirm every suggestion against the calibration sheet
(wp-admin → Energy CRM → Έντυπα παρόχων) before trusting it.

Usage:
    pip install pymupdf
    python tools/form-map-audit.py --sources tools/source-forms
    python tools/form-map-audit.py --sources tools/source-forms --only protergia_he --suggest

Source PDFs are not committed: they are provider documents, they are large, and
they are reissued periodically. Name each file so it contains the template key
(protergia_he.pdf, orizon_activation.pdf, …).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    sys.exit("Χρειάζεται το PyMuPDF:  pip install pymupdf")

MM = 25.4 / 72

# Text is drawn at y + 3mm (ECRM_FormFill::BASELINE) and box fields are written
# below their label, so an anchor may legitimately sit outside its highlight.
X_SLACK = 2.0
Y_SLACK = 8.0

# ECRM_FormFill::BASELINE — the map stores the top of the value, the glyph is
# drawn this far below it. Keep the two in step or the collision check tests a
# position the renderer never uses.
BASELINE_MM = 2.5


def is_filler(token: str) -> bool:
    """Dotted leaders and rule characters: the space a value goes into."""
    return not re.search(r"[Α-Ωα-ωΆ-ώA-Za-z0-9]", token)

# Section headers, most specific first: "υπευθύνου επικοινωνίας" must be tested
# before "επικοινωνίας", or it is swallowed by it.
SECTIONS = [
    (r"στοιχειαυπευθυνουεπικοινωνιας|υπευθυνοςεπικοινωνιας", "contact"),
    (r"διευθυνσηαποστολης|αποστοληλογαριασμου", "billing"),
    (r"στοιχειανομιμουεκπροσωπου|νομιμοςεκπροσωπος", "rep"),
    (r"ταυτοτηταπαροχης|στοιχειαπαροχης|ταυτοτηταεγκαταστασης|εγκαταστασης", "supply"),
    (r"στοιχειαεταιρειας|στοιχειαεπιχειρησης", "company"),
    (r"στοιχειαπελατη|στοιχειααιτουντο", "customer"),
    (r"στοιχειαεπικοινωνιας", "customer"),
    (r"στοιχειαταυτοποιησης", "customer"),
]

# (label pattern, {section: field key}); "default" applies where the section
# does not change the meaning. Order matters: the first match wins, so a label
# carrying two names ("Επάγγελμα: … Τηλ. οικίας: …") resolves by its head.
RULES: list[tuple[str, dict[str, str]]] = [
    (r"^ονοματεπωνυμο", {"contact": "contact_onomateponymo", "rep": "nomimos_ekprosopos",
                         "default": "onomateponymo"}),
    (r"^επωνυμια", {"default": "eponymia"}),
    (r"^επωνυμο", {"default": "eponymo"}),
    (r"^ονομα$", {"default": "onoma"}),
    (r"πατρωνυμο|ονομαπατρος", {"default": "patronymo"}),
    (r"^αδτ|αρδιαβ|ταυτοτητας", {"contact": "contact_adt", "default": "adt"}),
    (r"^αφμ", {"contact": "contact_afm", "company": "afm_etaireias", "default": "afm"}),
    (r"^δου", {"default": "doy"}),
    (r"ημερομηνιαγεννησης", {"default": "birth_date"}),
    (r"^επαγγελμα|δραστηριοτητα", {"default": "epaggelma"}),
    (r"^κινητο", {"contact": "contact_kinito", "default": "kinito"}),
    (r"^τηλεφωνο|τηλοικιας|σταθερο", {"contact": "contact_tilefono", "default": "tilefono"}),
    (r"^email|ηλεκτρονικοταχυδρομειο", {"contact": "contact_email", "default": "email"}),
    (r"^διευθυνση|^οδος", {"supply": "odos_paroxis", "billing": "dieuthynsi", "default": "odos"}),
    (r"^αριθμος$|^αρ$", {"default": "arithmos"}),
    (r"^τκ|ταχκωδικ", {"supply": "tk_paroxis", "default": "tk"}),
    (r"^πολη|^περιοχη|^δημος", {"supply": "poli_paroxis", "default": "poli"}),
    (r"^νομος", {"default": "nomos"}),
    (r"αριθμοςπαροχης|αρπαροχης", {"default": "ar_paroxis"}),
    (r"ηκασπ|γεωπληροφοριακοστιγμα", {"default": "hkasp"}),
    (r"τελευταιαενδειξη|ενδειξημετρητη", {"default": "teleftaia_endeixi_imeras"}),
    (r"αριθμοςμετρητη|αρμετρητη", {"default": "ar_metriti"}),
    (r"τιμολογιο", {"default": "timologio"}),
    (r"προγραμμα", {"default": "programma"}),
    (r"διαρκεια", {"default": "diarkeia"}),
    (r"αριθμοςαιτησης|αραιτησης", {"default": "ar_aitisis"}),
    (r"^ημερομηνια$", {"default": "imerominia"}),
    (r"^τοπος", {"default": "topos"}),
    (r"ονμοσυνεργατη|ονοματεπωνυμοσυνεργατη", {"default": "synergatis"}),
    (r"ονμοπωλητη|πωλητη", {"default": "politis"}),
    (r"κωδσυνεργατη|κωδικοςσυνεργατη", {"default": "kod_synergati"}),
    (r"υφισταμενοςπρομηθευτης|προηγουμενοςπρομηθευτης|τρεχωνπρομηθευτης",
     {"default": "ipistamenos_promitheftis"}),
    (r"εγγυηση", {"default": "poso_eggiisis"}),
    (r"ισχυς", {"default": "isxis_paroxis"}),
    (r"^οικιακη", {"default": "cat_oikiaki"}),
    (r"^επαγγελματικη", {"default": "cat_epaggelmatiki"}),
    (r"^ιδιωτης", {"default": "cat_idiotis"}),
    (r"ατομικηεπιχειρηση", {"default": "cat_atomiki"}),
    (r"^εταιρεια$", {"default": "cat_etaireia"}),
    (r"αλλαγηπρομηθευτη", {"default": "act_change"}),
    (r"^διαδοχη", {"default": "act_succession"}),
    (r"επανασυνδεση", {"default": "act_reconnection"}),
    (r"^ανανεωση", {"default": "act_renewal"}),
    (r"νεαπαροχη|νεασυνδεση|ενεργοποιησησυνδεσης", {"default": "act_new"}),
]


def norm(text: str) -> str:
    stripped = unicodedata.normalize("NFD", text)
    stripped = "".join(c for c in stripped if unicodedata.category(c) != "Mn")
    return re.sub(r"[^α-ωa-z0-9]", "", stripped.lower())


def sections_on(page) -> list[tuple[float, str]]:
    lines: dict[float, list[tuple[float, str]]] = {}
    for w in page.get_text("words"):
        lines.setdefault(round(w[1] * MM, 1), []).append((w[0], w[4]))

    found = []
    for y in sorted(lines):
        text = norm(" ".join(t for _, t in sorted(lines[y])))
        for pattern, name in SECTIONS:
            if re.search(pattern, text):
                found.append((y, name))
                break
    return found


def label_for(words, box) -> str:
    x0, y0, x1, y1 = box

    # The highlight usually covers the label itself; read that first.
    inside = [w for w in words
              if x0 - 1 <= (w[0] + w[2]) / 2 * MM <= x1 + 1
              and y0 - 1 <= (w[1] + w[3]) / 2 * MM <= y1 + 1]
    if inside:
        inside.sort(key=lambda w: w[0])
        text = " ".join(w[4] for w in inside[:6])
        if norm(text):
            return text

    left = [w for w in words if w[2] * MM <= x0 + 1 and abs(w[1] * MM - y0) < 2.5]
    if left:
        left.sort(key=lambda w: w[2])
        return " ".join(w[4] for w in left[-5:])

    above = [w for w in words if 0 < y0 - w[3] * MM < 5 and x0 - 3 <= w[0] * MM <= x0 + 45]
    above.sort(key=lambda w: (-w[3], w[0]))
    return " ".join(w[4] for w in above[:5])


def guess_key(label: str, section: str) -> str | None:
    full = norm(label)
    # A dotted line often carries several labels; resolve by the leading one.
    head = norm(re.split(r"[.:]{2,}|\s{2,}", label.strip())[0])

    for pattern, table in RULES:
        if re.search(pattern, head) or re.search(pattern, full):
            return table.get(section) or table.get("default")
    return None


def marks(pdf: Path) -> list[dict]:
    out = []
    with fitz.open(pdf) as doc:
        for index, page in enumerate(doc, start=1):
            annots = [a.rect for a in (page.annots() or []) if a.type[1] == "Highlight"]
            if not annots:
                continue

            words = page.get_text("words")
            headers = sections_on(page)

            for r in annots:
                box = (r.x0 * MM, r.y0 * MM, r.x1 * MM, r.y1 * MM)
                label = label_for(words, box)

                # A highlighted section header is not a field.
                if any(re.search(p, norm(label)) for p, _ in SECTIONS):
                    continue

                section = "default"
                for hy, name in headers:
                    if hy <= box[1] + 1:
                        section = name

                out.append({
                    "page": index, "x": round(box[0], 1), "y": round(box[1], 1),
                    "w": round(box[2] - box[0], 1), "label": label.strip(),
                    "section": section, "key": guess_key(label, section),
                })
    return out


def covered(field: dict, page: int, x: float, y: float, x1: float, y1: float) -> bool:
    """
    Is this highlight already served by a mapped field?

    Not a containment test. Where the provider highlights only the label —
    "ΑΡΙΘΜΟΣ ΠΑΡΟΧΗΣ" — the value belongs to the *right* of the mark, so a field
    sitting outside the rectangle is correct rather than missing. What matters
    is the line: same page, same height, at or after the mark's left edge.

    This once had an exception letting a tick sit to the *left* of its mark. It
    was written to explain an Orizon checkbox that would not come out covered —
    and the checkbox was simply mapped to the wrong box. Loosening the check to
    accommodate a mistake would have hidden it, so the exception is gone.
    """
    return (int(field.get("page", 1)) == page
            and float(field["x"]) >= x - X_SLACK
            and y - Y_SLACK <= float(field["y"]) <= y1 + Y_SLACK)


def placements(entry) -> list[dict]:
    """
    A field is one placement, or a list of them.

    The same value legitimately prints in several boxes — an application code
    repeated on every page, an e-mail asked for twice on one. ECRM_FormFill
    accepts both shapes; so must the audit, or a mapped field reads as missing.
    """
    if isinstance(entry, list):
        return [p for p in entry if isinstance(p, dict)]
    return [entry] if isinstance(entry, dict) else []


def collisions(pdf, fields: dict) -> list[tuple[str, dict, str, float]]:
    """
    Anchors that land on top of the form's own printed text.

    A missing field leaves a blank box, which anyone notices. An anchor a few
    millimetres too far left prints the value *over* the label — "1256" across
    the words "ΤΕΛΕΥΤΑΙΑ ΕΝΔΕΙΞΗ" — and that looks like a rendering glitch
    rather than a mapping error, so it survives review. This is the check that
    catches it.

    Dotted filler is not a collision: those runs of full stops are exactly
    where a value is supposed to be written.

    @return (field name, placement, word sat on, x where that word ends)
    """
    doc = fitz.open(pdf)
    by_page = {n + 1: ink(doc[n]) for n in range(doc.page_count)}

    hits = []
    for name, entry in fields.items():
        for pos in placements(entry):
            page = int(pos.get("page", 1))
            x, y = float(pos["x"]), float(pos["y"]) + BASELINE_MM

            over = [c for c in by_page.get(page, [])
                    if c[0] - 0.3 <= x <= c[2] - 0.3
                    and c[1] - 1.0 <= y <= c[3] + 1.5]

            if over:
                hits.append((name, pos, over[0][4], max(c[2] for c in over)))

    return hits


def ink(page) -> list[tuple[float, float, float, float, str]]:
    """
    Real printed characters on a page, in mm, with the dotted leaders removed.

    Character level rather than word level on purpose. PyMuPDF hands back
    "οικίας:................................" as one word, and its box covers
    both the label and the blank it introduces. Testing against that box calls
    a correctly placed value a collision, and the false alarms bury the true
    ones. Each glyph carries its own box, so the label ends where it really
    ends.

    Neighbouring glyphs of the same run are stitched back together so the
    report names a word rather than a letter.
    """
    glyphs = []
    for block in page.get_text("rawdict")["blocks"]:
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                for ch in span.get("chars", []):
                    if is_filler(ch["c"]):
                        continue
                    x0, y0, x1, y1 = ch["bbox"]
                    glyphs.append([x0 * MM, y0 * MM, x1 * MM, y1 * MM, ch["c"]])

    glyphs.sort(key=lambda g: (round(g[1], 1), g[0]))

    merged: list[list] = []
    for g in glyphs:
        last = merged[-1] if merged else None
        if last and abs(last[1] - g[1]) < 0.4 and g[0] - last[2] < 0.6:
            last[2], last[3] = g[2], max(last[3], g[3])
            last[4] += g[4]
        else:
            merged.append(g)

    return [tuple(m) for m in merged]


def overlaps(fields: dict, gap: float = 2.0) -> list[tuple[str, str, int, float, float]]:
    """
    Two fill keys aimed at the same box.

    Whichever is drawn second lands on top of the first, so the form shows one
    value where the provider expects another — and it looks perfectly filled in.
    Neither the missing-highlight check nor the collision check sees it: the
    highlight *is* covered, and the anchor is on blank paper.

    Only the renaming made these findable by eye. `afm` and `kad` sitting two
    tenths of a millimetre apart says nothing; `afm_pelati` and `kad` says the
    ΑΦΜ and the Κ.Α.Δ. are being printed in the same box.
    """
    placed = []
    for name, entry in fields.items():
        for pos in placements(entry):
            placed.append((name, int(pos.get("page", 1)),
                           float(pos["x"]), float(pos["y"])))

    clashes = []
    for i, (name, page, x, y) in enumerate(placed):
        for other, page2, x2, y2 in placed[i + 1:]:
            if page == page2 and abs(x - x2) < gap and abs(y - y2) < gap:
                clashes.append((name, other, page, x, y))

    return clashes


def dirty_background(key: str, forms: Path, placed: list[dict]) -> list[str]:
    """
    Pages whose background image was made from a *completed* form.

    The templates are rendered as a picture of the blank form with our values
    drawn over it. When the only PDF a provider ever sent was a filled specimen,
    that picture carries somebody else's answers — and every application printed
    from it shows a stranger's name and prices under the real ones.

    There is no way to tell from the JPEG alone, so this leans on what the map
    already records: a source marked as filled, and fields placed on the pages
    that came from it. It cannot be fixed here either. It needs a blank PDF.
    """
    document = json.loads((forms / key.split("_")[0] / f"{key}.json").read_text(encoding="utf-8"))

    if not document.get("source_is_filled"):
        return []

    pages = sorted({int(p.get("page", 1)) for p in placed})

    return [f"{key}-{n}.jpg" for n in pages]


def audit(key: str, pdf: Path, forms: Path, suggest: bool) -> int:
    document = json.loads((forms / key.split("_")[0] / f"{key}.json").read_text(encoding="utf-8"))
    fields = document["fields"]
    found = marks(pdf)

    # A signature is a placement like any other as far as coverage goes; it
    # lives outside `fields` only because it draws an image rather than text.
    placed = [p for entry in fields.values() for p in placements(entry)]
    placed += placements(document.get("sig"))

    missing = [m for m in found
               if not any(covered(f, m["page"], m["x"], m["y"],
                                  m["x"] + m["w"], m["y"] + 3) for f in placed)]
    named = [m for m in missing if m["key"]]

    print(f"\n=== {key}")
    print(f"    σημάνσεις: {len(found)}   χαρτογραφημένα: {len(fields)}   "
          f"ακάλυπτες: {len(missing)}   με πρόταση ονόματος: {len(named)}")

    for m in sorted(missing, key=lambda m: (m["page"], m["y"], m["x"])):
        print(f"    σελ {m['page']}  x={m['x']:6.1f} y={m['y']:6.1f}  "
              f"[{m['section']:8}] {(m['key'] or '???'):26} « {m['label'][:40]} »")

    # Some providers only ever sent a completed specimen. There the check is
    # meaningless and inverted: an anchor that lands on the sample's own answer
    # is exactly right, and every correct field reports as a collision. The
    # flag lives in the map so the reason sits next to the form it concerns.
    over = [] if document.get("source_is_filled") else collisions(pdf, fields)

    if document.get("source_is_filled"):
        images = dirty_background(key, forms, placed)
        print("\n    ⚠ ΤΟ ΔΕΙΓΜΑ ΕΙΝΑΙ ΣΥΜΠΛΗΡΩΜΕΝΟ")
        print("      Ο έλεγχος σύγκρουσης δεν ισχύει, και — πιο σοβαρά — αν τα")
        print("      υπόβαθρα φτιάχτηκαν από αυτό, κάθε έντυπο τυπώνει από κάτω")
        print(f"      τα στοιχεία του δείγματος. Έλεγξε: {', '.join(images[:4])}"
              + (" …" if len(images) > 4 else ""))
        print("      Λύση: κενό PDF από τον πάροχο και αναδημιουργία υποβάθρων.")

    if over:
        print(f"\n    ΠΑΝΩ ΣΕ ΤΥΠΩΜΕΝΟ ΚΕΙΜΕΝΟ: {len(over)}")
        for name, pos, word, ends in sorted(over, key=lambda h: (h[1].get("page", 1), h[1]["y"])):
            print(f"    σελ {pos.get('page', 1)}  x={float(pos['x']):6.1f} y={float(pos['y']):6.1f}  "
                  f"{name:26} πάνω στο «{word[:26]}» (τελειώνει x={ends:.1f})")

    clashes = overlaps(fields)

    if clashes:
        print(f"\n    ΔΥΟ ΠΕΔΙΑ ΣΤΗΝ ΙΔΙΑ ΘΕΣΗ: {len(clashes)}")
        for a, b, page, x, y in sorted(clashes, key=lambda c: (c[2], c[4])):
            print(f"    σελ {page}  x={x:6.1f} y={y:6.1f}  {a}  ⟷  {b}")

    if suggest and named:
        print("\n    -- για επικόλληση στο JSON, μετά από έλεγχο --")
        for m in sorted(named, key=lambda m: (m["page"], m["y"])):
            print(f'    "{m["key"]}": {{ "page": {m["page"]}, '
                  f'"x": {m["x"] + 0.5:.1f}, "y": {m["y"]:.1f} }},')

    return len(missing) + len(over) + len(clashes)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources", required=True, type=Path)
    parser.add_argument("--forms", type=Path,
                        default=Path(__file__).resolve().parent.parent / "assets" / "forms")
    parser.add_argument("--only")
    parser.add_argument("--suggest", action="store_true")
    args = parser.parse_args()

    total = 0
    # (284) Ενας φάκελος ανά πάροχο: assets/forms/<πάροχος>/<key>.json
    for path in sorted(args.forms.glob("*/*.json")):
        key = path.stem
        if args.only and key != args.only:
            continue

        matches = [p for p in args.sources.glob("*.pdf") if key in p.stem]
        if not matches:
            print(f"\n=== {key}\n    (δεν βρέθηκε PDF με «{key}» στο όνομα)")
            continue

        total += audit(key, matches[0], args.forms, args.suggest)

    print(f"\nΣΥΝΟΛΟ ακάλυπτων σημάνσεων: {total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
