<?php

/**
 * Plugin bootstrap — the single composition root.
 *
 * Responsibilities are deliberately narrow: know the plugin's identity, wire
 * the WordPress lifecycle hooks, and delegate the actual work to the installer
 * and the module loaders. Business logic never lives here.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM;

use EnergyCRM\Access\DepartingUser;
use EnergyCRM\Access\DisabledAccounts;
use EnergyCRM\Access\LoginThrottle;
use EnergyCRM\Access\NetworkSync;
use EnergyCRM\Access\Roles;
use EnergyCRM\Admin\FormCalibrator;
use EnergyCRM\Admin\HealthPage;
use EnergyCRM\Admin\MonitoringPage;
use EnergyCRM\Admin\PrivacyTools;
use EnergyCRM\Http\ControllerFactory;
use EnergyCRM\Http\Router;
use EnergyCRM\SiteIntake\Admin\SiteIntakePage;
use EnergyCRM\Infrastructure\DocumentExposureCheck;
use EnergyCRM\Infrastructure\DocumentProtection;
use EnergyCRM\Infrastructure\DocumentsSweep;
use EnergyCRM\Infrastructure\ErrorLog;
use EnergyCRM\Infrastructure\HealthChecks;
use EnergyCRM\Infrastructure\KeyFingerprint;
use EnergyCRM\Infrastructure\MonitoringReport;
use EnergyCRM\Infrastructure\PiiBackfill;
use EnergyCRM\Infrastructure\Retention;
use EnergyCRM\Infrastructure\SmtpMailer;
use EnergyCRM\Legacy\Loader as LegacyLoader;
use EnergyCRM\Persistence\CustomerFields;
use EnergyCRM\Persistence\MetricsRepository;
use EnergyCRM\Persistence\PersonalDataEraser;
use EnergyCRM\Persistence\PersonalDataExporter;
use EnergyCRM\Persistence\PiiBackfillRepository;

final class Plugin
{
    public const VERSION = '1.11.0';

    private static ?self $instance = null;

    /** Absolute path to the main plugin file. */
    private string $file;

    private function __construct(string $file)
    {
        $this->file = $file;
    }

    /** Boot once; repeated calls return the same instance. */
    public static function boot(string $file): self
    {
        if (self::$instance === null) {
            self::$instance = new self($file);
            self::$instance->registerHooks();
        }

        return self::$instance;
    }

    public static function instance(): ?self
    {
        return self::$instance;
    }

    public function file(): string
    {
        return $this->file;
    }

    public function dir(): string
    {
        return plugin_dir_path($this->file);
    }

    public function url(): string
    {
        return plugin_dir_url($this->file);
    }

    private function registerHooks(): void
    {
        register_activation_hook($this->file, [Installer::class, 'activate']);
        register_deactivation_hook($this->file, [Installer::class, 'deactivate']);

        add_action('plugins_loaded', [$this, 'onPluginsLoaded']);
    }

    /**
     * Runs on every request once WordPress and all plugins are available.
     *
     * Order matters: schema first, so every module can assume its tables exist,
     * then the modules themselves.
     */
    public function onPluginsLoaded(): void
    {
        Installer::maybeUpgrade();
        Roles::maybeSync();

        // Πρώτο απ' όλα: αν σκάσει κάτι παρακάτω, θέλουμε να έχει καταγραφεί.
        $errors = new ErrorLog();
        $errors->register();

        // Η αποστολή email: ο δρόμος αποστολής (ανενεργός μέχρι το
        // wp-config.php να ορίσει ECRM_SMTP_HOST) και -- πάντα -- η καταγραφή
        // των αποτυχιών, που ως τώρα ήταν σιωπηλές. Δες SmtpMailer.
        (new SmtpMailer($errors))->register();

        // Πριν από κάθε έλεγχο κωδικού: μια σειρά αποτυχιών σταματάει να
        // δέχεται προσπάθειες, αντί να τις πληρώνει ο server μία-μία.
        (new LoginThrottle())->register();

        // Πριν από οτιδήποτε αγγίζει δικαιώματα: όσο ο λογαριασμός είναι
        // απενεργοποιημένος, κανένα ecrm_* δικαίωμα δεν ισχύει πουθενά.
        (new DisabledAccounts(Services::team()))->register();

        (new NetworkSync(Services::network()))->register();

        // Η διαγραφή χρήστη από το wp-admin παρακάμπτει το «Αφαίρεση» του CRM.
        // Η δουλειά του παραδίδεται πριν πάψει να υπάρχει.
        (new DepartingUser(
            Services::team(),
            Services::contracts(),
            Services::leads(),
            Services::tasks()
        ))->register();
        (new Retention(Services::contracts()))->register();
        (new DocumentProtection(Services::unprotectedDocuments()))->register();

        // Η ιδια δοκιμη που τρεχει η Υγεια κατ' αιτημα, τωρα και ημερησια απο
        // μονη της -- ωστε ενα ξεχασμενο nginx να μην περιμενει καποιον να ανοιξει
        // τη σελιδα για να το μαθει.
        (new DocumentExposureCheck())->register();

        // Η ανάγνωση εγγράφων (242) για παλιές αιτήσεις που κανείς δεν
        // ξανανοίγει -- δες το docblock της DocumentsSweep.
        (new DocumentsSweep(Services::files(), Services::documentKindReview()))->register();

        // Record which key this site's data belongs to, once. Only while
        // encryption is on: stamping a site that has never encrypted anything
        // would name a key that nothing was written under, and the first real
        // rotation afterwards would be reported against a fiction.
        if (CustomerFields::isEnabled()) {
            KeyFingerprint::default()->remember();
        }

        // Scheduled unconditionally, and inert until ECRM_ENCRYPT_PII is on.
        // Registering only when the flag is set would mean the sweep never
        // starts on the site that turns encryption on later — which is every
        // site, since the flag is opt-in.
        (new PiiBackfill(PiiBackfillRepository::default()))->register();

        (new Router(...ControllerFactory::all()))->register();

        // Το καμπανάκι για τις καταστάσεις που ζητούν ενέργεια. Συνδέεται στον
        // κύκλο ζωής, ώστε αυτός να μη χρειάζεται να ξέρει ότι υπάρχουν
        // ειδοποιήσεις.
        Services::contractNotices()->register();

        // Απόρριψη από πάροχο -> αυτόματη εργασία παρακολούθησης. Ίδιο σημείο
        // σύνδεσης με τα δύο παραπάνω, για τον ίδιο λόγο -- ο κύκλος ζωής δεν
        // πρέπει να ξέρει ότι υπάρχουν εργασίες.
        Services::rejectionFollowUp()->register();

        // Επίπεδο ΣΤ (docs/OFFLINE-MODEL.md §2ΣΤ): ο ζωντανός έλεγχος
        // διπλοεγγραφής (/customers/check) μπορεί να μην τρέξει ποτέ πριν
        // την αποθήκευση -- δίχτυ ασφαλείας σε ΚΑΘΕ δημιουργία, ίδιο σημείο
        // σύνδεσης, ίδιος λόγος.
        Services::duplicateFollowUp()->register();

        // The PDF builder listens for its own scheduled events; without this
        // the queue fills and nothing ever drains it.
        Services::documents()->register();

        if (is_admin()) {
            (new FormCalibrator())->register();

            // Tools → Export/Erase Personal Data. Admin-only, and admin-ajax
            // counts as admin, which is where WordPress actually runs them.
            (new HealthPage(new HealthChecks(), new ErrorLog()))->register();

            // Αδελφή σελίδα της Υγείας: εκείνη λέει «τι δεν πάει καλά τώρα»,
            // αυτή «σε σχέση με πριν». Ίδιο δικαίωμα, ίδιο κέλυφος.
            (new MonitoringPage(new MonitoringReport(
                new MetricsRepository(),
                Services::analytics(),
                Services::scopeResolver()
            )))->register();

            // Η σύνδεση με το site σύγκρισης τιμών (310): χρήστης, μυστικό, διεύθυνση.
            (new SiteIntakePage(Services::siteIntakeConfig()))->register();

            (new PrivacyTools(
                new PersonalDataExporter(),
                new PersonalDataEraser(Services::files())
            ))->register();
        }

        LegacyLoader::boot();
    }
}
