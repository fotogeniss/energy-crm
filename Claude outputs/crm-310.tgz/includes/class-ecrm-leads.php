<?php
/**
 * Leads / pre-contract funnel.
 *
 * A lightweight pipeline that sits before a contract: capture an interested
 * prospect, schedule callbacks, move them through stages, and convert a won
 * lead into a draft contract (prefilled with the contact details).
 *
 * @package EnergyCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ECRM_Leads {

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	public static function routes(): void {
		// Οι διαδρομές /leads ζουν στο EnergyCRM\Http\LeadsController.
		// Εδώ μένουν τα λεξιλόγια stages() και sources().
	}

	public static function stages(): array {
		return [
			'new'       => 'Νέο',
			'contacted' => 'Επικοινωνία',
			'callback'  => 'Επανάκληση',
			'qualified' => 'Έτοιμο',
			'won'       => 'Κερδισμένο',
			'lost'      => 'Χαμένο',
		];
	}

	public static function sources(): array {
		// Το 'link' γράφεται ΜΟΝΟ από το ECRM_Intake, δηλαδή από τον ίδιο τον
		// πελάτη μέσα από τον δημόσιο σύνδεσμο του πωλητή. Ξεχωρίζει από το
		// 'chatbot' επίτηδες: εδώ ξέρεις ποιος πωλητής τον έφερε.
		// Το 'site' γράφεται ΜΟΝΟ από το SiteIntakeController (310): αίτηση από
		// το site σύγκρισης τιμών, με υπογραφή του server του site.
		return [ 'phone' => 'Τηλέφωνο', 'link' => 'Από τον σύνδεσμό μου', 'site' => 'Από το site', 'chatbot' => 'Chatbot', 'referral' => 'Σύσταση', 'walk_in' => 'Επίσκεψη', 'social' => 'Social', 'other' => 'Άλλο' ];
	}
}
