<?php
/**
 * Front-end markup.
 *
 *   [energy_crm_new_contract] — standalone New Contract form
 *   form_inner_html()         — shared partial reused by the app shell
 *
 * Behaviour lives in ecrm-form.js (exposes window.ECRMForm.init).
 *
 * @package EnergyCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ECRM_Shortcodes {

	/**
	 * Every front-end module, as `import specifier => file`.
	 *
	 * The specifiers are bare on purpose. A relative import — './ecrm-util.js'
	 * — is a URL the browser caches on its own terms, and WordPress has no way
	 * to put a version on it: only the entry point got ?ver, so an edited
	 * helper stayed stale until somebody thought to hard-reload. That cost two
	 * rounds of a verification that looked like it had passed. A bare specifier
	 * is resolved through the import map instead, and the map carries a version
	 * for *every* file in the graph.
	 *
	 * @var array<string, string>
	 */
	private const MODULES = [
		'@energy-crm/util'             => 'ecrm-util.js',
		'@energy-crm/ai-docs'          => 'ecrm-ai-docs.js',
		'@energy-crm/format'           => 'ecrm-format.js',
		'@energy-crm/scope'            => 'ecrm-scope.js',
		'@energy-crm/view-commissions' => 'ecrm-view-commissions.js',
		'@energy-crm/view-analytics'   => 'ecrm-view-analytics.js',
		'@energy-crm/export-modal'     => 'ecrm-export-modal.js',
		'@energy-crm/dialog'           => 'ecrm-dialog.js',
		'@energy-crm/view-detail'      => 'ecrm-view-detail.js',
		'@energy-crm/view-contracts'   => 'ecrm-view-contracts.js',
		'@energy-crm/view-pending'     => 'ecrm-view-pending.js',
		'@energy-crm/navigate'         => 'ecrm-navigate.js',
		'@energy-crm/view-leads'       => 'ecrm-view-leads.js',
		'@energy-crm/view-renewals'    => 'ecrm-view-renewals.js',
		'@energy-crm/view-tasks'       => 'ecrm-view-tasks.js',
		'@energy-crm/view-calc'        => 'ecrm-view-calc.js',
		'@energy-crm/view-customers'   => 'ecrm-view-customers.js',
		'@energy-crm/view-customer-card' => 'ecrm-view-customer-card.js',
		'@energy-crm/view-dashboard'   => 'ecrm-view-dashboard.js',
		'@energy-crm/view-import'      => 'ecrm-view-import.js',
		'@energy-crm/view-kb'          => 'ecrm-view-kb.js',
		'@energy-crm/view-training'    => 'ecrm-view-training.js',
		'@energy-crm/view-network'     => 'ecrm-view-network.js',
		'@energy-crm/view-partner'     => 'ecrm-view-partner.js',
		'@energy-crm/view-team'        => 'ecrm-view-team.js',
		'@energy-crm/view-team-live'   => 'ecrm-view-team-live.js',
		'@energy-crm/view-escalations' => 'ecrm-view-escalations.js',
		// Ειχε ξεχαστει απο εδω στο (243) -- το ecrm-app.js το εισαγε, ο
		// browser δεν μπορουσε να λυσει το bare specifier χωρις καταχωρηση, και
		// πεταγε ΟΛΟΚΛΗΡΟ το ecrm-app.js: καθε οθονη εμενε στο «Φορτωση…».
		// Το φυλαει πλεον ο ModuleMapMatchesRealImportsTest.
		'@energy-crm/view-documents'   => 'ecrm-view-documents.js',
		'@energy-crm/form'             => 'ecrm-form.js',
		'@energy-crm/app'              => 'ecrm-app.js',
		'@energy-crm/litsa'            => 'ecrm-litsa.js',
		'@energy-crm/queue'            => 'ecrm-queue.js',
	];

	/** What each module imports, so the map carries the whole graph. */
	private const MODULE_DEPS = [
		'@energy-crm/util'             => [],
		'@energy-crm/ai-docs'          => [ '@energy-crm/util' ],
		'@energy-crm/format'           => [],
		'@energy-crm/scope'            => [],
		'@energy-crm/view-commissions' => [ '@energy-crm/util' ],
		'@energy-crm/view-analytics'   => [ '@energy-crm/util' ],
		'@energy-crm/export-modal'     => [ '@energy-crm/util' ],
		'@energy-crm/dialog'           => [ '@energy-crm/util' ],
		'@energy-crm/view-detail'      => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/dialog',
			'@energy-crm/ai-docs',
		],
		'@energy-crm/view-contracts'   => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/export-modal',
			'@energy-crm/dialog',
			'@energy-crm/scope',
		],
		'@energy-crm/view-pending'     => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/scope',
		],
		'@energy-crm/navigate'         => [],
		'@energy-crm/view-leads'       => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/dialog',
			'@energy-crm/ai-docs',
		],
		'@energy-crm/view-renewals'    => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-tasks'       => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-calc'        => [ '@energy-crm/util' ],
		'@energy-crm/view-customers'   => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-customer-card' => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/dialog',
		],
		'@energy-crm/view-dashboard'   => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-import'      => [ '@energy-crm/util' ],
		'@energy-crm/view-kb'          => [ '@energy-crm/util' ],
		'@energy-crm/view-training'    => [ '@energy-crm/util' ],
		'@energy-crm/view-network'     => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-partner'     => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-team'        => [ '@energy-crm/util', '@energy-crm/format', '@energy-crm/navigate' ],
		'@energy-crm/view-team-live'   => [ '@energy-crm/util', '@energy-crm/format' ],
		'@energy-crm/view-escalations' => [ '@energy-crm/util', '@energy-crm/navigate' ],
		'@energy-crm/view-documents'   => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/scope',
		],
		'@energy-crm/queue'            => [ '@energy-crm/util' ],
		'@energy-crm/form'             => [
			'@energy-crm/util',
			'@energy-crm/format',
			'@energy-crm/navigate',
			'@energy-crm/queue',
			'@energy-crm/ai-docs',
		],
		'@energy-crm/app'              => [
			'@energy-crm/util',
			'@energy-crm/navigate',
			'@energy-crm/queue',
			'@energy-crm/view-detail',
			'@energy-crm/view-contracts',
			'@energy-crm/view-pending',
			'@energy-crm/view-documents',
			'@energy-crm/view-commissions',
			'@energy-crm/view-analytics',
			'@energy-crm/view-leads',
			'@energy-crm/view-renewals',
			'@energy-crm/view-tasks',
			'@energy-crm/view-calc',
			'@energy-crm/view-customers',
			'@energy-crm/view-customer-card',
			'@energy-crm/view-dashboard',
			'@energy-crm/view-import',
			'@energy-crm/view-kb',
			'@energy-crm/view-training',
			'@energy-crm/view-network',
			'@energy-crm/view-team',
			'@energy-crm/view-partner',
			'@energy-crm/view-team-live',
			'@energy-crm/view-escalations',
		],
		'@energy-crm/litsa'            => [ '@energy-crm/util' ],
	];

	public static function init(): void {
		add_shortcode( 'energy_crm_new_contract', [ __CLASS__, 'new_contract' ] );
	}

	/**
	 * Register every module with a version taken from the file itself.
	 *
	 * filemtime() rather than ECRM_VERSION: the plugin version changes on a
	 * release, and a helper edited between releases would otherwise keep its
	 * old URL. The whole point of this exercise is that a changed file is a
	 * changed URL, without anyone having to remember anything.
	 *
	 * Idempotent — WordPress ignores a second registration of the same id, and
	 * both entry points call this.
	 */
	private static function register_modules(): void {
		foreach ( self::MODULES as $id => $file ) {
			wp_register_script_module(
				$id,
				ECRM_URL . 'public/assets/' . $file,
				self::MODULE_DEPS[ $id ] ?? [],
				self::asset_version( $file )
			);
		}
	}

	/**
	 * Η έκδοση ενός asset, από το ΙΔΙΟ το αρχείο.
	 *
	 * Ήταν ιδιωτική λογική μέσα στην register_modules() και κάλυπτε μόνο τα JS
	 * modules. Τα δύο CSS έβγαιναν με `ECRM_VERSION` — που αλλάζει σε release,
	 * όχι σε επεξεργασία αρχείου. Αποτέλεσμα: κάθε διόρθωση CSS έμενε αόρατη
	 * πίσω από την cache του browser μέχρι κάποιος να θυμηθεί hard-reload, και
	 * μια πραγματική διόρθωση έμοιαζε με «δεν δούλεψε». Το βρήκε ο ιδιοκτήτης
	 * στις 23/08: τρεις διαδοχικές διορθώσεις CSS για κινητό δεν φάνηκαν καμία.
	 *
	 * Το σκεπτικό της register_modules() ίσχυε ήδη λέξη προς λέξη — «ένα
	 * αλλαγμένο αρχείο είναι ένα αλλαγμένο URL, χωρίς να χρειάζεται να το
	 * θυμάται κανείς». Απλώς δεν είχε φτάσει ως το CSS.
	 */
	public static function asset_version( string $file ): string {
		$path = ECRM_DIR . 'public/assets/' . $file;

		return file_exists( $path ) ? (string) filemtime( $path ) : ECRM_VERSION;
	}

	/**
	 * The configuration object every module reads before it does anything.
	 *
	 * wp_localize_script() does not work with script modules — there is no
	 * module equivalent — so this is printed as a classic inline script. That
	 * is not a workaround so much as the guarantee: a classic script runs while
	 * the document is still parsing, and modules are deferred until after, so
	 * ECRM is always defined before any module body starts.
	 *
	 * @param array<string, mixed> $data
	 */
	private static function print_config( array $data ): void {
		// The app shell calls enqueue_form_assets() and the standalone form
		// shortcode does too; on a page with both, the hook would be added
		// twice and window.ECRM assigned twice.
		static $done = false;

		if ( $done ) {
			return;
		}

		$done = true;

		add_action(
			'wp_footer',
			static function () use ( $data ): void {
				wp_print_inline_script_tag(
					'window.ECRM = ' . wp_json_encode( $data ) . ';',
					[ 'id' => 'ecrm-config' ]
				);
			},
			1
		);
	}

	public static function enqueue_form_assets(): void {
		wp_enqueue_style( 'ecrm-form', ECRM_URL . 'public/assets/ecrm-form.css', [], self::asset_version( 'ecrm-form.css' ) );

		self::register_modules();
		wp_enqueue_script_module( '@energy-crm/form' );

		// Capabilities are sent so the UI can hide what the user cannot do.
		// This is presentation only — every one of them is enforced again on
		// the server, because anything reaching the browser is a suggestion.
		$caps = [];
		foreach ( \EnergyCRM\Access\Capability::all() as $capability ) {
			$caps[ $capability ] = current_user_can( $capability );
		}

		self::print_config( [
			'rest'     => esc_url_raw( rest_url( \EnergyCRM\Http\Router::NAMESPACE ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'statuses' => ECRM_DB::statuses(),
			'caps'     => $caps,
			// «Πάνω στο έντυπο» (30/08): χρειάζεται να χτίσει URLs για
			// assets/forms/{πάροχος}/{template}-{n}.jpg -- ήδη δημόσια στατικά αρχεία,
			// καμία νέα σελίδα/endpoint γι' αυτά.
			'formsUrl' => esc_url_raw( ECRM_URL . 'assets/forms/' ),
			// build queue #15 -- η «ειδική πύλη» διαγραφής υπογεγραμμένων
			// ελέγχεται ΚΑΙ πάλι στον server (permission_callback στο
			// ContractStatusController::routes()) -- αυτό είναι μόνο για να
			// αποφασίσει το UI αν θα προσφέρει τη δεύτερη πύλη μετά από 409.
			'isAdmin'  => current_user_can( 'manage_options' ),
			// Ποιανού είναι η ουρά εκτός σύνδεσης (260). Σε κοινόχρηστο tablet
			// call center, μια αίτηση που περιμένει στη συσκευή ΔΕΝ επιτρέπεται
			// να σταλεί όταν έχει συνδεθεί άλλος συνεργάτης: θα δημιουργούσε τη
			// σύμβαση στο δικό του όνομα, με τον πελάτη του πρώτου. Δεν είναι
			// μυστικό -- ο ίδιος αριθμός ταξιδεύει ήδη σε κάθε απάντηση του API
			// ως partner_user_id -- και δεν αντικαθιστά κανέναν έλεγχο: ο
			// server επιβάλλει το UserScope ξανά, όπως πάντα.
			'userId'   => get_current_user_id(),
		] );
	}

	public static function new_contract(): string {
		if ( ! is_user_logged_in() ) {
			return '<div class="ecrm-gate">Συνδέσου για να καταχωρίσεις νέα σύμβαση.</div>';
		}
		self::enqueue_form_assets();
		return '<div class="ecrm" data-standalone="1">' . self::form_inner_html() . '</div>';
	}

	/**
	 * The inner form markup (no outer .ecrm wrapper, no enqueue).
	 * Reused inside the app shell's "Νέα Σύμβαση" view.
	 */
	public static function form_inner_html(): string {
		// Οι ετικέτες είναι ΣΚΕΤΟ ΚΕΙΜΕΝΟ. Τα emoji που ήταν ψημένα εδώ μέσα
		// («🏠 Οικιακό») περνούσαν από esc_html() μαζί με τη λέξη, οπότε το
		// εικονίδιο δεν μπορούσε ποτέ να γίνει τίποτα άλλο από emoji — και το
		// ζωγράφιζε το λειτουργικό, με δικό του χρώμα και δικό του βάρος.
		//
		// Τώρα το εικονίδιο μπαίνει από το CSS πάνω στο data-val του chip, με
		// mask + currentColor: κληρονομεί το χρώμα του κειμένου, άρα γίνεται
		// πράσινο μόνο του όταν το chip είναι ενεργό. Δες ecrm-form.css.
		$cats = [ 'home' => 'Οικιακό', 'business' => 'Επαγγελματικό', 'communal' => 'Κοινόχρηστο' ];
		$pts  = [ 'fixed' => 'Σταθερό', 'special' => 'Ειδικό', 'variable' => 'Κυμαινόμενο', 'dynamic' => 'Δυναμικό' ];
		$ctyp = [ 'individual' => 'Ιδιώτης', 'sole_prop' => 'Ατομική Επιχείρηση', 'company' => 'Εταιρεία' ];
		$acts = ECRM_DB::activation_types();

		ob_start();
		?>
		<div class="ecrm-form" data-step="config" lang="el">
			<header class="ecrm-head">
				<div class="ecrm-eyebrow">Αίτηση</div>
				<h2 class="ecrm-title" data-form-title>Δημιουργία Αίτησης</h2>
				<p class="ecrm-sub">Διάλεξε πάροχο και πρόγραμμα, σύρε τα έγγραφα και η φόρμα συμπληρώνεται μόνη της.</p>
			</header>

			<!-- Ο wizard: τέσσερα βήματα, όπως οι B1-B4 του UX kit. Η μπάρα είναι
			     ΚΟΥΜΠΙΑ, όχι διακόσμηση: πίσω ελεύθερα, μπροστά όσο έχεις φτάσει. -->
			<div class="ecrm-layout">
			<div class="ecrm-wizmain">

			<nav class="ecrm-wsteps" data-wsteps aria-label="Βήματα αίτησης">
				<button type="button" class="ecrm-wstep__b is-on" data-wgo="1" aria-current="step"><strong>Βήμα 1</strong>Πάροχος &amp; τύπος</button>
				<button type="button" class="ecrm-wstep__b" data-wgo="2"><strong>Βήμα 2</strong>Έγγραφα &amp; AI</button>
				<button type="button" class="ecrm-wstep__b" data-wgo="3"><strong>Βήμα 3</strong>Στοιχεία &amp; πρόγραμμα</button>
				<button type="button" class="ecrm-wstep__b" data-wgo="4"><strong>Βήμα 4</strong>Έλεγχος &amp; υπογραφή</button>
			</nav>

			<?php
			// ΠΡΟΣΟΧΗ ΣΤΗ ΘΕΣΗ: οι δυο closures οριζονται ΠΡΙΝ απο το πρωτο
			// βημα, οχι πριν απο το τριτο. Ζουσαν ακριβως πριν το wstep=3
			// οσο ολα τα πεδια τους ηταν εκει· απο τις 05/09/2026 τις
			// χρησιμοποιει και η καρτα «2β Συνδυαστικη Προσφορα» στο
			// wstep=1, και μια closure δεν υπαρχει πριν την ορισει καποιος:
			// η σελιδα πεθαινε με fatal στη μεση της αποδοσης, και μαζι της
			// εχανε ΚΑΙ τα δυο stylesheets (το ecrm-app εξαρταται απο το
			// ecrm-form, και το footer δεν εφτανε ποτε να τυπωθει).
			?>
			<?php
			// Helper to print a field. $extra=true marks it for the extra_json bag.
			// $energy_when, when non-empty, adds data-when-energy so a field can be
			// scoped to power/gas or mobile without a wrapper element around it.
			// $ac is the autocomplete token: 'off' by default, since most of these
			// fields (ΑΦΜ, ΑΔΤ, αριθμός παροχής, μετρητή) have no browser-known
			// shape and a wrong guess is worse than none. Fields that DO map to a
			// standard token (name/address/phone/email) pass it explicitly below,
			// each scoped to its own section (section-cust/rep/contact/supply/
			// bill) so the browser doesn't offer the customer's mobile for the
			// legal representative's, or the shipping address for the billing one.
			// $when προστέθηκε 25/08 (αίτημα ιδιοκτήτη, αναδιάταξη Στοιχείων
			// Πελάτη): ίδιο νόημα με το data-when ενός ολόκληρου .ecrm-grid
			// wrapper, αλλά ΣΤΟ ΙΔΙΟ το πεδίο — ώστε ένα πεδίο μόνο για
			// φυσικά πρόσωπα (π.χ. ΑΔΤ) να μπορεί να μπει ΔΙΠΛΑ σε ένα κοινό
			// πεδίο (π.χ. ΑΦΜ) μέσα στο ίδιο .ecrm-grid, χωρίς να χρειαστεί
			// δύο ξεχωριστά grid. Το applyCustomerType() στο ecrm-form.js
			// ήδη διαβάζει ΚΑΘΕ [data-when] στη σελίδα (qa('[data-when]')),
			// όχι μόνο div wrappers — μηδέν αλλαγή JS χρειάστηκε.
			$ecrm_field = function ( $name, $label, $type = 'text', $extra = false, $ph = '', $energy_when = '', $ac = 'off', $when = '' ) {
				printf(
					'<label class="ecrm-field" data-for="%1$s"%6$s%8$s><span class="ecrm-field__label">%2$s</span><input type="%3$s" name="%1$s" class="ecrm-input"%4$s autocomplete="%7$s" placeholder="%5$s"></label>',
					esc_attr( $name ), esc_html( $label ), esc_attr( $type ),
					$extra ? ' data-extra="1"' : '', esc_attr( $ph ),
					$energy_when !== '' ? ' data-when-energy="' . esc_attr( $energy_when ) . '"' : '',
					esc_attr( $ac ),
					$when !== '' ? ' data-when="' . esc_attr( $when ) . '"' : ''
				);
			};

			// Yes/No select, used by the customer-facing questions in Στοιχεία
			// Τιμολόγησης. Defined here (not inline where it's used) because it
			// used to live inside the mobile section and moved out with the
			// fields it belongs to — see ORIZON-TODO.md #3.
			// (268): πήρε ένα τρίτο, προαιρετικό $energy_when -- ίδιο μοτίβο με
			// το $ecrm_field παραπάνω -- ώστε μια Ναι/Όχι ερώτηση να μπορεί να
			// δηλώσει ρητά ΠΟΙΟΥΣ τύπους ενέργειας αφορά, αντί να κληρονομεί
			// σιωπηλά την ορατότητα ενός γονικού div (βλ. CHANGELOG (268)).
			$ecrm_yesno = function ( $name, $label, $energy_when = '' ) {
				printf(
					'<label class="ecrm-field" data-for="%1$s"%3$s><span class="ecrm-field__label">%2$s</span>'
					. '<select name="%1$s" class="ecrm-input" data-extra="1">'
					. '<option value="">—</option><option value="yes">Ναι</option><option value="no">Όχι</option>'
					. '</select></label>',
					esc_attr( $name ),
					esc_html( $label ),
					$energy_when !== '' ? ' data-when-energy="' . esc_attr( $energy_when ) . '"' : ''
				);
			};
			?>

			<div class="ecrm-wstep" data-wstep="1">

			<section class="ecrm-card">
				<div class="ecrm-step"><span class="ecrm-step__n">1</span> Επιλογή Παρόχου <span class="ecrm-step__hint" data-selprov></span></div>
				<div class="ecrm-usual" data-usual hidden></div>
				<div class="ecrm-providers" data-providers><div class="ecrm-loading">Φόρτωση παρόχων…</div></div>
			</section>

			<section class="ecrm-card">
				<div class="ecrm-step"><span class="ecrm-step__n">2</span> Είδος &amp; κατηγορία πελάτη</div>

				<div class="ecrm-row">
					<span class="ecrm-row__label">Είδος</span>
					<div class="ecrm-chips" data-field="energy_type">
						<button type="button" class="ecrm-chip is-on" data-val="power">Ηλεκτρισμός</button>
						<button type="button" class="ecrm-chip" data-val="gas">Φυσικό Αέριο</button>
						<button type="button" class="ecrm-chip" data-val="mobile">Κινητή Τηλεφωνία</button>
					</div>
				</div>

				<?php
				// data-when-energy: σε ποια είδη παροχής ανήκει η επιλογή.
				// Χωρίς αυτό, ο συνεργάτης που διάλεγε κινητή έβλεπε «Γ1/Γ21»,
				// «Σταθερό/Κυμαινόμενο» και «Επανασύνδεση» — έννοιες ρεύματος
				// που δεν σημαίνουν τίποτα σε γραμμή κινητής.
				?>
				<div class="ecrm-row">
					<span class="ecrm-row__label">Κατηγορία</span>
					<div class="ecrm-chips" data-field="category">
						<?php $first = true; foreach ( $cats as $v => $l ) : ?>
							<button type="button" class="ecrm-chip <?php echo $first ? 'is-on' : ''; ?>" data-val="<?php echo esc_attr( $v ); ?>"<?php echo $v === 'communal' ? ' data-when-energy="power,gas"' : ''; ?>><?php echo esc_html( $l ); ?></button>
						<?php $first = false; endforeach; ?>
					</div>
				</div>

				<div class="ecrm-row" data-when-energy="power,gas">
					<span class="ecrm-row__label">Χρώμα</span>
					<div class="ecrm-chips" data-field="price_type">
						<?php $first = true; foreach ( $pts as $v => $l ) : ?>
							<button type="button" class="ecrm-chip <?php echo $first ? 'is-on' : ''; ?>" data-val="<?php echo esc_attr( $v ); ?>"><?php echo esc_html( $l ); ?></button>
						<?php $first = false; endforeach; ?>
					</div>
				</div>

				<?php
				// Τα Γ-τιμολόγια είναι κωδικοί ρεύματος -- εξ ου το
				// data-when-energy. Το data-when-category είναι δεύτερος
				// φραγμός, από 04/09/2026: το Γ1 είναι το ΟΙΚΙΑΚΟ τιμολόγιο και
				// τα Γ21/Γ22/Γ23 τα ΕΠΑΓΓΕΛΜΑΤΙΚΑ. Ώς τότε εμφανίζονταν και τα
				// τέσσερα πάντα, οπότε ο πωλητής σε οικιακή αίτηση μπορούσε να
				// διαλέξει Γ22 -- επιλογή που δεν αντιστοιχεί σε τίποτα.
				//
				// Το «Κοινόχρηστο» κρατά και τα τέσσερα ΕΠΙΤΗΔΕΣ: ο κοινόχρηστος
				// μετρητής πολυκατοικίας δεν είναι ούτε οικιακός ούτε
				// επαγγελματικός με τον ίδιο τρόπο, και δεν επιβεβαιώθηκε ποιο
				// ισχύει. Ανοιχτό ερώτημα προς τον ιδιοκτήτη -- να δείχνει
				// περισσότερα είναι ανεκτό, να κρύψει το σωστό δεν είναι.
				?>
				<div class="ecrm-row" data-when-energy="power">
					<span class="ecrm-row__label">Τιμολόγιο</span>
					<div class="ecrm-chips" data-field="invoice_code">
						<button type="button" class="ecrm-chip" data-val="Γ1" data-when-category="home,communal">Γ1</button>
						<button type="button" class="ecrm-chip" data-val="Γ21" data-when-category="business,communal">Γ21</button>
						<button type="button" class="ecrm-chip" data-val="Γ22" data-when-category="business,communal">Γ22</button>
						<button type="button" class="ecrm-chip" data-val="Γ23" data-when-category="business,communal">Γ23</button>
					</div>
				</div>

				<div class="ecrm-row">
					<span class="ecrm-row__label">Πρόγραμμα</span>
					<select class="ecrm-select" data-program data-field="program_id"><option value="">—</option></select>
				</div>

				<div class="ecrm-row">
					<span class="ecrm-row__label">Τύπος πελάτη</span>
					<div class="ecrm-chips" data-field="customer_type">
						<?php $first = true; foreach ( $ctyp as $v => $l ) : ?>
							<button type="button" class="ecrm-chip <?php echo $first ? 'is-on' : ''; ?>" data-val="<?php echo esc_attr( $v ); ?>"><?php echo esc_html( $l ); ?></button>
						<?php $first = false; endforeach; ?>
					</div>
				</div>

				<?php
				// Η διαδοχή, η επανασύνδεση και η αλλαγή παρόχου περιγράφουν
				// μετρητή. Το αντίστοιχο της αλλαγής παρόχου στην κινητή είναι
				// η φορητότητα, και έχει δικό της έντυπο.
				$act_energy = [
					'change_provider' => 'power,gas',
					'succession'      => 'power,gas',
					'reconnection'    => 'power,gas',
					'program_change'  => 'power,gas',
					'portability'     => 'mobile',
				];
				?>
				<div class="ecrm-row">
					<span class="ecrm-row__label">Ενεργοποίηση</span>
					<div class="ecrm-chips ecrm-chips--wrap" data-field="activation_type">
						<?php foreach ( $acts as $v => $l ) : ?>
							<button type="button" class="ecrm-chip" data-val="<?php echo esc_attr( $v ); ?>"<?php
								echo isset( $act_energy[ $v ] ) ? ' data-when-energy="' . esc_attr( $act_energy[ $v ] ) . '"' : '';
							?>><?php echo esc_html( strtoupper( $l ) ); ?></button>
						<?php endforeach; ?>
					</div>
				</div>
			</section>

			<?php
			// Ο ΚΑΘΡΕΦΤΗΣ της «2β» της Volton, για την αιτηση ORIZON -- ιδια
			// αποφαση, ιδια θεση (05/09/2026, docs/UI-COMBO-PLACEMENT.html,
			// εγκεκριμενη). Ζουσε ολοκληρη μεσα στο «6β Στοιχεια Κινητης» του
			// Βηματος 3. Η καρτα εκεινη κρατουσε ΤΕΣΣΕΡΑ διαφορετικα πραγματα
			// μαζι: μια αποφαση ΠΡΟΪΟΝΤΟΣ (ποια προσφορα), στοιχεια ΓΡΑΜΜΗΣ
			// (αριθμος, SIM, επιδοτηση), τα πεδια που ενεργοποιει η προσφορα,
			// και τις τιμες. Η ραφη περναει αναμεσα στο πρωτο-τριτο και στο
			// δευτερο-τεταρτο: η προσφορα ανεβαινει, η γραμμη μενει κατω.
			//
			// Εδω το επιχειρημα ειναι ισχυροτερο απο τη μερια της Volton: στο
			// Βημα 1-2 υπαρχει ΗΔΗ το ΠΡΟΓΡΑΜΜΑ, και η συνδυαστικη εκπτωση ειναι
			// τροποποιητης ακριβως αυτου του προγραμματος και της τιμης του.
			//
			// Τα ονοματα πεδιων ΔΕΝ αλλαζουν -- ιδιο extra_json, ιδιο values(),
			// ιδιο εντυπο. Αλλαζει μονο πού τα βλεπει ο συνεργατης.
			?>
			<section class="ecrm-card" data-when-energy="mobile" data-no-template-filter>
				<div class="ecrm-step"><span class="ecrm-step__n">2β</span> Συνδυαστική Προσφορά</div>
				<div class="ecrm-grid">
					<?php
					// Μία επιλογή και όχι δύο διακόπτες: οι δύο προσφορές δίνουν
					// την ίδια τιμή για διαφορετικό λόγο — η συνδυαστική δένει
					// κινητή με κινητή, το COMBO κινητή με ρεύμα — και δεν
					// συνδυάζονται. Δύο ανεξάρτητα κουτάκια θα επέτρεπαν να
					// τσεκαριστούν και τα δύο.
					?>
					<label class="ecrm-field" data-for="mobile_offer">
						<span class="ecrm-field__label">Συνδυαστική Έκπτωση</span>
						<select name="mobile_offer" class="ecrm-input" data-extra="1">
							<option value="">Καμία</option>
							<option value="family">Συνδυαστική Προσφορά (κινητή + κινητή)</option>
							<option value="combo">COMBO Έκπτωση Ρεύματος (κινητή + ρεύμα)</option>
						</select>
					</label>

				</div>

				<?php
				// Το COMBO είναι το μόνο σημείο όπου η κινητή αγγίζει το ρεύμα:
				// το έντυπό του ζητά την παροχή και το πρόγραμμα ενέργειας του
				// ίδιου πελάτη, και ποιος από τους δύο είναι ο κύριος χρήστης
				// της γραμμής (orizon_combo.json: xristis_kyrios/xristis_defterevon).
				// Εμφανίζεται μόνο όταν επιλεγεί, γιατί σε κάθε άλλη περίπτωση
				// είναι ακριβώς το είδος πεδίου που δεν έχει θέση σε αίτηση κινητής.
				?>
				<div class="ecrm-grid" data-when-offer="combo" hidden>
					<?php
					// Άρθρο 1 του εντύπου («Δικαιούχοι -- Έναρξη ισχύος»),
					// περιπτώσεις i/ii/iii: το combo δίνεται και σε πελάτη που
					// είναι ΗΔΗ σε έναν από τους δύο παρόχους. Δεν τυπώνεται
					// πουθενά -- το έντυπο δεν έχει κουτάκι, το λέει μόνο στους
					// όρους. Ζει εδώ γιατί η έκπτωση ξεκινά όταν ενεργοποιηθούν
					// ΚΑΙ ΟΙ ΔΥΟ υπηρεσίες, άρα το back office πρέπει να ξέρει
					// ποια από τις δύο λείπει ακόμα.
					?>
					<label class="ecrm-field" data-for="combo_energy_relation">
						<span class="ecrm-field__label">Τι έχει ήδη ο πελάτης</span>
						<select name="combo_energy_relation" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="has_power">Έχει ήδη ρεύμα Volton — νέα κινητή Orizon</option>
							<option value="has_mobile">Έχει ήδη κινητή Orizon — νέο ρεύμα Volton</option>
							<option value="both_new">Νέος και στα δύο — ταυτόχρονη σύναψη</option>
						</select>
					</label>
					<?php $ecrm_field( 'combo_supply_number', 'Αριθμός Παροχής / ΗΚΑΣΠ Ρεύματος', 'text', true ); ?>
					<?php
					// Ήταν ελεύθερο κείμενο ώς 04/09/2026: ο πωλητής έγραφε ό,τι
					// θυμόταν, με ό,τι ορθογραφία, και αυτό τυπωνόταν. Γίνεται
					// λίστα από τα πραγματικά προγράμματα Volton (CHANGELOG 217)
					// -- ΜΟΝΟ Volton, γιατί το combo είναι Volton+Orizon και το
					// έντυπο φέρει τα στοιχεία της Volton· πρόγραμμα άλλου
					// παρόχου δεν έχει θέση σε αυτό το χαρτί. Οι επιλογές
					// γεμίζουν από το JS, που έχει ήδη όλο τον κατάλογο.
					?>
					<label class="ecrm-field" data-for="combo_energy_program">
						<span class="ecrm-field__label">Πρόγραμμα Ρεύματος</span>
						<select name="combo_energy_program" class="ecrm-input" data-extra="1" data-volton-programs>
							<option value="">—</option>
						</select>
					</label>
					<label class="ecrm-field" data-for="combo_user_role">
						<span class="ecrm-field__label">Χρήστης Γραμμής</span>
						<select name="combo_user_role" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="main">Κύριος Χρήστης</option>
							<option value="secondary">Δευτερεύων Χρήστης</option>
						</select>
					</label>
				</div>

				<?php
				// Το έντυπο έχει ΔΥΟ μπλοκ ταυτότητας -- «ΣΤΟΙΧΕΙΑ ΠΕΛΑΤΗ
				// ΚΙΝΗΤΗΣ ΤΗΛΕΦΩΝΙΑΣ» και «ΣΤΟΙΧΕΙΑ ΠΕΛΑΤΗ ΕΝΕΡΓΕΙΑΣ» -- επειδή
				// το άρθρο 4 προβλέπει ρητά ότι μπορεί να είναι δύο διαφορετικά
				// πρόσωπα (η παροχή ρεύματος σε άλλο όνομα από τη γραμμή που
				// εκπροσωπείται). Ώς τώρα η φόρμα είχε ένα μόνο σετ στοιχείων,
				// οπότε το ΑΦΜ του δεύτερου προσώπου δεν είχε πού να μπει.
				//
				// Ίδιο μοτίβο με το «Ίδια με τη διεύθυνση του πελάτη» παραπάνω:
				// τσεκαρισμένο εξαρχής, τα πεδία μαζεμένα. Η συνηθισμένη
				// περίπτωση -- ένα πρόσωπο -- δεν πληρώνει τίποτα.
				?>
				<div data-when-offer="combo" hidden>
					<div class="ecrm-subhead">Στοιχεία Πελάτη Ενέργειας</div>
					<label class="ecrm-syncbar">
						<input type="checkbox" name="combo_energy_same" value="1" data-energy-same="1" checked>
						Ίδιο πρόσωπο με τον πελάτη κινητής
					</label>
					<div class="ecrm-grid" data-energy-fields hidden>
						<?php $ecrm_field( 'combo_energy_name', 'Ονοματεπώνυμο', 'text', true ); ?>
						<?php $ecrm_field( 'combo_energy_afm', 'Α.Φ.Μ.', 'text', true ); ?>
						<?php $ecrm_field( 'combo_energy_adt', 'Αριθμός Εγγράφου Ταυτοπροσωπίας', 'text', true ); ?>
						<?php $ecrm_field( 'combo_energy_doy', 'Δ.Ο.Υ.', 'text', true ); ?>
						<?php
						// Στοιχεία επικοινωνίας ΤΟΥ ΠΕΛΑΤΗ ΕΝΕΡΓΕΙΑΣ -- όχι του
						// πελάτη κινητής. Δεν τυπώνονται πουθενά στο έντυπο· είναι
						// για τον δεύτερο σύνδεσμο υπογραφής (3β-Β), όταν χρειάζεται
						// δεύτερη υπογραφή γιατί είναι άλλο πρόσωπο. Γι' αυτό ΔΕΝ
						// έχουν data-extra="1": στήλες, όχι extra_json (§1.17, βλ.
						// AddComboEnergyContactColumns) -- ο σύνδεσμος υπογραφής τις
						// διαβάζει απευθείας.
						?>
						<?php $ecrm_field( 'combo_energy_mobile', 'Κινητό', 'text', false, '69…' ); ?>
						<?php $ecrm_field( 'combo_energy_email', 'Email', 'email', false ); ?>
					</div>
				</div>

				<?php
				// Η Συνδυαστική δένει δύο γραμμές κινητής κάτω από το ίδιο ΑΦΜ
				// (§ΓΕΝ.ΟΡΟΙ Ορίζον, «τουλάχιστον δύο (2) + συνδέσεις κινητής»).
				// Μέχρι 2026-09-01 η αίτηση έπαιρνε μόνο ΕΝΑΝ αριθμό κινητού
				// (mobile_msisdn), οπότε το έντυπο τυπωνόταν με τη 2η γραμμή
				// κενή -- ζητήθηκε ρητά από τον πελάτη. Ίδιο μοτίβο με το
				// COMBO ακριβώς από πάνω: εμφανίζεται μόνο για mobile_offer=
				// family, γιατί δεν έχει νόημα σε απλή αίτηση ή σε COMBO.
				?>
				<div class="ecrm-grid" data-when-offer="family" hidden>
					<?php $ecrm_field( 'mobile_msisdn_2', 'Αριθμός Κινητού (2ο, Συνδυαστικού)', 'text', true, '69…' ); ?>
				</div>

			</section>

			<?php
			// COMBO Volton+Orizon και από αίτηση ΡΕΥΜΑΤΟΣ -- Στάδιο 4,
			// 05/09/2026 (καθρέφτισμα του «6β» του Βήματος 3, ζητήθηκε ρητά
			// 04/09/2026: docs/UI-COMBO-FROM-VOLTON.html, εγκεκριμένη). Μόνο
			// Volton + ρεύμα -- το combo είναι Volton ρεύμα + Orizon κινητή
			// και τίποτα άλλο, δεν έχει θέση σε αίτηση αερίου ή άλλου
			// παρόχου. `data-when-combo-volton` είναι νέο, δικό του attribute
			// (`applyComboFromVolton()` στο ecrm-form.js) -- ΟΧΙ δύο
			// ανεξάρτητα data-when-energy/data-when-provider πάνω στο ίδιο
			// στοιχείο, που θα συγκρούονταν (βλ. σχόλιο εκεί).
			//
			// ΓΙΑΤΙ ΕΔΩ, στο Βήμα 1-2 και όχι στο 3 (05/09/2026,
			// docs/UI-COMBO-PLACEMENT.html, εγκεκριμένη): η φόρμα χωρίζεται
			// ήδη σε «τι πουλάμε» (Βήματα 1-2: πάροχος, πρόγραμμα, είδος,
			// κατηγορία, χρώμα) και «σε ποιον» (Βήμα 3 και μετά). Η
			// συνδυαστική προσφορά είναι απόφαση ΠΡΟΪΟΝΤΟΣ, όχι πεδίο
			// στοιχείων. Οσο ζούσε στο Βήμα 3 ως «6γ», ο συνεργάτης τη
			// συναντούσε αφού είχε συμπληρώσει ταυτότητα, διεύθυνση και
			// μετρητή -- δηλαδή αφού η κουβέντα για προσφορά με τον πελάτη
			// είχε ήδη τελειώσει. Και η ίδια η ετικέτα «6γ» τη δήλωνε
			// υποσύνολο του «6 Στοιχεία Μετρητή», με το οποίο δεν έχει καμία
			// σχέση.
			?>
			<section class="ecrm-card" data-when-combo-volton data-no-template-filter hidden>
				<div class="ecrm-step"><span class="ecrm-step__n">2β</span> Συνδυαστική Προσφορά</div>
				<div class="ecrm-grid">
					<label class="ecrm-field" data-for="combo_mobile_offer">
						<span class="ecrm-field__label">Συνδυαστική Έκπτωση</span>
						<select name="combo_mobile_offer" class="ecrm-input" data-extra="1">
							<option value="">Καμία</option>
							<option value="combo">COMBO με κινητή Orizon</option>
						</select>
					</label>
				</div>

				<?php
				// Ιδιο ΝΟΗΜΑ με το `combo_energy_relation` της καρτας «6β»,
				// αλλα ΔΙΚΟ ΤΟΥ ονομα: δυο input με το ιδιο name ζουν
				// ταυτοχρονα στο DOM (η μια καρτα ειναι απλως κρυμμενη) και
				// το setField()/collect() πιανουν το ΠΡΩΤΟ στη σειρα DOM --
				// δηλαδη παντα αυτης της καρτας. Κοινο ονομα θα σημαινε οτι
				// το ανοιγμα αποθηκευμενης αιτησης Orizon εγραφε την τιμη σε
				// ΑΥΤΟ το πεδιο και την εχανε. Ιδιος λογος με το
				// `combo_mobile_same` πιο κατω. Οι δυο τιμες ζουν σε
				// ξεχωριστα κλειδια του extra_json.
				?>
				<div class="ecrm-grid" data-when-combo-offer="combo" hidden>
					<label class="ecrm-field" data-for="combo_mobile_relation">
						<span class="ecrm-field__label">Τι έχει ήδη ο πελάτης</span>
						<select name="combo_mobile_relation" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="has_power">Έχει ήδη ρεύμα Volton — νέα κινητή Orizon</option>
							<option value="has_mobile">Έχει ήδη κινητή Orizon — νέο ρεύμα Volton</option>
							<option value="both_new">Νέος και στα δύο — ταυτόχρονη σύναψη</option>
						</select>
					</label>
					<?php $ecrm_field( 'combo_mobile_msisdn', 'Αριθμός Κινητού Orizon', 'text', true, '69…' ); ?>
					<label class="ecrm-field" data-for="combo_mobile_plan">
						<span class="ecrm-field__label">Πρόγραμμα Orizon</span>
						<select name="combo_mobile_plan" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<?php foreach ( \EnergyCRM\Domain\Forms\MobilePlans::options() as $plan_code => $plan_label ) : ?>
								<option value="<?php echo esc_attr( $plan_code ); ?>"><?php echo esc_html( $plan_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="ecrm-field" data-for="combo_mobile_user_role">
						<span class="ecrm-field__label">Χρήστης Γραμμής</span>
						<select name="combo_mobile_user_role" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="main">Κύριος Χρήστης</option>
							<option value="secondary">Δευτερεύων Χρήστης</option>
						</select>
					</label>
				</div>

				<?php
				// Ο κύριος πελάτης εδώ ΕΙΝΑΙ ο πελάτης ενέργειας (η ίδια η
				// αίτηση Volton) -- ανεστραμμένο από την κάρτα «6β», όπου ο
				// κύριος πελάτης είναι ο πελάτης κινητής. Ίδιο checkbox-μοτίβο,
				// ΔΙΚΟ ΤΟΥ όνομα (`combo_mobile_same`, όχι `combo_energy_same`)
				// -- τα δύο ζουν σε διαφορετικές κάρτες, ποτέ ταυτόχρονα
				// ορατές, και ένα κοινό όνομα θα σήμαινε δύο τιμές στο ίδιο
				// πεδίο του extra_json.
				?>
				<div data-when-combo-offer="combo" hidden>
					<label class="ecrm-syncbar">
						<input type="checkbox" name="combo_mobile_same" value="1" data-energy-same="1" checked>
						Ίδιο πρόσωπο και στις δύο συμβάσεις
					</label>
					<div class="ecrm-grid" data-mobile-fields hidden>
						<?php $ecrm_field( 'combo_mobile_name', 'Ονοματεπώνυμο', 'text', true ); ?>
						<?php $ecrm_field( 'combo_mobile_afm', 'Α.Φ.Μ.', 'text', true ); ?>
						<?php $ecrm_field( 'combo_mobile_adt', 'Αριθμός Εγγράφου Ταυτοπροσωπίας', 'text', true ); ?>
						<?php $ecrm_field( 'combo_mobile_doy', 'Δ.Ο.Υ.', 'text', true ); ?>
						<?php
						// Για τον δεύτερο σύνδεσμο υπογραφής -- δεν τυπώνονται
						// πουθενά. Στήλες, όχι extra_json (§1.17, βλ.
						// AddComboMobileContactColumns) -- τις διαβάζει
						// απευθείας ο SignLinkController.
						?>
						<?php $ecrm_field( 'combo_mobile_mobile', 'Κινητό', 'text', false, '69…' ); ?>
						<?php $ecrm_field( 'combo_mobile_email', 'Email', 'email', false ); ?>
					</div>
				</div>
			</section>

			</div>

			<div class="ecrm-wstep" data-wstep="2" hidden>

			<!-- Auto: required documents from Knowledge Base -->
			<section class="ecrm-card ecrm-kbdocs" data-kbdocs hidden>
				<div class="ecrm-step"><span class="ecrm-step__n ecrm-step__n--kb"><svg class="ecrm-i ecrm-i--step" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 4h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h4"/></svg></span> Απαιτούμενα δικαιολογητικά</div>
				<div class="ecrm-kbdocs__body" data-kbdocs-body></div>
			</section>

			<section class="ecrm-card ecrm-card--ai">
				<div class="ecrm-step"><span class="ecrm-step__n ecrm-step__n--ai">AI</span> Εξαγωγή στοιχείων</div>
				<p class="ecrm-ai-lead">Ταυτότητα + λογαριασμός παρόχου → η AI βγάζει τα στοιχεία και γεμίζει τη φόρμα.</p>

				<div class="ecrm-drop" data-drop tabindex="0" role="button" aria-label="Σύρε αρχεία ή πάτα για επιλογή">
					<input type="file" data-files accept="application/pdf,image/jpeg,image/png" multiple hidden>
					<div class="ecrm-drop__icon"><svg class="ecrm-i ecrm-i--drop" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V7m0 0l-4 4m4-4l4 4M4 21h16"/></svg></div>
					<div class="ecrm-drop__title">Σύρε αρχεία εδώ</div>
					<div class="ecrm-drop__hint">ή <button type="button" class="ecrm-link" data-pick>πάτα για επιλογή</button> · PDF, JPG, PNG · έως 10 αρχεία</div>
				</div>
				<?php
				/*
				 * Δεύτερη, ξεχωριστή είσοδος για τη ΦΩΤΟΓΡΑΦΙΑ — όχι το ίδιο input
				 * με `capture` προσθεμένο. Το `capture` σε είσοδο που δέχεται PDF
				 * ΚΑΙ πολλαπλά αρχεία έχει ασυνεπή συμπεριφορά ανά browser (συνήθως
				 * κλειδώνει σε μία φωτογραφία, αγνοώντας `multiple` και PDF) — θα
				 * έσπαγε την επιλογή αρχείου. Δύο εισόδους, ένα `addFiles()` και
				 * στις δύο (ecrm-form.js): ο χρήστης διαλέγει ρητά κάμερα ή αρχείο,
				 * όχι το browser για λογαριασμό του. Ζητήθηκε ρητά από τον
				 * ιδιοκτήτη, 23/08.
				 *
				 * Το κουμπί μένει στο DOM σε κάθε συσκευή — κρύβεται σε desktop
				 * μόνο με CSS (`@media (hover: hover) and (pointer: fine)` στο
				 * ecrm-form.css), ρητή αντιστροφή της 23/08 από τον ιδιοκτήτη,
				 * 2026-08-24: σε desktop δεν έχει νόημα κουμπί λήψης φωτογραφίας.
				 */
				?>
				<button type="button" class="ecrm-btn ecrm-btn--ghost ecrm-camera-btn" data-camera-pick>
					<svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l1.5-2h7L17 8h3a1 1 0 011 1v10a1 1 0 01-1 1H4a1 1 0 01-1-1V9a1 1 0 011-1z"/><circle cx="12" cy="13" r="3.5"/></svg>
					Λήψη φωτογραφίας
				</button>
				<input type="file" data-camera accept="image/jpeg,image/png" capture="environment" hidden>

				<ul class="ecrm-filelist" data-filelist></ul>
				<button type="button" class="ecrm-btn ecrm-btn--ai" data-extract disabled><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6z"/><path d="M18 15l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/></svg> Εξαγωγή με AI</button>
				<div class="ecrm-ai-status" data-ai-status aria-live="polite"></div>
			</section>

			</div>


			<div class="ecrm-wstep" data-wstep="3" hidden>

			<!-- Auto: possible duplicate warning. Ζει ΕΔΩ και όχι πιο πάνω, γιατί
			     την πυροδοτούν το ΑΦΜ και ο αριθμός παροχής, που είναι αυτής της
			     οθόνης· σε άλλο βήμα θα εμφανιζόταν εκεί που κανείς δεν κοιτά. -->
			<div class="ecrm-dupwarn" data-dupwarn hidden></div>

			<!-- «Πάνω στο έντυπο» -- ζητήθηκε ρητά 30/08 («να εμφανίζεται το
			     έγγραφο της αίτησης και ο υπάλληλος να συμπληρώνει κατευθείαν
			     πάνω στην αίτηση»). Ο μηχανισμός είναι γενικός (assets/forms/
			     {template}.json+jpg υπάρχουν ΗΔΗ για όλους τους παρόχους,
			     class-ecrm-formfill.php τα εμπιστεύεται σήμερα για την τελική
			     εκτύπωση) -- αλλά η ΕΜΦΑΝΙΣΗ περιορίστηκε ρητά μόνο σε Protergia
			     για αυτόν τον πρώτο γύρο (ecrm-form.js: docOverlaySupported()),
			     ώστε να μη «χαλάσει το υπάρχον» πουθενά αλλού. Κρυφό by default
			     -- η JS το ξεσκεπάζει ΜΟΝΟ όταν βρει θέσεις πεδίων για τον
			     τρέχοντα πάροχο/πρόγραμμα. Καμία αλλαγή στο <section> από κάτω:
			     η κλασική φόρμα μένει ΑΚΡΙΒΩΣ όπως ήταν. -->
			<div class="ecrm-docsw" data-docsw hidden>
				<span class="ecrm-docsw__label">Στοιχεία Πελάτη</span>
				<div class="ecrm-docsw__tabs">
					<button type="button" class="ecrm-docsw__tab is-on" data-docview="classic">Κλασική φόρμα</button>
					<button type="button" class="ecrm-docsw__tab" data-docview="doc">Πάνω στο έντυπο</button>
				</div>
			</div>

			<div data-classic-view>
			<section class="ecrm-card">
				<div class="ecrm-step"><span class="ecrm-step__n">3</span> Στοιχεία Πελάτη</div>

				<!-- Αναδιάταξη 25/08 (ζητήθηκε ρητά, live στην οθόνη): πρώτα η
				     ταυτότητα του φυσικού προσώπου (Όνομα/Επίθετο/Ημ.Γέννησης/
				     Πατρώνυμο), μετά οι αριθμοί (ΑΦΜ/ΑΔΤ/Δ.Ο.Υ) σε μία σειρά,
				     το Τ.Κ πήγε στη Διεύθυνση όπου ανήκει. Δύο grid αντί για
				     ένα ΜΟΝΟ επειδή το πρώτο είναι απών εξ ολοκλήρου για
				     εταιρεία (data-when στο ίδιο το div), ενώ το δεύτερο έχει
				     ΑΦΜ/Δ.Ο.Υ κοινά + ΑΔΤ μόνο για φυσικό πρόσωπο (data-when
				     στο ίδιο το πεδίο, νέα δυνατότητα του $ecrm_field). -->
				<!-- φυσικό πρόσωπο -->
				<div class="ecrm-grid" data-when="individual,sole_prop">
					<?php $ecrm_field( 'first_name', 'Όνομα', 'text', false, '', '', 'section-cust given-name' ); ?>
					<?php $ecrm_field( 'last_name', 'Επίθετο', 'text', false, '', '', 'section-cust family-name' ); ?>
					<?php $ecrm_field( 'birth_date', 'Ημ. Γέννησης', 'date', false, '', '', 'section-cust bday' ); ?>
					<?php $ecrm_field( 'father_name', 'Πατρώνυμο' ); ?>
				</div>

				<!-- Build queue 08, 25/08: εμφανίζεται όταν το ΑΦΜ που μόλις
				     γράφτηκε ανήκει ήδη σε γνωστό πελάτη (scoped στον
				     συνεργάτη — δες /customers/check). Άδειο by default, το
				     γεμίζει το ecrm-form.js σε blur του ΑΦΜ. -->
				<div class="ecrm-custmatch" data-custmatch hidden></div>

				<div class="ecrm-grid">
					<label class="ecrm-field" data-for="afm">
						<span class="ecrm-field__label">ΑΦΜ <abbr title="Υποχρεωτικό για να προχωρήσει η αίτηση πέρα από το πρόχειρο">*</abbr></span>
						<span class="ecrm-input-wrap"><input type="text" name="afm" class="ecrm-input" autocomplete="off"><button type="button" class="ecrm-input-btn" data-afm-search aria-label="Αναζήτηση ΑΦΜ"><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg></button></span>
					</label>
					<?php $ecrm_field( 'adt', 'Α.Δ.Τ / Διαβατήριο', 'text', false, '', '', 'off', 'individual,sole_prop' ); ?>
					<?php $ecrm_field( 'doy', 'Δ.Ο.Υ' ); ?>
				</div>

				<!-- εταιρεία -->
				<div class="ecrm-grid" data-when="company,sole_prop">
					<?php $ecrm_field( 'company_name', 'Επωνυμία Εταιρείας', 'text', false, '', '', 'section-cust organization' ); ?>
					<?php $ecrm_field( 'company_type', 'Νομική Μορφή', 'text', true, 'Α.Ε. / Ε.Π.Ε. / Ο.Ε.' ); ?>
					<?php $ecrm_field( 'activity', 'Αντικείμενο Δραστηριότητας', 'text', true ); ?>
					<?php // Ζητούνται ρητά στα επαγγελματικά έντυπα NRG και Protergia. ?>
					<?php $ecrm_field( 'kad', 'Κ.Α.Δ.', 'text', true ); ?>
					<?php $ecrm_field( 'gemi', 'Αρ. Γ.Ε.ΜΗ.', 'text', true ); ?>
				</div>

				<div class="ecrm-subhead">Διεύθυνση</div>
				<div class="ecrm-grid">
					<?php $ecrm_field( 'region', 'Νομός', 'text', false, '', '', 'section-cust address-level1' ); ?>
					<?php $ecrm_field( 'city', 'Πόλη', 'text', false, '', '', 'section-cust address-level2' ); ?>
					<?php $ecrm_field( 'street', 'Οδός', 'text', false, '', '', 'section-cust address-line1' ); ?>
					<?php $ecrm_field( 'street_no', 'Αριθμός' ); ?>
					<?php // Τ.Κ μετακόμισε εδώ 25/08 (ζητήθηκε ρητά) — είναι
					      // κομμάτι της διεύθυνσης, όχι της ταυτότητας του πελάτη. ?>
					<div class="ecrm-field-with-suggest">
						<?php $ecrm_field( 'postal_code', 'Τ.Κ', 'text', false, '', '', 'section-cust postal-code' ); ?>
						<div class="ecrm-postal-suggest" data-tk-suggest="cust" hidden>
							<span data-tk-suggest-text="cust"></span>
							<button type="button" class="ecrm-postal-suggest__btn" data-tk-suggest-use="cust" hidden>Χρήση</button>
						</div>
					</div>
				</div>

				<div class="ecrm-subhead">Επικοινωνία</div>
				<div class="ecrm-grid">
					<?php $ecrm_field( 'phone', 'Τηλέφωνο', 'text', false, '', '', 'section-cust tel' ); ?>
					<?php $ecrm_field( 'mobile', 'Κινητό', 'text', false, '', '', 'section-cust tel' ); ?>
					<?php $ecrm_field( 'email', 'Email', 'email', false, '', '', 'section-cust email' ); ?>
				</div>
			</section>

			<!--
				Πεδία που ζητά συγκεκριμένα η αίτηση του επιλεγμένου παρόχου.
				Γεμίζει από το /forms/fields με τις ετικέτες του ίδιου του
				εντύπου, ώστε ο συνεργάτης να διαβάζει στην οθόνη ό,τι θα δει
				και στο χαρτί.
			-->
			<section class="ecrm-card ecrm-provform" data-provider-fields hidden>
				<div class="ecrm-step"><span class="ecrm-step__n"><svg class="ecrm-i ecrm-i--step" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h10"/></svg></span> <span data-provform-title>Απαιτούμενα από τον πάροχο</span></div>
				<div class="ecrm-grid" data-provform-grid></div>
			</section>
			</div><!-- /[data-classic-view] -->

			<!-- Ίδια πεδία με τα δύο <section> από πάνω -- ΔΕΝ αντιγράφονται,
			     δανείζονται (ίδια τεχνική με το paintProviderFields παραπάνω):
			     η JS γράφει κατευθείαν στο πραγματικό .ecrm-input πάνω στο
			     έντυπο, όχι σε αντίγραφο. Έτσι το collect()/readField() και
			     κάθε listener που ήδη ακούει το πραγματικό πεδίο (dup-check,
			     AI-mark, Γρήγορη σύνοψη) συνεχίζουν να δουλεύουν ΑΝΑΛΛΟΙΩΤΑ,
			     ό,τι όψη κι αν βλέπει ο χρήστης. -->
			<section class="ecrm-card ecrm-docoverlay" data-doc-overlay hidden>
				<div class="ecrm-step"><span class="ecrm-step__n"><svg class="ecrm-i ecrm-i--step" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h10"/></svg></span> Πάνω στο έντυπο</div>
				<div class="ecrm-docbox" data-docoverlay-box>
					<img data-docoverlay-img alt="Έντυπο αίτησης">
				</div>
				<p class="ecrm-docoverlay__hint">Μόνο τα πεδία που τυπώνονται σε αυτή τη σελίδα εμφανίζονται εδώ· τα υπόλοιπα μένουν στην «Κλασική φόρμα».</p>
			</section>

			<?php
			// Νόμιμος εκπρόσωπος και υπεύθυνος επικοινωνίας περιγράφουν μια
			// επιχειρηματική σύμβαση ρεύματος/αερίου· κανένα από τα τέσσερα
			// έντυπα Orizon δεν τα ζητά (επιβεβαιωμένο με grep στα JSON), οπότε
			// κρύβονται στην κινητή. Το εξωτερικό div είναι απαραίτητο για το
			// πρώτο section: το δικό του data-when (τύπος πελάτη) δεν μπορεί
			// να συνυπάρξει με data-when-energy στο ίδιο στοιχείο, γιατί το JS
			// applyCustomerType() καλεί applyEnergyType() αμέσως μετά και το
			// δεύτερο θα σκέπαζε το πρώτο.
			?>
			<div data-when-energy="power,gas">
			<!-- Νόμιμος Εκπρόσωπος (εταιρείες) -->
			<section class="ecrm-card" data-when="company,sole_prop">
				<div class="ecrm-step"><span class="ecrm-step__n">4</span> Νόμιμος Εκπρόσωπος</div>
				<!-- Ίδιο μοτίβο με το data-sync="contact" της επόμενης κάρτας: για
				     ατομική επιχείρηση ο εκπρόσωπος ΕΙΝΑΙ ο πελάτης, το ίδιο φυσικό
				     πρόσωπο — 9 πεδία που έχουν ήδη γραφτεί στα Στοιχεία Πελάτη. -->
				<label class="ecrm-syncbar"><input type="checkbox" data-sync="rep"> Ίδια στοιχεία με τον πελάτη — αυτόματος συγχρονισμός</label>
				<div class="ecrm-grid">
					<?php $ecrm_field( 'rep_first_name', 'Όνομα', 'text', true, '', '', 'section-rep given-name' ); ?>
					<?php $ecrm_field( 'rep_last_name', 'Επώνυμο', 'text', true, '', '', 'section-rep family-name' ); ?>
					<?php $ecrm_field( 'rep_father_name', 'Πατρώνυμο', 'text', true ); ?>
					<?php $ecrm_field( 'rep_id', 'Αρ. Ταυτότητας / Διαβατηρίου', 'text', true ); ?>
					<?php $ecrm_field( 'rep_afm', 'ΑΦΜ Νόμιμου Εκπροσώπου', 'text', true ); ?>
					<?php $ecrm_field( 'rep_birth_date', 'Ημ. Γέννησης', 'date', true, '', '', 'section-rep bday' ); ?>
					<?php $ecrm_field( 'rep_phone', 'Σταθερό', 'text', true, '', '', 'section-rep tel' ); ?>
					<?php $ecrm_field( 'rep_mobile', 'Κινητό', 'text', true, '', '', 'section-rep tel' ); ?>
					<?php $ecrm_field( 'rep_email', 'Email', 'email', true, '', '', 'section-rep email' ); ?>
				</div>
			</section>
			</div>

			<!-- Υπεύθυνος Επικοινωνίας -->
			<section class="ecrm-card" data-when-energy="power,gas">
				<div class="ecrm-step"><span class="ecrm-step__n">5</span> Υπεύθυνος Επικοινωνίας</div>
				<label class="ecrm-syncbar"><input type="checkbox" data-sync="contact"> Ίδια στοιχεία με τον πελάτη / εκπρόσωπο — αυτόματος συγχρονισμός</label>
				<div class="ecrm-grid">
					<?php $ecrm_field( 'contact_first_name', 'Όνομα', 'text', true, '', '', 'section-contact given-name' ); ?>
					<?php $ecrm_field( 'contact_last_name', 'Επώνυμο', 'text', true, '', '', 'section-contact family-name' ); ?>
					<?php $ecrm_field( 'contact_father_name', 'Πατρώνυμο', 'text', true ); ?>
					<?php $ecrm_field( 'contact_adt', 'Α.Δ.Τ', 'text', true ); ?>
					<?php $ecrm_field( 'contact_mobile', 'Κινητό', 'text', true, '', '', 'section-contact tel' ); ?>
					<?php $ecrm_field( 'contact_email', 'Email', 'email', true, '', '', 'section-contact email' ); ?>
					<?php $ecrm_field( 'contact_phone', 'Τηλέφωνο', 'text', true, '', '', 'section-contact tel' ); ?>
					<?php $ecrm_field( 'contact_afm', 'ΑΦΜ Υπεύθυνου', 'text', true ); ?>
				</div>
			</section>

			<!-- Στοιχεία Μετρητή -->
			<?php
			// Παροχή, μετρητής, ισχύς, τιμολόγιο, προηγούμενος πάροχος: κάθε
			// πεδίο εδώ περιγράφει ρολόι σε τοίχο. Σε αίτηση κινητής δεν
			// υπάρχει τίποτα από αυτά να συμπληρωθεί, και το τμήμα έμενε
			// ορατό επειδή ήταν το μόνο χωρίς δήλωση είδους παροχής.
			?>
			<section class="ecrm-card" data-when-energy="power,gas">
				<div class="ecrm-step"><span class="ecrm-step__n">6</span> Στοιχεία Μετρητή</div>
				<div class="ecrm-grid">
					<?php $ecrm_field( 'supply_number', 'Αριθμός Παροχής / ΗΚΑΣΠ' ); ?>
					<?php $ecrm_field( 'meter_number', 'Αριθμός Μετρητή' ); ?>
					<?php $ecrm_field( 'region_code', 'Κωδ. Περιφέρειας', 'text', true ); ?>
					<?php $ecrm_field( 'successor_no', 'Διάδοχος', 'text', true ); ?>
					<?php $ecrm_field( 'meter_activity', 'Δραστηριότητα', 'text', true ); ?>
					<?php
					/*
					 * Λίστα και όχι <select>: το πεδίο τυπώνεται αυτούσιο στο
					 * «ΥΦΙΣΤΑΜΕΝΟΣ ΠΡΟΜΗΘΕΥΤΗΣ» του εντύπου, και οι παλιές αιτήσεις
					 * έχουν ελεύθερο κείμενο. Ένα <select> θα άδειαζε σιωπηλά κάθε
					 * τιμή που δεν είναι στη λίστα την πρώτη φορά που θα
					 * αποθηκευόταν η αίτηση. Έτσι διαλέγεις από τη λίστα, αλλά αν ο
					 * πάροχος λείπει μπορείς να τον γράψεις. Λίστα ΡΑΑΕΥ/αγοράς,
					 * 29/09/2026.
					 */
					$ecrm_suppliers = [
						'Μη επιβεβαιωμένος', 'ΔΕΗ', 'Protergia', 'Ήρων', 'Elpedison', 'NRG', 'ZeniΘ', 'Volton',
						'Watt+Volt', 'Enerwave', 'Φυσικό Αέριο Ελληνική Εταιρεία Ενέργειας',
						'Volterra', 'Solar Energy', 'We Energy', 'Ελίν', 'EFA Energy', 'ΚΕΝ',
					];
					?>
					<label class="ecrm-field" data-for="previous_provider">
						<span class="ecrm-field__label">Υφιστάμενος Προμηθευτής</span>
						<input type="text" name="previous_provider" class="ecrm-input" data-extra="1" list="ecrm-suppliers" autocomplete="off" placeholder="Διάλεξε ή γράψε">
					</label>
					<datalist id="ecrm-suppliers">
						<?php foreach ( $ecrm_suppliers as $ecrm_supplier ) : ?>
							<option value="<?php echo esc_attr( $ecrm_supplier ); ?>"></option>
						<?php endforeach; ?>
					</datalist>
					<label class="ecrm-field" data-for="capacity_role">
						<span class="ecrm-field__label">Ιδιότητα</span>
						<select name="capacity_role" class="ecrm-input" data-extra="1">
							<option value="">—</option><option value="owner">Ιδιοκτήτης</option><option value="tenant">Ενοικιαστής</option><option value="manager">Διαχειριστής</option>
						</select>
					</label>
					<?php $ecrm_field( 'agreed_power', 'Συμφωνημένη Ισχύς (kVA)', 'text', true ); ?>
					<?php $ecrm_field( 'day_indication', 'Ένδειξη Ημέρας', 'text', true ); ?>
					<label class="ecrm-field" data-for="meter_position">
						<span class="ecrm-field__label">Θέση Μετρητή</span>
						<select name="meter_position" class="ecrm-input" data-extra="1">
							<option value="">—</option><option value="inside">Εσωτερικός</option><option value="outside">Εξωτερικός</option>
						</select>
					</label>
					<label class="ecrm-field" data-for="meter_reading_type">
						<span class="ecrm-field__label">Μέτρηση</span>
						<select name="meter_reading_type" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="day">Ημερήσια</option>
							<option value="day_night">Ημερήσια &amp; Νυχτερινή</option>
							<option value="telemetry">Τηλεμετρούμενη</option>
						</select>
					</label>
					<?php // Ίδιο σκεπτικό με τον προμηθευτή: λίστα, όχι <select>, για να μη χαθούν οι παλιές τιμές. ?>
					<label class="ecrm-field" data-for="eidiki_katigoria">
						<span class="ecrm-field__label">Ειδική Κατηγορία</span>
						<input type="text" name="eidiki_katigoria" class="ecrm-input" data-extra="1" list="ecrm-special-category" autocomplete="off" placeholder="Διάλεξε ή γράψε">
					</label>
					<datalist id="ecrm-special-category">
						<?php foreach ( [ 'ΚΟΤ Α', 'ΚΟΤ Β', 'ΚΟΤ Γ', 'Ευάλωτος Πελάτης' ] as $ecrm_category ) : ?>
							<option value="<?php echo esc_attr( $ecrm_category ); ?>"></option>
						<?php endforeach; ?>
					</datalist>
					<?php // Η εγγύηση μετακόμισε στα Στοιχεία Τιμολόγησης — τη ζητά και η κινητή, όχι μόνο ρεύμα/αέριο. ?>
					<?php $ecrm_field( 'promotion', 'Promotion', 'text', true ); ?>
				</div>
				<?php
				// Where the meter actually is. Real columns, not the extras bag:
				// every provider form has a "ΔΙΕΥΘΥΝΣΗ ΠΑΡΟΧΗΣ" box, and until
				// these were stored properly it printed the customer's home
				// address — right until the meter is in a rented shop.
				?>
				<div class="ecrm-subhead">Διεύθυνση Παροχής <span class="ecrm-hint">— εκεί που βρίσκεται ο μετρητής</span></div>
				<label class="ecrm-syncbar">
					<input type="checkbox" name="supply_addr_same" value="1" data-addr-same="supply" checked>
					Ίδια με τη διεύθυνση του πελάτη
				</label>
				<div class="ecrm-grid" data-addr-fields="supply" hidden>
					<?php $ecrm_field( 'supply_street', 'Οδός', 'text', false, '', '', 'section-supply shipping address-line1' ); ?>
					<?php $ecrm_field( 'supply_street_no', 'Αριθμός' ); ?>
					<div class="ecrm-field-with-suggest">
						<?php $ecrm_field( 'supply_postal_code', 'Τ.Κ', 'text', false, '', '', 'section-supply shipping postal-code' ); ?>
						<div class="ecrm-postal-suggest" data-tk-suggest="supply" hidden>
							<span data-tk-suggest-text="supply"></span>
							<button type="button" class="ecrm-postal-suggest__btn" data-tk-suggest-use="supply" hidden>Χρήση</button>
						</div>
					</div>
					<?php $ecrm_field( 'supply_city', 'Πόλη', 'text', false, '', '', 'section-supply shipping address-level2' ); ?>
					<?php $ecrm_field( 'supply_region', 'Νομός', 'text', false, '', '', 'section-supply shipping address-level1' ); ?>
				</div>
			</section>


			<?php
			// Κινητή τηλεφωνία. Ένα δικό της τμήμα και όχι πεδία σκορπισμένα
			// στα υπάρχοντα: η αίτηση κινητής περιγράφει γραμμή, όχι μετρητή,
			// και τίποτα εδώ δεν έχει νόημα σε ρεύμα ή αέριο.
			?>
			<section class="ecrm-card" data-when-energy="mobile">
				<div class="ecrm-step"><span class="ecrm-step__n">6β</span> Στοιχεία Κινητής</div>
				<div class="ecrm-grid">
					<?php
					// Το «Τύπος Αίτησης» έφυγε από εδώ 2026-08-24: μπέρδευε τον
					// πράκτορα δίπλα στο ήδη υπάρχον «Ενεργοποίηση» του Βήματος
					// 1, που για mobile δείχνει «Νέα σύνδεση» / «Ανανέωση» /
					// «Φορητότητα» — τρεις πραγματικές τιμές (ECRM_DB::
					// activation_types() έχει και τις τρεις, οι δύο πρώτες
					// αφύλακτες στο $act_energy παρακάτω, ήδη ορατές). Το
					// request_type παράγεται πλέον αυτόματα από εκείνη την
					// επιλογή στο backend (ContractSaveMapping::contractFrom,
					// τρίτη περίπτωση 'renewal' — διόρθωση 2026-08-24, η πρώτη
					// γραφή αυτού του σημείου νόμιζε ότι υπήρχαν μόνο δύο
					// τιμές) — μία επιλογή στην οθόνη, όχι δύο συγχρονισμένα
					// πεδία.
					?>

					<?php $ecrm_field( 'mobile_msisdn', 'Αριθμός Κινητού', 'text', true, '69…' ); ?>
					<?php
					/*
					 * Ίδιο κέλυφος .ecrm-input-wrap με το ΑΦΜ λίγο πιο πάνω -- δεν
					 * φτιάχνεται δεύτερο μοτίβο, δεύτερος χρήστης του υπάρχοντος.
					 * Το data-scan="sim_number" είναι γενικό επίτηδες (§1.13): το
					 * ίδιο κουμπί, το ίδιο JS, θα δούλευε σε οποιοδήποτε πεδίο που
					 * θα αποκτούσε ανάγκη ανάγνωσης barcode αύριο.
					 */
					?>
					<label class="ecrm-field" data-for="sim_number">
						<span class="ecrm-field__label">Αριθμός Κάρτας SIM</span>
						<span class="ecrm-input-wrap">
							<input type="text" name="sim_number" class="ecrm-input" data-extra="1" autocomplete="off">
							<button type="button" class="ecrm-input-btn ecrm-scan-btn" data-scan="sim_number" aria-label="Σάρωση barcode κάρτας SIM">
								<svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><path d="M7 8v8M10 8v8M13.5 8v8M17 8v8"/></svg>
							</button>
						</span>
					</label>
					<?php $ecrm_field( 'subsidy_type', 'Τύπος Επιδότησης', 'text', true, 'π.χ. Έκπτωση Παγίου' ); ?>
					<?php
					// (265) Ανώτατο Όριο Λογαριασμού -- πίνακας 15 συγκεκριμένων
					// τιμών στη σελ.4 του orizon_mobile.json. Dropdown με ΑΚΡΙΒΩΣ
					// αυτές τις τιμές, όχι ελεύθερο κείμενο σαν το 'anotato_orio'
					// του ρεύματος/αερίου παρακάτω -- ένας αριθμός εκτός λίστας
					// δεν θα ταίριαζε σε κανένα κουτί του χαρτιού.
					?>
					<?php
					// (293) Σελ.3 του orizon_mobile: «ΧΡΗΣΗ ΥΠΗΡΕΣΙΑΣ ΑΝΩΤΑΤΟ ΟΡΙΟ
					// ΛΟΓΑΡΙΑΣΜΟΥ» ΝΑΙ/ΟΧΙ. Δική του ερώτηση, όχι το 'bill_cap' του
					// ρεύματος/αερίου -- εκείνο κρύβεται στην κινητή.
					$ecrm_yesno( 'mobile_bill_cap_use', 'Χρήση υπηρεσίας «Ανώτατο Όριο Λογαριασμού»' );
					?>
					<label class="ecrm-field" data-for="mobile_bill_cap">
						<span class="ecrm-field__label">Ανώτατο Όριο Λογαριασμού</span>
						<select name="mobile_bill_cap" class="ecrm-input" data-extra="1">
							<option value="">—</option>
							<option value="0">0€</option>
							<option value="10">10€</option>
							<option value="25">25€</option>
							<option value="50">50€</option>
							<option value="100">100€</option>
							<option value="150">150€</option>
							<option value="200">200€</option>
							<option value="250">250€</option>
							<option value="300">300€</option>
							<option value="350">350€</option>
							<option value="400">400€</option>
							<option value="450">450€</option>
							<option value="500">500€</option>
							<option value="1000">1000€</option>
							<option value="2000">2000€</option>
						</select>
					</label>
					<?php
					/*
					 * (268): οι τρεις δηλώσεις ΝΑΙ/ΟΧΙ της σελ.5 του orizon_mobile.json
					 * που ΔΕΝ ταυτίζονται με καμία ήδη υπάρχουσα ερώτηση -- η τέταρτη
					 * (άρθρο 11) είναι το ήδη υπάρχον 'no_marketing_calls', ζωντανό
					 * πλέον και για mobile στην ενότητα «Ερωτήσεις προς τον πελάτη»
					 * παρακάτω, όχι εδώ -- δεν ζητάμε το ίδιο πράγμα δύο φορές. (269):
					 * προστέθηκε το μονό κουτί της κορυφής σελ.6 (gdpr_rights_ack) --
					 * ίδια λογική, το 'no_directory_listing' λίγο πιο κάτω επίσης δεν
					 * επαναλαμβάνεται εδώ.
					 */
					$ecrm_yesno( 'orizon_marketing_consent', 'Επιθυμεί προωθητικά μηνύματα Orizon (SMS/Viber/email);' );
					$ecrm_yesno( 'volton_marketing_consent', 'Συναινεί σε επεξεργασία δεδομένων από Volton για προώθηση;' );
					$ecrm_yesno( 'promo_after_termination', 'Συναινεί σε επεξεργασία από Orizon μετά τη λήξη της σύμβασης (προώθηση);' );
					$ecrm_yesno( 'gdpr_rights_ack', 'Ενημερώθηκε για δικαίωμα ανάκλησης συναίνεσης & καταγγελίας (dpa.gr);' );
					?>
				</div>

				<?php
				/*
				 * Η κρυφή είσοδος λήψης, ΞΕΧΩΡΙΣΤΗ από το data-camera του
				 * τμήματος Εγγράφων. Δύο λόγοι: (1) εκείνη δέχεται PDF+JPG+PNG
				 * για έγγραφα φακέλου -- εδώ θέλουμε ΜΟΝΟ εικόνα, μία λήψη· (2)
				 * η αλλαγή εδώ ενεργοποιεί το barcode/AI της κάρτας SIM, όχι το
				 * addFiles() του φακέλου -- διαφορετικός χειριστής, διαφορετική
				 * είσοδος, ίδιο ζεύγος button+input capture="environment" με
				 * το data-camera-pick.
				 */
				?>
				<input type="file" data-scan-camera accept="image/*" capture="environment" hidden>

				<?php
				// Τρεις τιμές, γιατί η προσφορά αλλάζει δύο φορές: τι κοστίζει
				// κανονικά, τι πληρώνει όσο τρέχει η προσφορά, και πού
				// επιστρέφει μετά. Μία τιμή για τα τρία σημαίνει ότι κάποιος
				// μαθαίνει λάθος τιμή για τον 25ο μήνα.
				?>
				<?php
				// Το πλάνο έχει σταθερή, δημοσιευμένη τιμή — δεν είναι κάτι που
				// διαπραγματεύεται ο συνεργάτης. readonly ώστε να φαίνεται η
				// πραγματική τιμή που θα τυπωθεί αντί για κενά κουτιά που θα
				// αγνοηθούν σιωπηλά (values.php πάντα προτιμά το MobilePlans
				// όταν υπάρχει έγκυρο program_code). Γεμίζουν από JS
				// (updateMobilePricing) όταν αλλάζει πρόγραμμα ή προσφορά.
				?>
				<div class="ecrm-subhead">Τιμολόγηση Προγράμματος <span class="ecrm-hint">— υπολογίζεται αυτόματα από το πρόγραμμα</span></div>
				<div class="ecrm-grid">
					<label class="ecrm-field" data-for="base_price">
						<span class="ecrm-field__label">Αρχική Τιμή Παγίου (€)</span>
						<input type="text" name="base_price" class="ecrm-input" data-extra="1" readonly autocomplete="off">
					</label>
					<label class="ecrm-field" data-for="offer_price">
						<span class="ecrm-field__label">Τιμή Προσφοράς ανά Μήνα (€)</span>
						<input type="text" name="offer_price" class="ecrm-input" data-extra="1" readonly autocomplete="off">
					</label>
					<label class="ecrm-field" data-for="price_after">
						<span class="ecrm-field__label">Πάγιο μετά τη Λήξη Προσφοράς (€)</span>
						<input type="text" name="price_after" class="ecrm-input" data-extra="1" readonly autocomplete="off">
					</label>
				</div>
			</section>

			<!-- Στοιχεία Τιμολόγησης -->
			<section class="ecrm-card">
				<div class="ecrm-step"><span class="ecrm-step__n">7</span> Στοιχεία Τιμολόγησης</div>
				<div class="ecrm-grid">
					<?php
					// «Μετρητά» στη θέση του «Με την παραλαβή» (29/09). Η τιμή μένει
					// `manual` ώστε οι παλιές αιτήσεις να δείχνουν σωστά· στο έντυπο
					// ό,τι δεν είναι `standing_order` σημαίνει ούτως ή άλλως «όχι πάγια».
					?>
					<label class="ecrm-field" data-for="payment_method" data-when-energy="power,gas">
						<span class="ecrm-field__label">Τρόπος Πληρωμής</span>
						<select name="payment_method" class="ecrm-input" data-extra="1">
							<option value="">—</option><option value="standing_order">Πάγια Εντολή</option><option value="manual">Μετρητά</option>
						</select>
					</label>
					<label class="ecrm-field" data-for="bill_delivery" data-when-energy="power,gas,mobile">
						<span class="ecrm-field__label">Τρόπος Αποστολής Λογαριασμού</span>
						<select name="bill_delivery" class="ecrm-input" data-extra="1">
							<option value="">—</option><option value="email">Email</option><option value="post">Ταχυδρομικώς</option><option value="both">Και τα δύο</option>
						</select>
					</label>
					<?php
					// Το πεδίο IBAN αφαιρέθηκε 2026-08-11. Κανένα από τα 20 έντυπα
					// δεν είχε θέση να το τυπώσει, οπότε ζητούσαμε τραπεζικό
					// λογαριασμό που δεν πήγαινε πουθενά. Το αποδεικτικό
					// λογαριασμού παραμένει ως είδος ανεβασμένου εγγράφου, όταν
					// το ζητά ο πάροχος.
					?>
					<?php // Χωρίς guard: το orizon_mobile.json ζητά κι αυτό εγγύηση, όχι μόνο ρεύμα/αέριο. ?>
					<div class="ecrm-field-with-suggest">
						<?php $ecrm_field( 'guarantee', 'Εγγύηση (€)', 'text', true ); ?>
						<?php
						// Πρόταση δίπλα στο πεδίο, ΠΟΤΕ αυτόματο γέμισμα -- ρητή απόφαση
						// ιδιοκτήτη 01/09 (στάδιο 3 της μηχανής εγγυήσεων, CHANGELOG (212)).
						// Άδειο μέχρι να απαντήσει το GET /guarantee/suggest (ecrm-form.js:
						// refreshGuaranteeSuggestion()) -- hidden by default ώστε καμία
						// αναλαμπή να μη φανεί πριν προλάβει η πρώτη κλήση.
						?>
						<div class="ecrm-guarantee-suggest" data-guarantee-suggest hidden>
							<span data-guarantee-suggest-text></span>
							<button type="button" class="ecrm-guarantee-suggest__btn" data-guarantee-suggest-use hidden>Χρήση</button>
						</div>
					</div>
					<?php $ecrm_field( 'ar_koinoxristou', 'Αρ. Κοινόχρηστου Μετρητή', 'text', true, '', 'power,gas' ); ?>
				</div>

				<?php
				// Η διεύθυνση αποστολής λογαριασμού μετακόμισε εδώ 2026-09-01
				// (ίδιο μοτίβο με την εγγύηση, λίγο πιο πάνω): το πεδίο ζούσε
				// μέσα στα Στοιχεία Μετρητή, κλειδωμένο πίσω από
				// data-when-energy="power,gas", άρα αόρατο σε αίτηση κινητής --
				// παρόλο που οι στήλες billing_street/billing_city/κλπ ήταν ήδη
				// πραγματικές στήλες της βάσης, όχι νέο πεδίο. Κανένα από τα
				// τέσσερα έντυπα Orizon δεν ζητούσε τη διεύθυνση αποστολής μέχρι
				// τώρα -- βλ. CHANGELOG (208).
				?>
				<div class="ecrm-subhead">Διεύθυνση Αποστολής Λογαριασμού</div>
				<label class="ecrm-syncbar">
					<input type="checkbox" name="billing_addr_same" value="1" data-addr-same="billing" checked>
					Ίδια με τη διεύθυνση του πελάτη
				</label>
				<div class="ecrm-grid" data-addr-fields="billing" hidden>
					<?php $ecrm_field( 'billing_street', 'Οδός', 'text', false, '', '', 'section-bill billing address-line1' ); ?>
					<?php $ecrm_field( 'billing_street_no', 'Αριθμός' ); ?>
					<div class="ecrm-field-with-suggest">
						<?php $ecrm_field( 'billing_postal_code', 'Τ.Κ', 'text', false, '', '', 'section-bill billing postal-code' ); ?>
						<div class="ecrm-postal-suggest" data-tk-suggest="billing" hidden>
							<span data-tk-suggest-text="billing"></span>
							<button type="button" class="ecrm-postal-suggest__btn" data-tk-suggest-use="billing" hidden>Χρήση</button>
						</div>
					</div>
					<?php $ecrm_field( 'billing_city', 'Πόλη', 'text', false, '', '', 'section-bill billing address-level2' ); ?>
					<?php $ecrm_field( 'billing_region', 'Νομός', 'text', false, '', '', 'section-bill billing address-level1' ); ?>
				</div>

				<?php
				// Απαντήσεις του πελάτη, όχι ρυθμίσεις της εταιρείας. Το
				// 'bill_cap'/'anotato_orio' είναι μόνο ρεύμα/αέριο (η κινητή έχει
				// δικό της 'mobile_bill_cap', βλ. (265)) — πριν ζούσαν μέσα στο
				// τμήμα κινητής, όπου ήταν ακριβώς ανάποδα ορατά: φαινόντουσαν
				// μόνο όταν δεν εξυπηρετούσαν κανέναν. Το 'no_marketing_calls'
				// (268) είναι πλέον ΚΑΙ mobile -- το orizon_mobile.json τυπώνει
				// τη δήλωση άρθρου 11 στη σελ.5 -- οπότε το gate έφυγε από το
				// γονικό div και πήγε ανά πεδίο (ίδιο μοτίβο με το «Διάρκεια
				// Σύμβασης» παρακάτω), ώστε το καθένα να δηλώνει τη δική του
				// ορατότητα αντί να την κληρονομεί σιωπηλά.
				?>
				<div class="ecrm-subhead">Ερωτήσεις προς τον πελάτη <span class="ecrm-hint">— απαντά ο ίδιος</span></div>
				<div class="ecrm-grid">
					<?php
					$ecrm_yesno( 'bill_cap', 'Θέλει ανώτατο όριο λογαριασμού;', 'power,gas' );
					$ecrm_field( 'anotato_orio', 'Ανώτατο Όριο (€)', 'text', true, '', 'power,gas' );
					$ecrm_yesno( 'no_marketing_calls', 'Μητρώο άρθρου 11 — να ΜΗΝ δέχεται προωθητικές κλήσεις;', 'power,gas,mobile' );
					$ecrm_yesno( 'group_data_consent', 'Συναινεί στην επεξεργασία δεδομένων από τον όμιλο;', 'power,gas' );
					// Χωριστή ερώτηση από την προηγούμενη: τα νέα οικιακά έντυπα
					// Protergia έχουν δικό τους ΝΑΙ/ΟΧΙ γι' αυτήν (όρος Η), και
					// συναίνεση που δεν τη ζήτησες δεν μπορείς να τη σημειώσεις.
					$ecrm_yesno( 'survey_consent', 'Δέχεται τηλεφωνικές έρευνες ικανοποίησης πελατών;', 'power,gas' );
					$ecrm_yesno( 'waive_withdrawal', 'Θέλει άμεση έναρξη, παραιτούμενος από το δικαίωμα υπαναχώρησης;', 'power,gas' );
					// (269): ίδια περίπτωση με το 'no_marketing_calls' παραπάνω -- το
					// orizon_mobile.json τυπώνει τη δήλωση καταλόγου στη σελ.6, οπότε
					// πλέον ΚΑΙ mobile.
					$ecrm_yesno( 'no_directory_listing', 'Να ΜΗΝ καταχωρηθεί στους τηλεφωνικούς καταλόγους;', 'power,gas,mobile' );
					?>
				</div>

				<?php
				// Το «Ημ. Έναρξης» έφυγε εντελώς 2026-08-24: κανένα από τα ~20
				// έντυπα δεν το τυπώνει ποτέ (επιβεβαιωμένο με grep σε όλα τα
				// JSON) — ζητούσε ημερομηνία που δεν πήγαινε πουθενά, ίδιο σχήμα
				// με το IBAN της (78). Η στήλη `start_date` ΜΕΝΕΙ στη βάση: την
				// ξαναγράφει το backend στις ανανεώσεις (`RenewalsController`).
				//
				// Το «Διάρκεια Σύμβασης» κρύβεται μόνο για mobile (Orizon): το
				// `orizon_*.json` δεν έχει `diarkeia_symvasis` σε κανένα από τα
				// τέσσερα πρότυπά του — το «24 ΜΗΝΕΣ» στο χαρτί είναι στατικό
				// κείμενο. Παραμένει αναγκαίο για nrg_fa/nrg_he/volton_fa/
				// volton_he, οπότε δεν φεύγει το πεδίο, μόνο κρύβεται με
				// data-when-energy. Το «Ημ. Λήξης» ΔΕΝ κρύβεται — το
				// `orizon_mobile.json` το τυπώνει («imerominia_liksis»), οπότε
				// μένει ελεύθερα επεξεργάσιμο ώστε ο πράκτορας να το γράφει με
				// το χέρι όταν η αυτόματη πρόταση (Έναρξη+Διάρκεια) δεν τρέχει.
				?>
				<div class="ecrm-subhead">Διάρκεια Σύμβασης</div>
				<div class="ecrm-grid">
					<label class="ecrm-field" data-for="term_months" data-when-energy="power,gas">
						<span class="ecrm-field__label">Διάρκεια Σύμβασης</span>
						<select name="term_months" class="ecrm-input">
							<option value="">—</option>
							<option value="0">Αορίστου</option>
							<option value="6">6 μήνες</option>
							<option value="12">12 μήνες</option>
							<option value="18">18 μήνες</option>
							<option value="24">24 μήνες</option>
							<option value="36">36 μήνες</option>
						</select>
					</label>
					<?php $ecrm_field( 'end_date', 'Ημ. Λήξης', 'date' ); ?>
				</div>
				<p class="ecrm-hint" data-term-hint>Αν συμπληρώσεις Έναρξη + Διάρκεια, η Λήξη υπολογίζεται αυτόματα.</p>
			</section>

			</div>

			<div class="ecrm-wstep" data-wstep="4" hidden>

			<!-- Ενέργειες σύμβασης -->
			<?php
			// Επιλογέας ρόλου, ΜΟΝΟ όταν η αίτηση είναι COMBO με δύο πρόσωπα --
			// 3β-Γ, 04/09/2026, δεύτερο σημείο. Το ίδιο dialog της καρτέλας
			// σύμβασης (ecrm-view-detail.js) το έχει ήδη· αυτό εδώ είναι η
			// δεύτερη, παλιότερη διαδρομή αποστολής (Βήμα 4 της ίδιας της
			// φόρμας) που έμενε αγνοώντας ρόλους -- ο πωλητής δεν είχε τρόπο να
			// στοχεύσει τον πελάτη ενέργειας από εδώ, μόνο τον κινητής (δες
			// docs/CHANGELOG.md, εγγραφή για το εύρημα). Κρυμμένο εξαρχής,
			// το γεμίζει/δείχνει η renderSignWho() στο ecrm-form.js.
			?>
			<div class="ecrm-whopick-wrap" data-signwho hidden>
				<p class="ecrm-whopick__lbl">Σε ποιον από τους δύο;</p>
				<div class="ecrm-whopick" data-signwho-btns></div>
			</div>
			<div class="ecrm-actbanners">
				<button type="button" class="ecrm-actbanner ecrm-actbanner--primary" data-act="pdf">
					<span class="ecrm-actbanner__ic"><svg class="ecrm-i ecrm-i--banner" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 9V3h10v6M7 18H5a2 2 0 01-2-2v-4a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2h-2M7 15h10v6H7z"/></svg></span>
					<span class="ecrm-actbanner__tx"><b>Εκτύπωση Σύμβασης</b><span>Δημιουργείται αυτόματα το PDF του συμβολαίου με τα στοιχεία της φόρμας</span></span>
				</button>
				<button type="button" class="ecrm-actbanner ecrm-actbanner--dark" data-act="email">
					<span class="ecrm-actbanner__ic"><svg class="ecrm-i ecrm-i--banner" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18v12H3zM3 7l9 6 9-6"/></svg></span>
					<span class="ecrm-actbanner__tx"><b>Αποστολή στον πελάτη για ηλεκτρονική υπογραφή</b><span>Στέλνεται email στον πελάτη με σύνδεσμο υπογραφής</span></span>
				</button>
				<button type="button" class="ecrm-actbanner ecrm-actbanner--outline" data-act="livelink">
					<span class="ecrm-actbanner__ic"><svg class="ecrm-i ecrm-i--banner" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-1.5 1.5M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l1.5-1.5"/></svg></span>
					<span class="ecrm-actbanner__tx"><b>Δημιουργία συνδέσμου για live υπογραφή</b><span>Σύνδεσμος για υπογραφή επί τόπου ή αποστολή με μήνυμα</span></span>
				</button>
			</div>

			<section class="ecrm-card">
				<div class="ecrm-step"><span class="ecrm-step__n">8</span> Σχόλια Αίτησης</div>
				<textarea class="ecrm-textarea" data-notes name="notes" rows="3" placeholder="Επιπλέον σημειώσεις…"></textarea>
			</section>

			</div>

			<footer class="ecrm-foot">
				<?php
				// Ticked by default: the agent is with the customer when they
				// fill this in and consent is part of that conversation, so the
				// box was being ticked on every single application anyway.
				//
				// What it therefore stops being is evidence. It records the
				// agent's assertion and the agent's IP, not the customer's, and
				// a field that is always true demonstrates nothing. The consent
				// that counts is the one the customer ticks themselves on the
				// signing page (ECRM_Tracking) — their own tick, their own IP,
				// their own timestamp. That one stays untouched and unticked.
				?>
				<label class="ecrm-consent"><input type="checkbox" data-consent name="consent" value="1" checked> Ο πελάτης ενημερώθηκε και συναινεί στην επεξεργασία των προσωπικών του δεδομένων για τη σύναψη/διαχείριση της σύμβασης (GDPR), συμπεριλαμβανομένης της αυτόματης ανάγνωσης των εγγράφων που υποβάλλει (ταυτότητα, λογαριασμός) από εξωτερική υπηρεσία τεχνητής νοημοσύνης.</label>
				<div class="ecrm-foot__actions">
					<?php
					/*
					 * Three buttons, of which the agent ever sees two — which
					 * pair depends on the stage, and ecrm-form.js setStage()
					 * decides. Nothing transitions TO draft in ContractStatus,
					 * and only draft transitions to new, so the first two are
					 * legal in exactly one situation: an application that is
					 * unsaved or still a draft. Past that, editing a field is
					 * still allowed — it is not a transition at all — and that
					 * is what the third one does, by sending no status.
					 */
					?>
					<button type="button" class="ecrm-btn ecrm-btn--ghost" data-wprev hidden><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg> Πίσω</button>
					<button type="button" class="ecrm-btn ecrm-btn--ghost" data-save-draft>Προσωρινή Αποθήκευση</button>
					<button type="button" class="ecrm-btn ecrm-btn--primary" data-wnext>Συνέχεια <svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
					<button type="button" class="ecrm-btn ecrm-btn--primary" data-finalize hidden>Οριστικοποίηση</button>
					<button type="button" class="ecrm-btn ecrm-btn--primary" data-save-changes hidden>Αποθήκευση Αλλαγών</button>
				</div>
			</footer>
			</div><!-- /.ecrm-wizmain -->

			<!-- «Γρήγορη σύνοψη» -- ζητήθηκε ρητά 30/08 (screenshot εξωτερικού
			     εργαλείου), για να ξέρει ο συνεργάτης πού βρίσκεται χωρίς να
			     ανεβοκατεβαίνει τη φόρμα. Καθαρά στατικό markup εδώ -- το γεμίζει
			     και το ενημερώνει το updateSummary() του ecrm-form.js σε κάθε
			     αλλαγή πεδίου, ίδια πεδία με τη φόρμα, καμία δική του κλήση στο
			     API. Ίδιο οπτικό λεξιλόγιο με το προϊόν: .ecrm-meter (dashboard)
			     και .ecrm-rcheck (κάρτα σύμβασης), όχι νέο στυλ. -->
			<aside class="ecrm-summary" data-summary aria-label="Γρήγορη σύνοψη αίτησης">
				<p class="ecrm-summary__title">Γρήγορη σύνοψη</p>
				<p class="ecrm-summary__sub">Ενημερώνεται αυτόματα καθώς συμπληρώνεις τη φόρμα.</p>

				<dl class="ecrm-summary__rows">
					<div class="ecrm-summary__row"><dt>Πελάτης</dt><dd data-sum="customer" class="is-empty">—</dd></div>
					<div class="ecrm-summary__row"><dt>Περιοχή</dt><dd data-sum="region" class="is-empty">—</dd></div>
					<div class="ecrm-summary__row"><dt>Πάροχος</dt><dd data-sum="provider" class="is-empty">—</dd></div>
					<div class="ecrm-summary__row"><dt>Πρόγραμμα</dt><dd data-sum="program" class="is-empty">—</dd></div>
				</dl>

				<div class="ecrm-meter"><span class="ecrm-meter__f" data-sum-fill style="width:0%"></span></div>
				<div class="ecrm-summary__pct"><span>Πληρότητα αίτησης</span><b data-sum-pct>0%</b></div>

				<ul class="ecrm-rcheck">
					<li data-sumcheck="providerProgram"><span class="ecrm-rcheck__m">○</span>Πάροχος &amp; πρόγραμμα</li>
					<li data-sumcheck="identity"><span class="ecrm-rcheck__m">○</span>Στοιχεία ταυτότητας</li>
					<li data-sumcheck="afmAdt"><span class="ecrm-rcheck__m">○</span>ΑΦΜ / ΑΔΤ</li>
					<li data-sumcheck="address"><span class="ecrm-rcheck__m">○</span>Διεύθυνση</li>
					<li data-sumcheck="contact"><span class="ecrm-rcheck__m">○</span>Στοιχεία επικοινωνίας</li>
				</ul>

				<p class="ecrm-summary__foot" data-sum-step>Βήμα 1 από 4</p>
			</aside>
			</div><!-- /.ecrm-layout -->
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
