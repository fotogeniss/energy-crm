<?php
/**
 * Public application-tracking page (courier-style).
 *
 * The customer opens ?ecrm_track=TOKEN (no login) and sees a friendly,
 * stage-based progress view of their application — code, provider, energy
 * type, current stage, last update. No internal notes/events are exposed.
 *
 * Tokens are stateless: {id}-{hmac}. No DB column, cannot be enumerated or
 * forged without the site auth salt. ECRM_Tracking::url() builds the link,
 * and ECRM_Messaging exposes it to templates as {track}.
 *
 * @package EnergyCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ECRM_Tracking {

	public static function init(): void {
		add_action( 'template_redirect', [ __CLASS__, 'maybe_render' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	public static function routes(): void {
		register_rest_route( \EnergyCRM\Http\Router::NAMESPACE, '/track/(?P<token>[A-Za-z0-9\-]+)', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_get' ],
			'permission_callback' => '__return_true',
		] );
		register_rest_route( \EnergyCRM\Http\Router::NAMESPACE, '/track/(?P<token>[A-Za-z0-9\-]+)/sign', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_sign' ],
			'permission_callback' => '__return_true',
		] );
		register_rest_route( \EnergyCRM\Http\Router::NAMESPACE, '/track/(?P<token>[A-Za-z0-9\-]+)/upload', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'rest_upload' ],
			'permission_callback' => '__return_true',
		] );
	}

	// --- Token ανά σύμβαση, ανακλητό ----------------------------------------

	/**
	 * Ο σύνδεσμος μιας σύμβασης. Παράγει κλειδί αν δεν υπάρχει ήδη.
	 *
	 * Ως τις 19/08/2026 το token ήταν `{id}-{hmac(id, salt)}`: καθαρό, χωρίς
	 * βάση, μη απαριθμήσιμο — και **αιώνιο**. Ο ίδιος σύνδεσμος για την ίδια
	 * σύμβαση, για πάντα, και ο μόνος τρόπος να ακυρωθεί ήταν να αλλάξει το
	 * `wp_salt('auth')`, που ακυρώνει όλους και πετάει έξω κάθε συνδεδεμένο
	 * χρήστη του WordPress.
	 *
	 * Τώρα στο υλικό του HMAC μπαίνει και ένα κλειδί που ανήκει στη σύμβαση.
	 * Ανάκληση ενός συνδέσμου = νέο κλειδί σε μία γραμμή· όλοι οι άλλοι ζουν.
	 *
	 * Χάθηκε η ιδιότητα «δεν αγγίζει τη βάση» — μία ανάγνωση με πρωτεύον
	 * κλειδί. Είναι το τίμημα της ανάκλησης, και είναι το ζητούμενο.
	 *
	 * Από 04/09 (3β-Β) δέχεται και ρόλο -- στο SignatureRoles::MOBILE
	 * (προεπιλογή) παράγει ΑΚΡΙΒΩΣ το ίδιο token με πριν, byte για byte:
	 * κάθε σύνδεσμος που έχει ήδη σταλεί συνεχίζει να δουλεύει αναλλοίωτος.
	 * Ο ρόλος ENERGY παίρνει διαφορετικό υλικό υπογραφής (και δεν θα
	 * μπορούσε να μπερδευτεί με το MOBILE — δες verify()).
	 */
	public static function token( int $id, string $role = \EnergyCRM\Domain\Contract\SignatureRoles::MOBILE ): string {
		$key = self::key_for( $id );
		return $key === '' ? '' : self::sign( $id, $key, $role );
	}

	/**
	 * Το id ΚΑΙ ο ρόλος πίσω από ένα token, ή null.
	 *
	 * **Ποτέ δεν παράγει κλειδί.** Η διαδρομή είναι ανώνυμη και δημόσια· αν
	 * παρήγαγε, μια αίτηση σε τυχαίο id θα προκαλούσε εγγραφή στη βάση, δηλαδή
	 * θα έδινε σε οποιονδήποτε τρόπο να γεμίσει τον πίνακα. Σύμβαση χωρίς
	 * κλειδί δεν έχει έγκυρο σύνδεσμο, τελεία.
	 *
	 * Δύο μορφές: `{id}-{hmac}` (MOBILE, η ιστορική μορφή, αναλλοίωτη) και
	 * `{id}-e-{hmac}` (ENERGY, νέα). Δεν υπάρχει σύγκρουση: το δεύτερο 'e'
	 * σπάει τον πρώτο κανόνα (ακριβώς 20 hex ψηφία μετά την παύλα), οπότε ένα
	 * MOBILE token δεν μπορεί ποτέ να διαβαστεί σαν ENERGY και αντίστροφα.
	 *
	 * @return array{id:int, role:string}|null
	 */
	public static function verify( string $token ): ?array {
		if ( preg_match( '/^(\d+)-([a-f0-9]{20})$/', $token, $m ) ) {
			$id   = (int) $m[1];
			$role = \EnergyCRM\Domain\Contract\SignatureRoles::MOBILE;
			$key  = self::stored_key( $id );

			return ( $key !== '' && hash_equals( self::sign( $id, $key, $role ), $token ) )
				? [ 'id' => $id, 'role' => $role ]
				: null;
		}

		if ( preg_match( '/^(\d+)-e-([a-f0-9]{20})$/', $token, $m ) ) {
			$id   = (int) $m[1];
			$role = \EnergyCRM\Domain\Contract\SignatureRoles::ENERGY;
			$key  = self::stored_key( $id );

			return ( $key !== '' && hash_equals( self::sign( $id, $key, $role ), $token ) )
				? [ 'id' => $id, 'role' => $role ]
				: null;
		}

		return null;
	}

	/**
	 * Ακυρώνει τον σύνδεσμο μιας σύμβασης.
	 *
	 * Ο επόμενος που θα ζητήσει σύνδεσμο παίρνει καινούργιο· ο παλιός δεν
	 * ξαναδουλεύει ποτέ. Ακυρώνει ΚΑΙ ΤΑ ΔΥΟ token (MOBILE και ENERGY) μαζί
	 * -- μοιράζονται το ίδιο track_key, οπότε δεν υπάρχει τρόπος να
	 * ανακληθεί το ένα χωρίς το άλλο, ούτε λόγος: η ανάκληση σημαίνει «αυτός
	 * ο σύνδεσμος διέρρευσε», κάτι που αφορά τη σύμβαση, όχι τον ρόλο.
	 */
	public static function revoke( int $id ): void {
		global $wpdb;
		$ct = ECRM_DB::table( 'contracts' );
		// Ρητό ερώτημα και όχι $wpdb->update(): εκείνη δεν γράφει NULL — τα
		// null στα δεδομένα τα προσπερνά, οπότε η ανάκληση θα «πετύχαινε»
		// αφήνοντας το κλειδί στη θέση του. Σιωπηλή αποτυχία σε λειτουργία
		// ασφαλείας είναι το χειρότερο είδος.
		$wpdb->query( $wpdb->prepare( "UPDATE {$ct} SET track_key = NULL WHERE id = %d", $id ) );
	}

	private static function sign( int $id, string $key, string $role = \EnergyCRM\Domain\Contract\SignatureRoles::MOBILE ): string {
		if ( $role === \EnergyCRM\Domain\Contract\SignatureRoles::ENERGY ) {
			$sig = substr( hash_hmac( 'sha256', 'ecrm_track_' . $id . '|' . $role . '|' . $key, wp_salt( 'auth' ) ), 0, 20 );
			return $id . '-e-' . $sig;
		}

		// MOBILE: ΙΔΙΟ υλικό υπογραφής με πριν την ύπαρξη ρόλων -- δεν
		// αλλάζει, ώστε κάθε ήδη σταλμένος σύνδεσμος να συνεχίσει να ισχύει.
		$sig = substr( hash_hmac( 'sha256', 'ecrm_track_' . $id . '|' . $key, wp_salt( 'auth' ) ), 0, 20 );
		return $id . '-' . $sig;
	}

	/** Το αποθηκευμένο κλειδί, χωρίς να παραχθεί τίποτα. */
	private static function stored_key( int $id ): string {
		global $wpdb;
		if ( $id <= 0 ) {
			return '';
		}
		$ct = ECRM_DB::table( 'contracts' );
		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT track_key FROM {$ct} WHERE id = %d", $id ) );
	}

	/**
	 * Το κλειδί της σύμβασης, φτιαγμένο αν λείπει.
	 *
	 * Η διεκδίκηση είναι μέσα στο `UPDATE`, με το `track_key IS NULL` ως
	 * συνθήκη, και μετά ξαναδιαβάζεται ό,τι όντως γράφτηκε. Ο λόγος δεν είναι
	 * θεωρητικός: το `ContractsReadController` χτίζει `track_url` σε **κάθε**
	 * άνοιγμα καρτέλας, οπότε δύο ταυτόχρονα αιτήματα θα έγραφαν δύο κλειδιά
	 * και ο σύνδεσμος του πρώτου θα έπαυε να ισχύει σιωπηλά — ακριβώς το σχήμα
	 * που έκλεισε στη δημιουργία εκκαθάρισης.
	 */
	private static function key_for( int $id ): string {
		global $wpdb;
		if ( $id <= 0 ) {
			return '';
		}

		$existing = self::stored_key( $id );
		if ( $existing !== '' ) {
			return $existing;
		}

		$ct = ECRM_DB::table( 'contracts' );
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$ct} SET track_key = %s WHERE id = %d AND ( track_key IS NULL OR track_key = '' )",
			wp_generate_password( 24, false ),
			$id
		) );

		return self::stored_key( $id );
	}

	public static function url( int $id, string $role = \EnergyCRM\Domain\Contract\SignatureRoles::MOBILE ): string {
		$token = self::token( $id, $role );
		return $token === '' ? '' : add_query_arg( 'ecrm_track', $token, home_url( '/' ) );
	}

	// --- Customer-friendly stages -------------------------------------------

	/** Ordered journey shown to the customer. */
	public static function stages(): array {
		return [ 'Καταχώρηση', 'Περιμένει υπογραφή', 'Αποστολή SIM', 'Οριστικοποίηση', 'Ενεργοποίηση' ];
	}

	/** Statuses where the customer is allowed to e-sign from the tracking link. */
	public static function signable_statuses(): array {
		return [ 'awaiting_signature' ];
	}

	/**
	 * Πόσο μένει ανοιχτό το παράθυρο υπογραφής, σε ώρες.
	 *
	 * **Απόφαση ιδιοκτήτη 22/08: 48 ώρες.** Είχα προτείνει 7 μέρες και ο λόγος
	 * μένει γραμμένος επειδή θα ξαναϊσχύσει: πώληση Παρασκευή απόγευμα,
	 * υπογραφή Δευτέρα πρωί, είναι **62 ώρες** — με 48ωρο ο σύνδεσμος πεθαίνει
	 * Κυριακή βράδυ. Το μετριάζει το «Ξαναστείλε», που ξανανοίγει το παράθυρο.
	 * Αν φανεί στην πράξη, εδώ αλλάζει, μία γραμμή.
	 * Ανάλυση: docs/UI-SIGN-EXPIRY.html.
	 */
	public const SIGN_WINDOW_HOURS = 48;

	/**
	 * Τα γεγονότα που ξεκινούν το ρολόι.
	 *
	 * Γράφονται από τον SignLinkController σε ΚΑΘΕ αποστολή — γι' αυτό το
	 * «Ξαναστείλε» μηδενίζει το ρολόι. Το `status_change` ΔΕΝ θα έκανε: το
	 * ContractLifecycle::moveTo() επιστρέφει σιωπηλά true χωρίς να γράψει
	 * τίποτα όταν η σύμβαση είναι ήδη εκεί, οπότε η δεύτερη αποστολή δεν θα
	 * άφηνε ίχνος και το ρολόι θα έμενε κολλημένο στην πρώτη.
	 */
	private const SEND_EVENTS = [ 'sign_sent_sms', 'sign_sent_email', 'sign_sent_link' ];

	/**
	 * Έληξε το παράθυρο υπογραφής;
	 *
	 * **Καμία αποστολή καταγεγραμμένη σημαίνει καμία προθεσμία.** Οι συμβάσεις
	 * που πήραν σύνδεσμο πριν την (79) δεν έχουν τέτοιο γεγονός· ένα SMS που
	 * έχει ήδη φύγει δεν πεθαίνει επειδή αλλάξαμε εμείς κώδικα. Το ρολόι τους
	 * ξεκινά την πρώτη φορά που κάποιος πατήσει «Αποστολή» ή «Ξαναστείλε» —
	 * χωρίς backfill, και χωρίς μέρα όπου παλιοί σύνδεσμοι πεθαίνουν μαζικά.
	 * Αυτό ακριβώς κρατούσε ανοιχτό το §6γ (7).
	 */
	public static function sign_expired( int $contract_id ): bool {
		$hours = ( new \EnergyCRM\Persistence\EventRepository() )
			->hoursSinceLastOfTypes( $contract_id, self::SEND_EVENTS );

		return $hours !== null && $hours >= self::SIGN_WINDOW_HOURS;
	}

	/** Map an internal status to a stage index (0-based) or -1 if cancelled. */
	public static function stage_index( string $status ): int {
		// Το `awaiting_sim` παίρνει δικό του βήμα (07/09): για τον πελάτη που
		// περιμένει courier ΕΙΝΑΙ ξεχωριστό βήμα, και η αίτηση χωρίς κινητή
		// απλώς το προσπερνά -- η μπάρα δείχνει 3 από 5 αντί για 2, που είναι
		// η αλήθεια για εκείνη τη σύμβαση.
		$map = [
			'draft'              => 0,
			'presale'            => 0,
			'registration'       => 0,
			'awaiting_signature' => 1,
			'signature_complete' => 2,
			'awaiting_sim'       => 2,
			'sim_delivered'      => 2,
			'to_finalisation'    => 3,
			'finalisation'       => 3,
			'active'             => 4,
		];

		// 05/10/2026: μία τερματική, η «Ακυρώθηκε». Οι υπόλοιπες νέες
		// (ΘΑΛΗΣ, Εκκρεμότητα, Επανέλεγχος, Οφειλή, For review, MP reject)
		// συμβαίνουν αφού η αίτηση έχει φύγει από τη δική μας πλευρά, οπότε
		// για τον πελάτη είναι το βήμα «στον πάροχο».
		if ( 'cancelled' === $status ) {
			return -1;
		}
		return $map[ $status ] ?? 3;
	}

	/** Allowed upload MIME types → file extension. */
	public static function upload_types(): array {
		return [
			'image/jpeg'      => 'jpg',
			'image/png'       => 'png',
			'image/webp'      => 'webp',
			'image/heic'      => 'heic',
			'application/pdf' => 'pdf',
		];
	}

	/**
	 * Build the customer-facing document payload for a contract: the required
	 * checklist (kind, label, done) plus whether uploads are currently accepted.
	 *
	 * @return array{items:array,complete:bool,can_upload:bool}
	 */
	public static function docs_payload( int $id, string $status, ?string $activation_type, ?string $energy_type = null ): array {
		$can = ! in_array( $status, [ 'cancelled', 'active' ], true );
		if ( ! class_exists( 'ECRM_Docs' ) ) {
			return [ 'items' => [], 'complete' => true, 'can_upload' => $can ];
		}
		$cl = ECRM_Docs::checklist( $id, (string) $activation_type, $energy_type );
		$items = [];
		foreach ( $cl['items'] as $it ) {
			$items[] = [ 'kind' => $it['kind'], 'label' => $it['label'], 'done' => ! empty( $it['ok'] ) ];
		}
		return [ 'items' => $items, 'complete' => ! empty( $cl['complete'] ), 'can_upload' => $can ];
	}

	/**
	 * Ποιοι ρόλοι πρέπει να υπογράψουν αυτή τη σύμβαση, και ποιοι το έχουν
	 * ήδη κάνει -- μεσολαβεί το `EnergyCRM\Infrastructure\SignatureState`,
	 * που είναι το ΜΟΝΟ σημείο που ενώνει το `SignatureRoles` (κανόνας) με
	 * τα αρχεία (ποιος έχει ΉΔΗ υπογράψει). Ίδιο αντικείμενο χρησιμοποιεί
	 * και το `SignLinkController` -- δες το docblock του `SignatureState`
	 * για το γιατί δεν αντιγράφεται εδώ.
	 *
	 * @param array<string, mixed> $row Πρέπει να έχει `extra_json`.
	 *
	 * @return array{required:list<string>, collected:list<string>, complete:bool}
	 */
	private static function signature_state( int $id, array $row ): array {
		return \EnergyCRM\Services::signatureState()->forContract( $id, $row );
	}

	// --- REST: tracking payload ---------------------------------------------

	public static function rest_get( WP_REST_Request $req ): WP_REST_Response {
		if ( class_exists( 'ECRM_RateLimit' ) && ! ECRM_RateLimit::allow( 'track', 60, 300 ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'too_many' ], 429 );
		}
		$v = self::verify( (string) $req['token'] );
		if ( ! $v ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'invalid_token' ], 404 );
		}
		$id   = $v['id'];
		$role = $v['role'];
		global $wpdb;
		$ct = ECRM_DB::table( 'contracts' );
		$cu = ECRM_DB::table( 'customers' );
		$pr = ECRM_DB::table( 'providers' );
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT c.code, c.status, c.energy_type, c.activation_type, c.updated_at, c.created_at, c.signed_at, c.extra_json,
			        p.name AS provider_name,
			        cu.first_name, cu.last_name, cu.company_name
			 FROM {$ct} c
			 LEFT JOIN {$cu} cu ON cu.id = c.customer_id
			 LEFT JOIN {$pr} p  ON p.id  = c.provider_id
			 WHERE c.id = %d", $id
		), ARRAY_A );
		if ( ! $row ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'not_found' ], 404 );
		}

		$status = (string) $row['status'];
		$idx    = self::stage_index( $status );
		$labels = ECRM_DB::statuses();
		$name   = $row['company_name'] ?: trim( ( $row['first_name'] ?? '' ) . ' ' . ( $row['last_name'] ?? '' ) );

		// Από 04/09 (3β-Β): «υπέγραψε» και «μπορεί να υπογράψει» είναι ανά
		// ΡΟΛΟ, όχι ανά σύμβαση -- ένα COMBO με δύο πρόσωπα έχει δύο
		// συνδέσμους, και ο καθένας βλέπει ΜΟΝΟ τη δική του κατάσταση. Για
		// την κοινή περίπτωση (ένας μόνο απαιτούμενος ρόλος) αυτό συμπίπτει
		// ΑΚΡΙΒΩΣ με το παλιό `! empty( $row['signed_at'] )`, γιατί τότε η
		// σύμβαση ολοκληρώνεται τη στιγμή που υπογράφει ο μοναδικός ρόλος.
		$state         = self::signature_state( $id, $row );
		$role_required = in_array( $role, $state['required'], true );
		$role_signed   = in_array( $role, $state['collected'], true );
		$waiting_other = $role_signed && ! $state['complete'];
		$signable      = in_array( $status, self::signable_statuses(), true );
		$expired       = self::sign_expired( $id );

		return new WP_REST_Response( [
			'ok'           => true,
			'code'         => $row['code'] ?: '—',
			'provider'     => $row['provider_name'] ?: '—',
			'energy'       => ECRM_DB::energy_label( (string) $row['energy_type'] ),
			'customer'     => $name ?: '—',
			'status_label' => $labels[ $status ] ?? $status,
			'cancelled'    => ( $idx < 0 ),
			'stage'        => max( 0, $idx ),
			'stages'       => self::stages(),
			'updated_at'   => $row['updated_at'],
			'created_at'   => $row['created_at'],
			// «Υπέγραψα εγώ», όχι «υπέγραψαν όλοι» -- δες το σχόλιο πάνω.
			'signed'            => $role_signed,
			// Νέο: υπέγραψα, αλλά η αίτηση περιμένει ακόμα τον άλλο ρόλο.
			// Μόνο η σελίδα το χρειάζεται (άλλο κείμενο από το απλό «✓»),
			// η ολοκλήρωση της ΣΥΜΒΑΣΗΣ ήδη φαίνεται στο status_label.
			'waiting_other'     => $waiting_other,
			// Η λήξη είναι ΤΡΙΤΟΣ όρος, όχι νέα διαδρομή: η σελίδα ζωγραφίζει
			// το πάνελ υπογραφής μόνο όταν αυτό είναι αληθές, οπότε το
			// tracking μένει ανέπαφο — αυτό ήταν όλο το ζητούμενο.
			'can_sign'     => ( $signable && $role_required && ! $role_signed && ! $expired ),
			'sign_expired' => ( $signable && $role_required && ! $role_signed && $expired ),
			'docs'         => self::docs_payload( $id, $status, $row['activation_type'] ?? '', $row['energy_type'] ?? '' ),
			'company'      => class_exists( 'ECRM_Admin' ) ? (string) ECRM_Admin::get( 'company_name' ) : '',
		], 200 );
	}

	// --- REST: customer e-signature ----------------------------------------


	public static function rest_sign( WP_REST_Request $req ): WP_REST_Response {
		if ( class_exists( 'ECRM_RateLimit' ) && ! ECRM_RateLimit::allow( 'track_sign', 10, 600 ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Πολλές προσπάθειες. Δοκιμάστε αργότερα.' ], 429 );
		}
		$v = self::verify( (string) $req['token'] );
		if ( ! $v ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Μη έγκυρος σύνδεσμος.' ], 404 );
		}
		$id   = $v['id'];
		$role = $v['role'];

		/*
		 * ΠΡΙΝ από κάθε έλεγχο του φορτίου, και αυτό δεν είναι λεπτομέρεια.
		 *
		 * Πρώτη γραφή τον είχε πιο κάτω, μαζί με τον έλεγχο κατάστασης. Το
		 * βρήκε test: με ληγμένο σύνδεσμο και κακοσχηματισμένη υπογραφή, η
		 * απάντηση ήταν «Μη έγκυρη υπογραφή» — δηλαδή ο πελάτης μάθαινε για
		 * το PNG του αντί για τον πραγματικό λόγο. Το ίδιο θα γινόταν και με
		 * ξεχασμένο checkbox συναίνεσης.
		 *
		 * Η λήξη είναι προϋπόθεση του ΠΟΡΟΥ, όχι της εισόδου: «επιτρέπεται
		 * ακόμη να υπογραφεί αυτό;» απαντιέται πριν από «τι μου έστειλες;».
		 * Ολόκληρη η παρτίδα είναι για το να λέγεται ο σωστός λόγος· θα ήταν
		 * περίεργο να τον κρύβει η ίδια.
		 *
		 * Ο έλεγχος γίνεται ΚΑΙ εδώ ΚΑΙ στο can_sign επίτηδες: εκείνο λέει
		 * στη σελίδα τι να ζωγραφίσει, αυτό εδώ το επιβάλλει. Καρτέλα ανοιχτή
		 * από προχθές δεν υπογράφει επειδή το κουμπί της είναι ακόμη εκεί.
		 */
		if ( self::sign_expired( $id ) ) {
			// 410 και όχι 400: ο σύνδεσμος ΗΤΑΝ έγκυρος, απλώς όχι πια.
			return new WP_REST_Response( [
				'ok'      => false,
				'expired' => true,
				'error'   => 'Ο σύνδεσμος υπογραφής έληξε. Ζητήστε νέον από τον συνεργάτη σας.',
			], 410 );
		}

		$p       = $req->get_json_params() ?: $req->get_params();
		$consent = ! empty( $p['consent'] );
		$dataurl = (string) ( $p['signature'] ?? '' );
		if ( ! $consent ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Απαιτείται η συναίνεσή σας.' ], 400 );
		}
		if ( ! preg_match( '#^data:image/png;base64,([A-Za-z0-9+/=]+)$#', $dataurl, $m ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Μη έγκυρη υπογραφή.' ], 400 );
		}
		$png = base64_decode( $m[1], true );
		if ( $png === false || strlen( $png ) < 200 || strlen( $png ) > 800000 || substr( $png, 0, 8 ) !== "\x89PNG\r\n\x1a\n" ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Μη έγκυρη υπογραφή.' ], 400 );
		}

		global $wpdb;
		$ct  = ECRM_DB::table( 'contracts' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ct} WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Δεν βρέθηκε η αίτηση.' ], 404 );
		}
		if ( ! in_array( $row['status'], self::signable_statuses(), true ) ) {
			return new WP_REST_Response( [ 'ok' => true, 'already' => true, 'message' => 'Η αίτηση δεν εκκρεμεί για υπογραφή ή έχει ήδη υπογραφεί.' ], 200 );
		}

		// 04/09 (3β-Β, δεύτερο εύρημα): το `! empty( $row['signed_at'] )` που
		// ζούσε εδώ μέχρι σήμερα έλεγχε τη ΛΑΘΟΣ ερώτηση -- "υπέγραψε ΠΟΤΕ
		// αυτή η σύμβαση πλήρως" αντί για "χρειάζεται ΤΩΡΑ υπογραφή από ΑΥΤΟΝ
		// τον ρόλο". Μια COMBO αίτηση που υπέγραψε πλήρως όσο ήταν ακόμα
		// μονο-προσωπική (ένας απαιτούμενος ρόλος) και μετά επεξεργάστηκε να
		// θέλει και δεύτερο, κρατά το παλιό `signed_at` -- το
		// `SignLinkController::create()` το καθαρίζει ΜΟΝΟ όταν ξαναστέλνει
		// σε ρόλο που ΕΙΧΕ ήδη υπογράψει (`confirm_resend`), όχι όταν στέλνει
		// σε νέο, ΑΚΟΜΑ ανυπόγραφο ρόλο. Αποτέλεσμα: ο πελάτης υπέγραφε εδώ,
		// έπαιρνε "ok" 200, και τίποτα δεν αποθηκευόταν ποτέ -- ο έλεγχος
		// έβγαινε πριν καν φτάσει στο σημείο που γράφει την υπογραφή.
		//
		// Ο ανά-ρόλο έλεγχος από κάτω (`SignatureState::forContract()`,
		// ίδιο σημείο αλήθειας με τον SignLinkController) είναι ήδη ακριβώς
		// αυτό που χρειάζεται: αν ο ρόλος έχει ΗΔΗ υπογράψει, "already"·
		// αλλιώς προχωράει. Δεν χρειάζεται δεύτερος, χοντρικός έλεγχος πάνω
		// από αυτόν -- απλώς έκρυβε τη σωστή απάντηση.
		$state = self::signature_state( $id, $row );
		if ( ! in_array( $role, $state['required'], true ) ) {
			return new WP_REST_Response( [ 'ok' => true, 'already' => true, 'message' => 'Δεν χρειάζεται υπογραφή από αυτόν τον σύνδεσμο.' ], 200 );
		}
		if ( in_array( $role, $state['collected'], true ) ) {
			return new WP_REST_Response( [ 'ok' => true, 'already' => true, 'message' => 'Έχετε ήδη υπογράψει.' ], 200 );
		}

		$now = current_time( 'mysql' );
		$ip  = \EnergyCRM\Infrastructure\RequestIp::current();

		// Persist the signature image (protected). Στο doc_kind ΤΟΥ ΡΟΛΟΥ --
		// SignatureRoles::kindFor(): 'signature' για MOBILE (η ιστορική τιμή,
		// αναλλοίωτη), 'signature_energy' για ENERGY.
		$sig_path = '';
		$kind     = \EnergyCRM\Domain\Contract\SignatureRoles::kindFor( $role );
		if ( class_exists( 'ECRM_Files' ) && $kind !== '' ) {
			$stored = ECRM_Files::put_bytes( $png, 'png', 'image/png', 'signature.png' );
			if ( $stored ) {
				$sig_path = $stored['path'];
				// Μέσω FileRepository και όχι με σκέτο insert. Μια σύμβαση έχει ΜΙΑ
				// υπογραφή ΑΝΑ ΡΟΛΟ, και η replaceKind() σβήνει πρώτα τα bytes της
				// παλιάς· ένα insert εδώ θα άφηνε το προηγούμενο σχέδιο στον δίσκο
				// χωρίς τίποτα να το δείχνει — ακριβώς η διαρροή για την οποία
				// γράφτηκε ο FileRepository, και που ως τώρα την απέτρεπε μόνο ο
				// έλεγχος signed_at δύο οθόνες πιο πάνω.
				\EnergyCRM\Services::files()->replaceKind(
					$id, $kind, 'signature.png', 'image/png', $stored['path']
				);
			}
		}

		// Ξαναχτίζει το συνημμένο έντυπο ΤΩΡΑ, ανεξάρτητα από το αν λείπει
		// ακόμα ο άλλος ρόλος -- ώστε η αποθηκευμένη έκδοση να δείχνει πάντα
		// τις υπογραφές που πράγματι υπάρχουν (ContractDocuments::store()
		// διαβάζει signaturesByRole() και αφήνει κενή τη θέση όποιου δεν
		// έχει υπογράψει ακόμα, δες CHANGELOG (221)).
		\EnergyCRM\Services::contractDocuments()->store( $id );

		$collected   = $state['collected'];
		$collected[] = $role;
		$complete    = \EnergyCRM\Domain\Contract\SignatureRoles::isComplete( $state['required'], $collected );

		if ( ! $complete ) {
			// Η αίτηση ΔΕΝ μετράει «υπογεγραμμένη» ώσπου να υπογράψουν όλοι
			// οι απαιτούμενοι ρόλοι -- ρητή απόφαση ιδιοκτήτη 04/09
			// (SignatureRoles::isComplete). Η σύμβαση μένει στην ίδια
			// κατάσταση, χωρίς signed_at/signed_ip -- ο,τι απομένει
			// παρακάτω (PDF υπογεγραμμένου, μετάβαση σε "signed", ειδοποίηση
			// συνεργάτη) τρέχει ΜΟΝΟ όταν ολοκληρωθεί η τελευταία υπογραφή.
			return new WP_REST_Response( [
				'ok'      => true,
				'message' => 'Ευχαριστούμε! Η υπογραφή σας καταχωρήθηκε. Περιμένουμε ακόμα την υπογραφή του δεύτερου προσώπου.',
			], 200 );
		}

		// Build a signed contract PDF (full customer + application data + signature).
		//
		// The joined row comes from the repository rather than from a fourth copy
		// of the same query written here. The copy that used to sit in this spot
		// selected the encrypted customer columns and handed them straight to the
		// renderer, so with ECRM_ENCRYPT_PII on this document — the signed one —
		// printed ciphertext where the ΑΦΜ belongs.
		//
		// Γνωστός περιορισμός, όχι αγγιγμένος εδώ: το ECRM_PDF::build() δέχεται
		// ΜΙΑ υπογραφή ($sig_path -- αυτού που μόλις ολοκλήρωσε, εδώ). Σε ένα
		// COMBO με δύο πρόσωπα, το "signed_pdf" θα δείξει μόνο τη ΤΕΛΕΥΤΑΙΑ
		// υπογραφή· το σωστό, ανά-ρόλο αποτέλεσμα ζει ήδη στο συνημμένο έντυπο
		// (contractDocuments()->store(), λίγο πιο πάνω, μέσω SignatureRoles).
		if ( class_exists( 'ECRM_PDF' ) ) {
			// Το fetch του $full μπήκε ΜΕΣΑ στο try 2026-08-24: ήταν έξω, οπότε
			// το σχόλιο «PDF optional — signing still succeeds» ήταν ψέμα ακριβώς
			// για το πιο σοβαρό είδος αποτυχίας — ένα undefined-method fatal σε
			// αυτή τη γραμμή (ECRM-9422, ORIZON-0003) σκότωνε ολόκληρο το
			// rest_sign() πριν προλάβει να προχωρήσει η κατάσταση σε "signed",
			// αν και η ίδια η υπογραφή είχε ήδη αποθηκευτεί από πάνω.
			$full = null;
			try {
				$full = \EnergyCRM\Services::contractDetails()->forDocument( $id );
				$pdf = ECRM_PDF::build( $full ?: $row, $sig_path ?: null, [ 'date' => gmdate( 'd/m/Y H:i' ), 'ip' => $ip ] );
				if ( $pdf && class_exists( 'ECRM_Files' ) ) {
					$sp = ECRM_Files::put_bytes( $pdf, 'pdf', 'application/pdf', 'symvasi-ypografi.pdf' );
					if ( $sp ) {
						\EnergyCRM\Services::files()->replaceKind(
							$id,
							'signed_pdf',
							( $row['code'] ?: ( 'symvasi-' . $id ) ) . '-ypografi.pdf',
							'application/pdf',
							$sp['path']
						);
					}
				}
			} catch ( \Throwable $e ) { /* PDF optional — signing still succeeds */ }
		}

		// Advance status + record the signature audit fields, via the centralized
		// lifecycle (logs the event and fires the configured customer messaging).
		//
		// The hand-rolled fallback that used to sit here, for the case where
		// ECRM_REST was missing, is gone: it wrote a different event type for the
		// same act, so the one path nobody could reach was also the only one that
		// logged it wrong.
		// Η υπογραφή προχωράει την αίτηση ΑΜΕΣΩΣ (07/09/2026).
		//
		// Ως τότε έγραφε `status = 'signed'` και ένα cron (`AutoProcess`) την
		// προωθούσε πέντε λεπτά αργότερα. Δύο πράγματα ήταν λάθος σε αυτό: η
		// «Υπογράφηκε» ήταν γεγονός βαφτισμένο στάδιο -- η υπογραφή είναι το
		// `signed_at`, όχι μια θέση στη γραμμή παραγωγής -- και το πεντάλεπτο
		// «παράθυρο διόρθωσης» δεν το είχε ζητήσει κανείς. Το cron διαγράφηκε
		// ολόκληρο μαζί με την κατάσταση.
		//
		// Ποιο είναι το επόμενο στάδιο το λέει το περιεχόμενο της αίτησης, όχι
		// ο γράφος: με γραμμή κινητής περιμένει το SIM, χωρίς πάει κατευθείαν
		// στην οριστικοποίηση (κανόνας Κ2).
		$next = \EnergyCRM\Domain\Contract\MobileLine::stageAfterSignature( $row );

		$moved = \EnergyCRM\Services::lifecycle()->moveTo( $id, $next->value, [
			'from'    => (string) $row['status'],
			'message' => 'Ο πελάτης υπέγραψε ηλεκτρονικά από τον σύνδεσμο παρακολούθησης' . ( $ip ? ' (IP ' . $ip . ')' : '' ),
			'extra'   => [ 'signed_at' => $now, 'signed_ip' => $ip ],
			'inapp'   => false, // The contractNotices() call below handles the in-app notification.
		] );

		// Αν η πύλη δεν αφήσει την αίτηση να προχωρήσει (συνήθως λείπουν
		// δικαιολογητικά ή έχει λήξει η ταυτότητα), το moveTo() επιστρέφει false
		// και δεν γράφει τίποτα, ούτε το signed_at. Η εικόνα της υπογραφής όμως
		// έχει ήδη αποθηκευτεί, οπότε ο πελάτης έβλεπε «καταχωρήθηκε» ενώ η
		// λίστα ελέγχου έμενε με «○ Υπογραφή πελάτη». Η υπογραφή είναι γεγονός,
		// όχι στάδιο: γράφεται το signed_at και η κατάσταση μένει όπως ήταν.
		if ( ! $moved ) {
			\EnergyCRM\Services::lifecycle()->moveTo( $id, (string) $row['status'], [
				'from'    => (string) $row['status'],
				'force'   => true,
				'message' => 'Ο πελάτης υπέγραψε ηλεκτρονικά' . ( $ip ? ' (IP ' . $ip . ')' : '' ) . ', αλλά η αίτηση δεν προχώρησε: λείπουν δικαιολογητικά.',
				'extra'   => [ 'signed_at' => $now, 'signed_ip' => $ip ],
				'inapp'   => false,
				'sms'     => false,
			] );
		}

		// Ξαναχτίζεται ΚΑΙ εδώ (και όχι μόνο πιο πάνω): τώρα η κατάσταση της
		// σύμβασης προχώρησε, και ο,τιδήποτε διαβάζει το status από το ίδιο
		// έγγραφο (π.χ. footer/badge) πρέπει να το δει ενημερωμένο.
		\EnergyCRM\Services::contractDocuments()->store( $id );

		\EnergyCRM\Services::contractNotices()->signed( $id, (string) ( $row['first_name'] ?? '' ) );

		// Notify the seller.
		if ( ! empty( $row['partner_user_id'] ) ) {
			$u = get_userdata( (int) $row['partner_user_id'] );
			if ( $u && is_email( $u->user_email ) ) {
				wp_mail(
					$u->user_email,
					sprintf( '✍️ Υπογράφηκε: %s', $row['code'] ),
					sprintf(
						$moved
							? "Ο πελάτης υπέγραψε ηλεκτρονικά τη σύμβαση %s.\nΗ κατάσταση προχώρησε σε «%s»."
							: "Ο πελάτης υπέγραψε ηλεκτρονικά τη σύμβαση %s.\nΗ κατάσταση δεν προχώρησε σε «%s» γιατί λείπουν δικαιολογητικά. Δες τη λίστα ελέγχου της αίτησης.",
						$row['code'],
						$next->label()
					)
				);
			}
		}

		return new WP_REST_Response( [ 'ok' => true, 'message' => 'Ευχαριστούμε! Η υπογραφή καταχωρήθηκε.' ], 200 );
	}

	// --- REST: customer document upload ------------------------------------

	public static function rest_upload( WP_REST_Request $req ): WP_REST_Response {
		if ( class_exists( 'ECRM_RateLimit' ) && ! ECRM_RateLimit::allow( 'track_upload', 30, 600 ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Πολλές προσπάθειες. Δοκιμάστε αργότερα.' ], 429 );
		}
		// Ο ρόλος δεν έχει σημασία εδώ -- ένα ανεβασμένο έγγραφο (ταυτότητα,
		// λογαριασμός) ανήκει στη ΣΥΜΒΑΣΗ, όχι σε συγκεκριμένο υπογράφοντα.
		$v = self::verify( (string) $req['token'] );
		if ( ! $v ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'invalid_token' ], 404 );
		}
		$id = $v['id'];

		global $wpdb;
		$ct  = ECRM_DB::table( 'contracts' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT status, activation_type FROM {$ct} WHERE id = %d", $id ), ARRAY_A );
		if ( ! $row ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'not_found' ], 404 );
		}
		if ( in_array( $row['status'], [ 'cancelled', 'active' ], true ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Η αίτηση δεν δέχεται πλέον έγγραφα.' ], 400 );
		}

		// Πόσα αρχεία κρέμονται ήδη. Ίδιο όριο και ίδιος λόγος με το
		// ECRM_Intake::rest_file() -- χωρίς αυτό, ο σύνδεσμος παρακολούθησης
		// γίνεται δωρεάν αποθηκευτικός χώρος για όποιον τον έχει, ασχέτως αν
		// είναι ο πελάτης ή κάποιος στον οποίο το προώθησε. AUDIT 29/08.
		$ft    = ECRM_DB::table( 'files' );
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ft} WHERE contract_id = %d", $id ) );
		if ( $count >= 6 ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Έχετε ήδη ανεβάσει τον μέγιστο αριθμό αρχείων.' ], 400 );
		}

		$p    = $req->get_json_params() ?: $req->get_params();
		$kind = sanitize_key( (string) ( $p['kind'] ?? 'other' ) );
		$catalog = class_exists( 'ECRM_Docs' ) ? ECRM_Docs::kinds() : [ 'other' => 'Άλλο έγγραφο' ];
		if ( ! array_key_exists( $kind, $catalog ) ) { $kind = 'other'; }

		$data  = (string) ( $p['data'] ?? '' );
		$fname = sanitize_file_name( (string) ( $p['filename'] ?? '' ) );

		if ( ! preg_match( '#^data:([a-zA-Z0-9./+\-]+);base64,#', $data, $m ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Μη έγκυρο αρχείο.' ], 400 );
		}
		$mime    = strtolower( $m[1] );
		$allowed = self::upload_types();
		if ( ! isset( $allowed[ $mime ] ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Επιτρέπονται μόνο JPG, PNG, WEBP, HEIC ή PDF.' ], 400 );
		}
		$bin = base64_decode( substr( $data, strlen( $m[0] ) ), true );
		if ( $bin === false || strlen( $bin ) < 64 ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Το αρχείο είναι κατεστραμμένο.' ], 400 );
		}
		if ( strlen( $bin ) > 12 * 1024 * 1024 ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Το αρχείο είναι πολύ μεγάλο (μέγιστο 12MB).' ], 400 );
		}
		// Magic-byte sanity so the declared MIME can't lie about the payload.
		// AUDIT 29/08: webp/heic used to skip this ("trust the whitelist +
		// size check") -- the one gap between this anonymous route and the
		// authenticated upload (ECRM_Files::store(), which has sniffed every
		// type through UploadCheck since 2026-08-18). Same check, same class,
		// no more gap.
		$sniffed = \EnergyCRM\Infrastructure\UploadCheck::sniff( substr( $bin, 0, \EnergyCRM\Infrastructure\UploadCheck::HEAD_BYTES ) );
		if ( '' === $sniffed || $sniffed !== $mime ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Ο τύπος αρχείου δεν ταιριάζει.' ], 400 );
		}

		if ( ! class_exists( 'ECRM_Files' ) ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Σφάλμα αποθήκευσης.' ], 500 );
		}
		$ext    = $allowed[ $mime ];
		$stored = ECRM_Files::put_bytes( $bin, $ext, $mime, ( $fname ?: ( $kind . '.' . $ext ) ) );
		if ( ! $stored ) {
			return new WP_REST_Response( [ 'ok' => false, 'error' => 'Σφάλμα αποθήκευσης.' ], 500 );
		}

		$wpdb->insert( ECRM_DB::table( 'files' ), [
			'contract_id'   => $id,
			'attachment_id' => null,
			'doc_kind'      => $kind,
			'filename'      => $stored['filename'],
			'mime'          => $stored['mime'],
			'path'          => $stored['path'],
			'protected'     => 1,
		] );

		$label = $catalog[ $kind ] ?? 'έγγραφο';
		$wpdb->insert( ECRM_DB::table( 'events' ), [
			'contract_id' => $id, 'user_id' => 0, 'type' => 'note',
			'message'     => 'Ο πελάτης ανέβασε δικαιολογητικό: ' . $label,
		] );
		\EnergyCRM\Services::contractNotices()->documentUploaded( $id, $label );

		return new WP_REST_Response( [
			'ok'      => true,
			'message' => 'Το έγγραφο ανέβηκε. Ευχαριστούμε!',
			'docs'    => self::docs_payload( $id, (string) $row['status'], $row['activation_type'] ?? '', $row['energy_type'] ?? '' ),
		], 200 );
	}

	// --- Public page --------------------------------------------------------

	/**
	 * What the customer ticks before signing.
	 *
	 * The previous wording covered "processing for concluding the contract",
	 * which is true and incomplete: the photograph of their ID card and their
	 * bill is sent to an external AI service that reads the ΑΦΜ, ΑΔΤ, date of
	 * birth and address off it, so the application can be filled in without
	 * retyping. A recipient the customer is never told about is exactly what
	 * Articles 13–14 exist to prevent, and consent given without knowing it
	 * is not informed consent.
	 *
	 * Filterable because the final wording is the company lawyer's call, not
	 * the developer's — and because a wording change should never require
	 * editing a template.
	 */
	public static function consent_text(): string {
		$default = 'Συναινώ στην επεξεργασία των προσωπικών μου δεδομένων για τη σύναψη/διαχείριση '
			. 'της σύμβασης και αποδέχομαι την ηλεκτρονική υπογραφή ως δεσμευτική. Ενημερώθηκα ότι τα '
			. 'έγγραφα που υποβάλλονται (ταυτότητα, λογαριασμός) αναγνωρίζονται αυτόματα από εξωτερική '
			. 'υπηρεσία τεχνητής νοημοσύνης για τη συμπλήρωση της αίτησης.';

		return (string) apply_filters( 'ecrm_consent_text', $default );
	}

	public static function maybe_render(): void {
		$token = isset( $_GET['ecrm_track'] ) ? preg_replace( '/[^A-Za-z0-9\-]/', '', wp_unslash( $_GET['ecrm_track'] ) ) : '';
		if ( ! $token ) {
			return;
		}
		$rest    = esc_url_raw( rest_url( \EnergyCRM\Http\Router::NAMESPACE . '/track/' . $token ) );
		$accent  = class_exists( 'ECRM_Admin' )
			? (string) ECRM_Admin::get( 'accent_color', ECRM_Admin::DEFAULT_ACCENT )
			: '#0e8610';
		$company = class_exists( 'ECRM_Admin' ) ? (string) ECRM_Admin::get( 'company_name' ) : '';

		// Verify the HMAC token here (server-side) so we can distinguish a genuinely
		// invalid/expired link (bad signature — e.g. site salts changed) from a
		// reachability problem (REST API blocked for anonymous visitors).
		$token_ok = ( self::verify( $token ) !== null );

		$consent_text = self::consent_text();

		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!doctype html>
<html lang="el">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Παρακολούθηση Αίτησης</title>
<?php // Η γραμματοσειρά σερβίρεται ΑΠΟ ΤΟ PLUGIN. Εδώ έμπαινε Inter από το CDN
// της Google — σε σελίδα που βλέπει ο ΠΕΛΑΤΗΣ, μέσα σε ροή προσωπικών
// δεδομένων. Δες EnergyCRM\Infrastructure\LocalFonts και CHANGELOG (15).
echo \EnergyCRM\Infrastructure\LocalFonts::styleTag( ECRM_URL ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- σταθερό CSS με URL που φτιάχνει η ίδια η κλάση.
?>
<style>
	/* ---- Ταυτότητα 2026-08-18, ευθυγραμμίστηκε με το kit A 2026-08-25 --------
	 * Ήταν navy #0a1f3d με amber gradient: η παλέτα ΠΡΙΝ από το restyle των
	 * πέντε βημάτων, που δεν άγγιξε ποτέ τις σελίδες του πελάτη. Ο πελάτης που
	 * υπέγραφε έβλεπε άλλο προϊόν από τον συνεργάτη που του πούλησε.
	 *
	 * Ήταν σκόπιμα τρίτο σύστημα (λευκή κάρτα σε σκούρο φόντο, πράσινο accent,
	 * CHANGELOG 63/68) — ΔΕΝ ήταν ξεχασμένο. Απόφαση ιδιοκτήτη 25/08, μετά από
	 * σύγκριση δίπλα-δίπλα κατά §1.8 (`docs/UI-SIGN-VS-KIT.html`): η κάρτα
	 * ακολουθεί πια το λάιμ accent και τα σκούρα επίπεδα του kit A (`#p-public`,
	 * screen B5) αντί για τη δική της παλέτα. Οι τιμές είναι κυριολεκτικά ίδιες
	 * με το `docs/UI-UX-KIT.html` `:root` — ΟΧΙ tokens του `.ecrm[data-theme]`:
	 * αυτό το αρχείο δεν φορτώνει κοινό φύλλο εσκεμμένα (CHANGELOG 68 — «καμία
	 * οθόνη του CRM δεν μπορεί να παλινδρομήσει από αυτή την παρτίδα»), οπότε
	 * μένει με δικά του literal χρώματα, τώρα απλώς ίδια με του kit.
	 *
	 * Το --accent-text είναι ΝΕΟ: το λάιμ #c2f04a είναι πολύ ανοιχτό για λευκό
	 * κείμενο πάνω του (το kit το λέει ρητά, `--accent-text:#1a2208`) — το παλιό
	 * πράσινο #0e8610 δούλευε με λευκό επειδή ήταν αρκετά σκούρο, το λάιμ όχι.
	 *
	 * Το --accent έρχεται από τις ρυθμίσεις, με προεπιλογή ECRM_Admin::DEFAULT_ACCENT
	 * — που έγινε κι αυτή #c2f04a, ίδια μέρα, ίδιος λόγος. */
	:root {
		--accent: <?php echo esc_html( $accent ?: '#c2f04a' ); ?>;
		--accent-text:#1a2208;
		--page:#0f1218; --chrome:#12161f; --surface:#171b24;
		--ink:#eef1f6; --ink2:#aab3c5; --ink3:#8b95a8;
		--line:#2a3140; --line2:#3a455c; --fill:#1e2430;
		--ok:#3dd68c; --ok-bg:rgba(61,214,140,.15);
		/* Το kit δεν ορίζει κόκκινο (καμία οθόνη του δεν το χρειάζεται) — εδώ
		   χρειάζεται, για την ακυρωμένη αίτηση. Ίδια μέθοδος με το δικό του
		   --ok-dim/--warn-dim: rgba πάνω στο ίδιο απόχρωμα, όχι νέο σύστημα. */
		--err:#ff6b7a; --err-bg:rgba(255,107,122,.15);
		/* Η υπογραφή ΜΕΝΕΙ σε λευκό πλαίσιο ακόμα κι εδώ — το kit το δείχνει
		   ρητά (`background:#fff` στο δικό του B5), γιατί το μελάνι πρέπει να
		   φαίνεται καθαρά μέσα στο PDF. Πριν, το --ink ήταν ήδη σκούρο (μελάνι σε
		   χαρτί) οπότε το `.strokeStyle` της JS διάβαζε κατευθείαν από αυτό· τώρα
		   που το --ink έγινε ανοιχτό (κείμενο σε σκούρο φόντο) θα ζωγράφιζε
		   ΑΟΡΑΤΗ υπογραφή σε λευκό πλαίσιο. Το --pad-ink είναι ξεχωριστό ΕΠΙΤΗΔΕΣ:
		   δεν ακολουθεί το θέμα, γιατί ο καμβάς της υπογραφής δεν το ακολουθεί. */
		--pad-ink:#1a1a18; --pad-border:#4a5568;
	}
	* { box-sizing: border-box; }
	body { margin:0; font-family:<?php echo \EnergyCRM\Infrastructure\LocalFonts::STACK; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- σταθερά κλάσης, όχι είσοδος. Το esc_html() θα μετέτρεπε τα εισαγωγικά του «"Manrope"» σε &quot; και θα ΕΣΠΑΓΕ το CSS. ?>;
		background:var(--page); font-size:13px; min-height:100vh; min-height:100dvh;
		display:flex; align-items:center; justify-content:center; padding:20px; color:var(--ink); }
	.card { background:var(--surface); border-radius:12px; box-shadow:0 24px 60px -24px rgba(0,0,0,.55);
		width:100%; max-width:520px; overflow:hidden; }
	.head { background:var(--chrome); color:#fff; padding:14px 18px; }
	.head h1 { margin:0; font-size:15px; font-weight:700; letter-spacing:-.02em; }
	.head p { margin:4px 0 0; color:var(--ink3); font-size:12px; }
	.body { padding:16px 18px; }
	.row { display:flex; justify-content:space-between; gap:14px; padding:7px 0; border-bottom:1px solid var(--line); font-size:13px; }
	.row:last-of-type { border-bottom:0; }
	.row span { color:var(--ink2); } .row b { color:var(--ink); font-weight:600; text-align:right; }
	.foot { text-align:center; font-size:11.5px; color:var(--ink3); padding:11px; border-top:1px solid var(--line); }
	.steps { list-style:none; margin:16px 0 4px; padding:0; }
	.steps li { display:flex; align-items:flex-start; gap:12px; padding-bottom:13px; position:relative; }
	.steps li:not(:last-child)::before { content:""; position:absolute; left:11px; top:24px; bottom:-2px; width:2px; background:var(--line); }
	.steps li.done:not(:last-child)::before { background:var(--accent); }
	.dot { flex:0 0 24px; width:24px; height:24px; border-radius:50%; background:var(--line); color:var(--ink3);
		display:grid; place-items:center; font-weight:700; font-size:12.5px; z-index:1; }
	/* Κείμενο πάνω στο accent: --accent-text, όχι λευκό — δες σχόλιο στο :root. */
	.steps li.done .dot { background:var(--accent); color:var(--accent-text); }
	.steps li.current .dot { background:var(--chrome); color:var(--ink); box-shadow:0 0 0 4px rgba(0,0,0,.35); }
	.steps .lbl { padding-top:3px; font-size:13px; font-weight:600; color:var(--ink3); }
	.steps li.done .lbl, .steps li.current .lbl { color:var(--ink); }
	/* ΟΥΔΕΤΕΡΟ, όχι πράσινο: το badge δείχνει όποια κατάσταση κι αν είναι, και
	   «Εκκρεμότητα» σε πράσινο φόντο λέει «όλα καλά». Την πρόοδο τη δείχνει η
	   λίστα βημάτων από κάτω· εδώ χρειάζεται μόνο ονομασία. Η ακύρωση κρατά το
	   δικό της κόκκινο, γιατί εκεί το χρώμα ΕΙΝΑΙ η πληροφορία. */
	.badge { display:inline-block; margin-top:4px; padding:3px 10px; border-radius:999px; font-size:11.5px;
		font-weight:700; background:var(--fill); color:var(--ink); border:1px solid var(--line2); }
	.badge.cancel { background:var(--err-bg); color:var(--err); }
	.cancel-box { text-align:center; padding:22px 10px; }
	.cancel-box .x { width:46px; height:46px; border-radius:50%; background:var(--err-bg); color:var(--err);
		display:grid; place-items:center; font-size:22px; margin:0 auto 12px; }
	.sign { margin-top:16px; border-top:1px solid var(--line); padding-top:14px; }
	.sign h2 { font-size:13px; margin:0 0 4px; color:var(--ink); font-weight:700; }
	.sign p.lead { margin:0 0 12px; font-size:12.5px; color:var(--ink2); }
	/* Λευκό πλαίσιο ΕΠΙΤΗΔΕΣ, όχι var(--fill): το kit το δείχνει ρητά έτσι στο
	   δικό του B5, και το μελάνι της υπογραφής πρέπει να φαίνεται καθαρά μέσα
	   στο PDF — δες --pad-ink στο :root. */
	.pad { border:2px dashed var(--pad-border); border-radius:8px; background:#fff; touch-action:none;
		width:100%; height:150px; display:block; }
	.padbar { display:flex; justify-content:space-between; align-items:center; margin-top:8px; }
	.padbar small { color:var(--ink3); font-size:12px; }
	.btn { border:0; border-radius:8px; padding:11px 18px; font-size:14px; font-weight:600; cursor:pointer; font-family:inherit; }
	.btn--clear { background:var(--fill); color:var(--ink2); padding:6px 11px; font-size:11.5px; border:1px solid var(--line2); }
	.btn--clear:hover { border-color:var(--ink3); }
	.btn--sign { background:var(--accent); color:var(--accent-text); width:100%; margin-top:14px; height:46px; font-size:14px; font-weight:700; transition:filter .15s; }
	.btn--sign:hover:not(:disabled) { filter:brightness(1.08); }
	.btn--sign:disabled { opacity:.5; cursor:not-allowed; }
	.consent { display:flex; gap:10px; align-items:flex-start; margin-top:14px; font-size:12px; color:var(--ink2); line-height:1.5; }
	.consent input { margin-top:1px; flex:0 0 18px; width:18px; height:18px; accent-color:var(--accent); }
	.signed-ok { text-align:center; padding:14px 10px; }
	.signed-ok .v { width:44px; height:44px; border-radius:50%; background:var(--ok-bg); color:var(--ok);
		display:grid; place-items:center; font-size:20px; margin:0 auto 12px; }
	.signed-ok p { color:var(--ok); font-weight:700; margin:0; font-size:14px; }
	.docs { margin-top:16px; border-top:1px solid var(--line); padding-top:14px; }
	.docs h2 { font-size:13px; margin:0 0 4px; color:var(--ink); font-weight:700; }
	.docs p.lead { margin:0 0 12px; font-size:12.5px; color:var(--ink2); }
	.doc-item { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:8px 0; border-bottom:1px solid var(--line); }
	.doc-item:last-child { border-bottom:0; }
	.doc-lbl { font-size:13px; font-weight:600; color:var(--ink); }
	.doc-ok { display:inline-flex; align-items:center; gap:6px; color:var(--ok); font-weight:700; font-size:13px; }
	.doc-btns { display:flex; gap:6px; flex:0 0 auto; }
	.up-btn { border:1px solid var(--line2); background:var(--surface); color:var(--ink); border-radius:8px;
		padding:6px 11px; font-size:12px; font-weight:600; cursor:pointer; font-family:inherit; }
	.up-btn:hover { border-color:var(--ink3); }
	.up-btn.is-busy { opacity:.6; pointer-events:none; }
	/* Στόχος αφής 40x40 σαν το .up-btn κανονικό — μόνο εικονίδιο, όχι κείμενο,
	   ώστε δύο κουμπιά να χωράνε δίπλα-δίπλα ακόμα και σε στενή οθόνη. */
	.up-btn--cam { padding:6px 10px; font-size:15px; line-height:1; }
	.doc-msg { font-size:12px; margin-top:8px; min-height:16px; color:var(--ink3); }
	.doc-msg.is-ok { color:var(--ok); }
	.doc-msg.is-err { color:var(--err); }
	/* Η παράγραφος της ακύρωσης: είχε το slate #64748b της παλιάς ταυτότητας
	   γραμμένο μέσα στη render(), όπου κανένας φύλακας δεν το βλέπει — ο
	   ColourIsDecidedInOnePlaceTest σαρώνει public/assets/*.css, όχι public/*.php. */
	.cancel-box .quiet { margin:12px 0 0; font-size:13.5px; color:var(--ink2); }
	/* Ο άκυρος σύνδεσμος: ΟΥΔΕΤΕΡΟΣ, όχι κόκκινος. Ο πελάτης που πάτησε παλιό link
	   δεν έκανε λάθος και δεν έχει πρόβλημα ασφαλείας — έχει σύνδεσμο που δεν ισχύει.
	   Το κόκκινο μένει εκεί που το χρώμα ΕΙΝΑΙ η πληροφορία: στην ακυρωμένη αίτηση.
	   Το ΚΕΙΜΕΝΟ δεν άλλαξε. Τα δύο διαφορετικά μηνύματα (άκυρο token / δεν βρέθηκε)
	   δεν διαρρέουν τίποτα: και τα δύο γυρίζουν 404 και το δεύτερο απαιτεί έγκυρο
	   HMAC για να εμφανιστεί. Ολόκληρο το σκεπτικό στο docs/UI-SIGN.html §1. */
	.fail { text-align:center; padding:22px 10px; }
	.fail__i { width:46px; height:46px; border-radius:50%; background:var(--fill); color:var(--ink3);
		border:1px solid var(--line2); display:grid; place-items:center; font-size:22px; margin:0 auto 12px; }
	.fail p { margin:0; font-size:13.5px; color:var(--ink2); line-height:1.5; }
	.fail code { display:block; margin-top:10px; font-size:11px; color:var(--ink3);
		font-family:ui-monospace,Menlo,Consolas,monospace; }
	/* Πυκνότητα για ποντίκι, στόχος για αντίχειρα — ο κανόνας §1.9. Ίδιο μοτίβο με
	   τα 36->44px input της (65): ο σχεδιασμός ξεκινά από desktop, η λειτουργία δεν
	   επιτρέπεται να σπάσει πουθενά. */
	@media (max-width: 560px) {
		.pad { height:180px; }
		.up-btn, .btn--clear { min-height:40px; }
	}
</style>
</head>
<body>
<div class="card">
	<div class="head">
		<h1>Παρακολούθηση Αίτησης</h1>
		<p><?php echo esc_html( $company ?: 'Energy CRM' ); ?></p>
	</div>
	<div id="content" class="body"><p>Φόρτωση…</p></div>
	<div class="foot">Ασφαλής σύνδεσμος παρακολούθησης</div>
</div>

<script>
(function(){
	var REST = <?php echo wp_json_encode( $rest ); ?>;
	var TOKEN_OK = <?php echo $token_ok ? 'true' : 'false'; ?>;
	var CONSENT_TEXT = <?php echo wp_json_encode( $consent_text ); ?>;
	var SIGN = REST + '/sign';
	var content = document.getElementById('content');
	// Το μελάνι της υπογραφής, από το --pad-ink του :root — ΟΧΙ το --ink. ΔΕΝ
	// ξαναγράφεται εδώ: ο καμβάς γίνεται PNG που μπαίνει στο υπογεγραμμένο PDF,
	// άρα αυτή η τιμή ΑΠΟΘΗΚΕΥΕΤΑΙ μέσα στο έγγραφο. Μέχρι τις 20/08 ήταν
	// σκληροκωδικοποιημένο το navy #0a1f3d.
	//
	// Ξεχωριστό token από 25/08, ΕΠΙΤΗΔΕΣ: μέχρι τότε το --ink ήταν ήδη σκούρο
	// (κείμενο σε λευκή κάρτα) και δούλευε σαν μελάνι σε χαρτί — σύμπτωση, όχι
	// σχέδιο. Η ευθυγράμμιση με το kit A έκανε το --ink ΑΝΟΙΧΤΟ (κείμενο σε
	// σκούρο φόντο), αλλά το πλαίσιο υπογραφής ΕΞΑΚΟΛΟΥΘΕΙ να είναι λευκό — αν
	// αυτή η γραμμή έμενε στο --ink, η υπογραφή θα ζωγραφιζόταν ΑΟΡΑΤΗ (σχεδόν-
	// λευκό μελάνι σε λευκό φόντο) και θα το ανακάλυπτε πρώτος ο πελάτης που θα
	// έστελνε κενό PNG. Το --pad-ink δεν ακολουθεί το θέμα, γιατί ο καμβάς δεν
	// το ακολουθεί.
	var INK = (getComputedStyle(document.documentElement).getPropertyValue('--pad-ink') || '').trim() || '#1a1a18';

	function esc(s){ var d=document.createElement('div'); d.textContent=(s==null?'':String(s)); return d.innerHTML; }
	// Τοπική ανάγνωση, χωρίς 'Z' — 22/08. Οι αποθηκευμένες ώρες είναι ώρα
	// Αθήνας· το 'Z' πρόσθετε τη διαφορά δεύτερη φορά και ο πελάτης έβλεπε
	// την τελευταία ενημέρωση τρεις ώρες μετά. Δες ecrm-format.js.
	function fmt(s){ if(!s) return '—'; var d=new Date(s.replace(' ','T')); if(isNaN(d)) return s; return d.toLocaleDateString('el-GR')+' '+d.toLocaleTimeString('el-GR',{hour:'2-digit',minute:'2-digit'}); }

	function fail(msg, code){
		content.innerHTML = '<div class="fail"><div class="fail__i">!</div><p>' + esc(msg) + '</p>' +
			(code ? '<code>κωδ. ' + esc(code) + '</code>' : '') + '</div>';
	}

	function load(){
		// If the link itself didn't pass the server-side signature check, it's
		// genuinely invalid/expired — no point hitting the API.
		if (!TOKEN_OK) {
			fail('Ο σύνδεσμος δεν είναι έγκυρος ή έληξε. Ζητήστε νέο σύνδεσμο από τον συνεργάτη σας.', 'ΑΚΥΡΟΣ ΣΥΝΔΕΣΜΟΣ');
			return;
		}
		fetch(REST, { headers: { 'Accept': 'application/json' } })
			.then(function(r){
				return r.json().catch(function(){ return null; }).then(function(d){ return { http: r.status, d: d }; });
			})
			.then(function(res){
				var d = res.d, http = res.http;
				if (d && d.ok) { render(d); return; }

				// The token is valid (checked above), so a non-OK here is almost
				// always the server blocking the public endpoint, not a bad link.
				if (http === 401 || http === 403 || (d && /^rest_/.test(d.code || ''))) {
					fail('Δεν ήταν δυνατή η σύνδεση με τον διακομιστή. Δοκιμάστε ξανά ή επικοινωνήστε μαζί μας.', 'ΣΥΝΔΕΣΗ');
				} else if (http === 429 || (d && d.error === 'too_many')) {
					fail('Πολλές προσπάθειες σε σύντομο διάστημα. Δοκιμάστε ξανά σε λίγα λεπτά.', 'ΠΟΛΛΕΣ ΠΡΟΣΠΑΘΕΙΕΣ');
				} else if (d && d.error === 'not_found') {
					fail('Η αίτηση δεν βρέθηκε. Ενδέχεται να έχει διαγραφεί.', 'ΔΕΝ ΒΡΕΘΗΚΕ');
				} else if (d && d.error === 'invalid_token') {
					fail('Ο σύνδεσμος δεν είναι έγκυρος ή έληξε.', 'ΑΚΥΡΟΣ ΣΥΝΔΕΣΜΟΣ');
				} else {
					fail('Παρουσιάστηκε πρόβλημα κατά τη φόρτωση. Δοκιμάστε ξανά.', 'ΑΓΝΩΣΤΟ ΣΦΑΛΜΑ');
				}
			})
			.catch(function(){ fail('Σφάλμα δικτύου. Ελέγξτε τη σύνδεσή σας και δοκιμάστε ξανά.', 'ΔΙΚΤΥΟ'); });
	}
	load();

	function render(d){
		var info =
			'<div class="row"><span>Κωδικός</span><b>'+esc(d.code)+'</b></div>'+
			'<div class="row"><span>Πάροχος</span><b>'+esc(d.provider)+'</b></div>'+
			'<div class="row"><span>Υπηρεσία</span><b>'+esc(d.energy)+'</b></div>'+
			'<div class="row"><span>Πελάτης</span><b>'+esc(d.customer)+'</b></div>'+
			'<div class="row"><span>Τελευταία ενημέρωση</span><b>'+esc(fmt(d.updated_at))+'</b></div>';

		if(d.cancelled){
			content.innerHTML = info +
				'<div class="cancel-box"><div class="x">✕</div>'+
				'<div class="badge cancel">'+esc(d.status_label)+'</div>'+
				'<p class="quiet">Η αίτηση δεν είναι σε εξέλιξη. Για διευκρινίσεις επικοινωνήστε μαζί μας.</p></div>';
			return;
		}

		var stages = d.stages || [], cur = d.stage|0;
		var steps = '<ul class="steps">';
		for(var i=0;i<stages.length;i++){
			var cls = i<cur ? 'done' : (i===cur ? 'current' : '');
			var mark = i<cur ? '✓' : (i+1);
			steps += '<li class="'+cls+'"><span class="dot">'+mark+'</span><span class="lbl">'+esc(stages[i])+'</span></li>';
		}
		steps += '</ul>';

		var tail = '<div style="text-align:center"><span class="badge">'+esc(d.status_label)+'</span></div>';

		if (d.can_sign) {
			tail +=
				'<div class="sign">'+
					'<h2>Υπογραφή σύμβασης</h2>'+
					'<p class="lead">Υπογράψτε στο πλαίσιο με το δάχτυλο ή το ποντίκι για να ολοκληρωθεί η αίτησή σας.</p>'+
					'<canvas class="pad is-empty" id="pad"></canvas>'+
					'<div class="padbar"><small>Σχεδιάστε την υπογραφή σας παραπάνω</small><button type="button" class="btn btn--clear" id="clear">Καθαρισμός</button></div>'+
					'<label class="consent"><input type="checkbox" id="consent"> '+esc(CONSENT_TEXT)+'</label>'+
					'<button type="button" class="btn btn--sign" id="dosign" disabled>Υπογραφή & Αποστολή</button>'+
				'</div>';
		} else if (d.sign_expired) {
			// Η ΚΑΤΑΣΤΑΣΗ ΑΠΟ ΠΑΝΩ ΜΕΝΕΙ. Χάνεται μόνο το κουμπί: εδώ ο
			// σύνδεσμος υπογραφής ΕΙΝΑΙ ο σύνδεσμος παρακολούθησης, και ο
			// πελάτης θα ξανανοίξει το ίδιο SMS τον Δεκέμβριο για να δει πού
			// πάει η σύμβασή του. Δες docs/UI-SIGN-EXPIRY.html.
			tail +=
				'<div class="fail"><div class="fail__i">!</div>'+
					'<p><b>Ο σύνδεσμος υπογραφής έληξε.</b><br>'+
					'Ζητήστε νέον από τον συνεργάτη σας — η αίτησή σας δεν χάθηκε, '+
					'και η κατάσταση από πάνω εξακολουθεί να ενημερώνεται.</p>'+
				'</div>';
		} else if (d.signed && d.waiting_other) {
			// Αυτός ο ρόλος υπέγραψε, αλλά η αίτηση χρειάζεται ΚΑΙ την υπογραφή
			// του δεύτερου προσώπου (COMBO, διαφορετικός πελάτης ενέργειας).
			// Το status_label από πάνω ήδη δείχνει ότι δεν έχει ολοκληρωθεί -- εδώ
			// μόνο διευκρινίζουμε ότι ΤΟ ΔΙΚΟ ΤΟΥ κομμάτι έγινε, ώστε να μην
			// νομίζει ότι κάτι πήγε στραβά ή ότι πρέπει να ξαναϋπογράψει.
			tail += '<div class="signed-ok"><div class="v">✓</div>'+
				'<p>Η υπογραφή σας καταχωρήθηκε</p>'+
				'<p style="font-weight:400;font-size:13px;margin-top:6px">'+
				'Περιμένουμε ακόμα την υπογραφή του δεύτερου προσώπου για να ολοκληρωθεί η αίτηση.</p>'+
			'</div>';
		} else if (d.signed) {
			tail += '<div class="signed-ok"><div class="v">✓</div><p>Η σύμβαση υπεγράφη ηλεκτρονικά</p></div>';
		}

		tail += docsHtml(d.docs);

		content.innerHTML = info + steps + tail;
		if (d.can_sign) initPad();
		initDocs();
	}

	function docsHtml(docs){
		if (!docs || !docs.can_upload) return '';
		var items = docs.items || [];
		var html = '<div class="docs"><h2>Δικαιολογητικά</h2>'+
			'<p class="lead">Ανεβάστε τα απαραίτητα έγγραφα (φωτογραφία ή PDF). Συνδέονται αυτόματα με την αίτησή σας.</p>';
		/* (275) Πριν, μόλις ανέβαινε ΕΝΑ αρχείο ενός είδους (π.χ. ταυτότητα),
		 * το `it.done` γινόταν true και τα κουμπιά ανεβάσματος εξαφανίζονταν
		 * ΜΟΝΙΜΑ -- ο πελάτης δεν είχε κανέναν τρόπο να προσθέσει δεύτερο
		 * αρχείο του ίδιου είδους (π.χ. πίσω όψη ταυτότητας μετά την μπροστινή).
		 * Το backend ήδη δέχεται πολλά αρχεία ανά kind (βλ. FileRepository::
		 * deleteKind() που σβήνει ΟΛΑ τα αρχεία ενός kind, όχι ένα) -- το
		 * όριο ήταν μόνο εδώ, στο UI. Τώρα το ✓ δείχνει ότι καλύφθηκε η
		 * απαίτηση, αλλά τα κουμπιά μένουν διαθέσιμα για να προστεθεί κι
		 * άλλο αρχείο του ίδιου είδους. */
		for (var i=0;i<items.length;i++){
			var it = items[i];
			html += '<div class="doc-item"><span class="doc-lbl">'+esc(it.label)+(it.done ? ' <span class="doc-ok">✓ Ανέβηκε</span>' : '')+'</span>'+
				'<span class="doc-btns"><button type="button" class="up-btn" data-kind="'+esc(it.kind)+'">Ανέβασμα</button>'+
					'<button type="button" class="up-btn up-btn--cam" data-kind="'+esc(it.kind)+'" aria-label="Λήψη φωτογραφίας">📷</button></span>'+
				'</div>';
		}
		// Always allow a free-form extra document.
		html += '<div class="doc-item"><span class="doc-lbl">Άλλο έγγραφο</span>'+
			'<span class="doc-btns"><button type="button" class="up-btn" data-kind="other">Ανέβασμα</button>'+
			'<button type="button" class="up-btn up-btn--cam" data-kind="other" aria-label="Λήψη φωτογραφίας">📷</button></span></div>';
		html += '<div class="doc-msg" id="docmsg"></div>'+
			'<input type="file" id="docfile" accept="image/jpeg,image/png,image/webp,image/heic,application/pdf,.pdf,.jpg,.jpeg,.png,.webp,.heic" style="display:none">'+
			// Ξεχωριστό input από το docfile, με `capture` — το `capture` σε ένα
			// input που δέχεται ΚΑΙ PDF ΚΑΙ πολλαπλές μορφές εικόνας συμπεριφέρεται
			// ασυνεπώς ανά browser/κινητό. Ο πελάτης διαλέγει ρητά κάμερα ή αρχείο.
			// Ζητήθηκε ρητά, 23/08 — «τρομερά σημαντικό» για κινητό/tablet.
			'<input type="file" id="docfile-camera" accept="image/jpeg,image/png" capture="environment" style="display:none">'+
			'</div>';
		return html;
	}

	function initDocs(){
		var input = document.getElementById('docfile');
		var camInput = document.getElementById('docfile-camera');
		if (!input) return;
		var msg = document.getElementById('docmsg');
		var curKind = 'other', curBtn = null;
		function say(t, ok){ if(msg){ msg.textContent=t; msg.className = 'doc-msg' + (ok===false ? ' is-err' : (ok ? ' is-ok' : '')); } }

		content.querySelectorAll('.up-btn').forEach(function(b){
			b.addEventListener('click', function(){
				curKind = b.getAttribute('data-kind') || 'other'; curBtn = b;
				var target = b.classList.contains('up-btn--cam') && camInput ? camInput : input;
				target.value = ''; target.click();
			});
		});

		/* (271) Ίδιο σκεπτικό με το class-ecrm-intake.php: το iPhone στέλνει
		 * HEIC από προεπιλογή, αποθηκεύεται κανονικά εδώ (magic-bytes το
		 * επιβεβαιώνουν, UploadCheck.php), αλλά ο εξαγωγέας AI δεν διαβάζει
		 * HEIC καθόλου -- έμενε αόρατο, σιωπηλά. Μετατροπή σε JPEG εδώ, πριν
		 * το FileReader, με το ίδιο heic2any (WASM, lazy-load). Αποτυχία
		 * μετατροπής δεν μπλοκάρει το ανέβασμα -- ίδια συμπεριφορά με σήμερα. */
		var _heicLib = null;
		function loadHeic2Any() {
			if (_heicLib) return _heicLib;
			_heicLib = new Promise(function (res, rej) {
				if (window.heic2any) { res(window.heic2any); return; }
				var s = document.createElement('script');
				s.src = 'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js';
				s.onload = function () { res(window.heic2any); };
				s.onerror = function () { rej(new Error('heic2any load failed')); };
				document.head.appendChild(s);
			});
			return _heicLib;
		}
		function isHeic(file) {
			return file.type === 'image/heic' || file.type === 'image/heif' || /\.hei[cf]$/i.test(file.name || '');
		}
		function heicToJpeg(file) {
			if (!isHeic(file)) return Promise.resolve(file);
			return loadHeic2Any().then(function (heic2any) {
				return heic2any({ blob: file, toType: 'image/jpeg', quality: 0.85 });
			}).then(function (result) {
				var blob = Array.isArray(result) ? result[0] : result;
				var name = (file.name || 'photo.heic').replace(/\.hei[cf]$/i, '.jpg');
				return new File([blob], name, { type: 'image/jpeg' });
			}).catch(function (err) {
				console.warn('[ecrm] Μετατροπή HEIC απέτυχε, στέλνεται το αρχικό:', err);
				return file;
			});
		}

		function handleFile(f){
			if (!f) return;
			if (curBtn) curBtn.classList.add('is-busy');
			say('Ανέβασμα…');
			heicToJpeg(f).then(function (file) {
				if (file.size > 12*1024*1024) {
					if (curBtn) curBtn.classList.remove('is-busy');
					say('Το αρχείο είναι πολύ μεγάλο (μέγιστο 12MB).', false);
					return;
				}
				var reader = new FileReader();
				reader.onload = function(){
					fetch(REST + '/upload', {
						method:'POST', headers:{'Content-Type':'application/json'},
						body: JSON.stringify({ kind: curKind, filename: file.name, data: reader.result })
					}).then(function(r){ return r.json().catch(function(){return null;}); })
					.then(function(res){
						if (curBtn) curBtn.classList.remove('is-busy');
						if (res && res.ok) { say(res.message || 'Το έγγραφο ανέβηκε.', true); load(); }
						else { say((res && res.error) || 'Αποτυχία ανεβάσματος.', false); }
					}).catch(function(){ if(curBtn) curBtn.classList.remove('is-busy'); say('Σφάλμα δικτύου.', false); });
				};
				reader.onerror = function(){ if(curBtn) curBtn.classList.remove('is-busy'); say('Δεν ήταν δυνατή η ανάγνωση του αρχείου.', false); };
				reader.readAsDataURL(file);
			});
		}

		input.addEventListener('change', function(){ handleFile(input.files && input.files[0]); });
		if (camInput) { camInput.addEventListener('change', function(){ handleFile(camInput.files && camInput.files[0]); }); }
	}

	function initPad(){
		var canvas = document.getElementById('pad');
		var clearBtn = document.getElementById('clear');
		var consent = document.getElementById('consent');
		var doBtn = document.getElementById('dosign');
		if(!canvas) return;

		// Hi-DPI sizing.
		var ratio = window.devicePixelRatio || 1;
		function resize(){
			var w = canvas.clientWidth, h = canvas.clientHeight;
			canvas.width = w * ratio; canvas.height = h * ratio;
			var c = canvas.getContext('2d'); c.scale(ratio, ratio);
			c.lineWidth = 2.2; c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = INK;
		}
		resize();
		var ctx = canvas.getContext('2d');
		var drawing = false, empty = true, last = null;

		function pos(e){
			var r = canvas.getBoundingClientRect();
			var t = e.touches ? e.touches[0] : e;
			return { x: t.clientX - r.left, y: t.clientY - r.top };
		}
		function start(e){ e.preventDefault(); drawing = true; last = pos(e); }
		function move(e){
			if(!drawing) return; e.preventDefault();
			var p = pos(e);
			ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
			last = p; empty = false; canvas.classList.remove('is-empty');
			doBtn.disabled = !(consent.checked && !empty);
		}
		function end(){ drawing = false; }

		canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move);
		window.addEventListener('mouseup', end);
		canvas.addEventListener('touchstart', start, {passive:false});
		canvas.addEventListener('touchmove', move, {passive:false});
		canvas.addEventListener('touchend', end);

		clearBtn.addEventListener('click', function(){
			ctx.clearRect(0,0,canvas.width,canvas.height); empty = true;
			canvas.classList.add('is-empty'); doBtn.disabled = true;
		});
		consent.addEventListener('change', function(){ doBtn.disabled = !(consent.checked && !empty); });

		doBtn.addEventListener('click', function(){
			if(empty || !consent.checked) return;
			doBtn.disabled = true; doBtn.textContent = 'Αποστολή…';
			var data = canvas.toDataURL('image/png');
			fetch(SIGN, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ signature:data, consent:true }) })
				.then(function(r){ return r.json(); })
				.then(function(res){
					if(res && res.ok){ load(); }
					else { doBtn.disabled=false; doBtn.textContent='Υπογραφή & Αποστολή'; alert((res && res.error) || 'Αποτυχία.'); }
				})
				.catch(function(){ doBtn.disabled=false; doBtn.textContent='Υπογραφή & Αποστολή'; alert('Σφάλμα δικτύου.'); });
		});

		window.addEventListener('resize', function(){ /* keep simple: no redraw persistence */ });
	}
})();
</script>
</body>
</html>
		<?php
		exit;
	}
}
