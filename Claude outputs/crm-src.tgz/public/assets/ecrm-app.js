import { api, esc, fetch, H, toast } from '@energy-crm/util';
import { wire } from '@energy-crm/navigate';
import { count as queueCount, flush as queueFlush, forget as queueForget, onChange as onQueueChange, pending as queuePending, purgeExpired, retryNow } from '@energy-crm/queue';
import { openDetail } from '@energy-crm/view-detail';
import { loadContracts, setContractsFilter } from '@energy-crm/view-contracts';
import { loadPending } from '@energy-crm/view-pending';
import { loadDocuments } from '@energy-crm/view-documents';
import { loadCommissions } from '@energy-crm/view-commissions';
import { loadAnalytics } from '@energy-crm/view-analytics';
import { loadLeads } from '@energy-crm/view-leads';
import { loadRenewals } from '@energy-crm/view-renewals';
import { loadTasks } from '@energy-crm/view-tasks';
import { loadCalc } from '@energy-crm/view-calc';
import { loadCustomers } from '@energy-crm/view-customers';
import { loadDashboard } from '@energy-crm/view-dashboard';
import { initImport } from '@energy-crm/view-import';
import { loadKB } from '@energy-crm/view-kb';
import { loadTraining } from '@energy-crm/view-training';
import { loadNetwork } from '@energy-crm/view-network';
import { loadTeam } from '@energy-crm/view-team';
import { openPartner } from '@energy-crm/view-partner';
import { openCustomerCard } from '@energy-crm/view-customer-card';
import { loadTeamLive } from '@energy-crm/view-team-live';
import { loadEscalations } from '@energy-crm/view-escalations';

/* Energy CRM — το κέλυφος, και μόνο αυτό.
 *
 * Ό,τι απέμεινε αφού το Βήμα 9 έβγαλε τις δεκαπέντε οθόνες σε δικά τους
 * modules: η δρομολόγηση (hash ↔ όψη), το συρτάρι του κινητού, η καθολική
 * αναζήτηση της μπάρας, το καμπανάκι ειδοποιήσεων, και το boot.
 *
 * Το go() είναι ο ένας πίνακας που ξέρει ποια συνάρτηση φορτώνει ποια οθόνη.
 * Είναι σκόπιμα βαρετός: κάθε γραμμή του είναι ένα import, οπότε το γράφημα
 * εξαρτήσεων διαβάζεται από την κορυφή του αρχείου χωρίς να ψάξει κανείς.
 *
 * Οι τρεις συναρτήσεις που έχουν ανάγκη οι όψεις — go, openDetail, openEdit —
 * δίνονται μία φορά στο @energy-crm/navigate με wire(). Καμία όψη δεν εισάγει
 * το κέλυφος· έτσι δεν κλείνει κύκλος.
 *
 * Εξαρτάται από το ECRM (rest, nonce) και το window.ECRMForm (init της φόρμας). */
(function () {
	'use strict';

	var app = document.getElementById('ecrm-app');
	if (!app || typeof ECRM === 'undefined') return;

	// ---- routing ----------------------------------------------------------
	var loaded = {};
	var VIEWS = ['dashboard','new-contract','leads','contracts','pending','documents','tasks','customers','renewals','network','team','commissions','calc','kb','teamlive','escalations','analytics','import'];
	var suppressHash = false;
	function go(view) {
		app.setAttribute('data-view', view);
		app.querySelectorAll('.ecrm-view').forEach(function (v) { v.classList.toggle('is-active', v.getAttribute('data-view') === view); });
		app.querySelectorAll('.ecrm-nav__item[data-go]').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-go') === view); });
		window.scrollTo({ top: 0, behavior: 'smooth' });
		if (!suppressHash && VIEWS.indexOf(view) >= 0) {
			try { if (location.hash.slice(1) !== view) history.pushState({ v: view }, '', '#' + view); } catch (e) {}
		}

		if (view === 'dashboard') loadDashboard();
		if (view === 'contracts') loadContracts();
		if (view === 'team') loadTeam();
		if (view === 'network') loadNetwork();
		if (view === 'import') initImport();
		if (view === 'commissions') loadCommissions();
		if (view === 'analytics') loadAnalytics();
		if (view === 'teamlive') loadTeamLive();
		if (view === 'escalations') loadEscalations();
		if (view === 'calc') loadCalc();
		if (view === 'kb') loadKB();
		if (view === 'training') loadTraining();
		if (view === 'leads') loadLeads();
		if (view === 'customers') loadCustomers();
		if (view === 'pending') loadPending();
		if (view === 'documents') loadDocuments();
		if (view === 'tasks') loadTasks();
		if (view === 'renewals') loadRenewals();
		if (view === 'new-contract' && !loaded.form) {
			var formRoot = app.querySelector('.ecrm-view[data-view="new-contract"] .ecrm-form');
			if (formRoot && window.ECRMForm) { window.ECRMForm.init(formRoot); loaded.form = true; }
		}
	}
	// ---- offline banner (docs/OFFLINE-MODEL.md §2Β) ------------------------
	// Ρητό αίτημα ιδιοκτήτη (08/09): σήμερα μια αποτυχία δικτύου δείχνει απλά
	// «Σφάλμα δικτύου» -- ο συνεργάτης το διαβάζει σαν «κάτι χάλασε», όχι σαν
	// «είσαι offline, θα φύγει μόλις γυρίσει». Το banner μένει ΟΣΟ διαρκεί η
	// αποσύνδεση -- δεν είναι toast (4 δευτερόλεπτα, ένα συμβάν που πέρασε),
	// είναι κατάσταση που συνεχίζεται μέχρι να αλλάξει.
	//
	// navigator.onLine + events online/offline, τίποτα παραπάνω -- ρητή
	// επιλογή του OFFLINE-MODEL.md, όχι δικό μου heartbeat/ping. Είναι γνωστό
	// αναξιόπιστο (π.χ. συνδεδεμένος σε LAN χωρίς πραγματικό internet δείχνει
	// online) αλλά φθηνό και σωστό στη μεγάλη πλειοψηφία -- «σήκωσε/έπεσε το
	// wifi/δεδομένα», που είναι το πραγματικό σενάριο εδώ.
	var offlineEl = app.querySelector('#ecrm-offline');
	var wasOffline = !navigator.onLine;
	function paintOnline() {
		if (!offlineEl) return;
		offlineEl.hidden = navigator.onLine;
	}
	window.addEventListener('online', function () {
		paintOnline();
		// Toast μόνο αν πράγματι ήμασταν offline -- ένα «Η σύνδεση επανήλθε»
		// σε κάθε φόρτωση σελίδας (ήδη online) θα ήταν θόρυβος χωρίς νόημα.
		if (wasOffline) { toast('Η σύνδεση επανήλθε.'); }
		wasOffline = false;
		drainQueue();
	});
	window.addEventListener('offline', function () {
		wasOffline = true;
		paintOnline();
	});
	paintOnline();

	// ---- ουρά εκτός σύνδεσης (docs/OFFLINE-MODEL.md §2Δ) -------------------
	// Το κέλυφος είναι το ΜΟΝΟ σημείο που ξέρει για την ουρά συνολικά: η φόρμα
	// βάζει μέσα, εδώ αδειάζει. Ο λόγος είναι ότι η φόρμα ζει μόνο όσο ο
	// συνεργάτης βρίσκεται στην οθόνη «Νέα Σύμβαση», ενώ οι αιτήσεις πρέπει να
	// φεύγουν όποια οθόνη κι αν κοιτά -- και ιδίως όταν δεν κοιτά καμία.
	var queueEl   = app.querySelector('#ecrm-queue');
	var queueText = app.querySelector('[data-queue-text]');
	var queueBtn  = app.querySelector('[data-queue-retry]');

	function paintQueue(n) {
		if (!queueEl) { return; }

		queueEl.hidden = n === 0;

		if (n > 0 && queueText) {
			queueText.textContent = n === 1
				? 'Μία αίτηση δεν έχει σταλεί ακόμα.'
				: n + ' αιτήσεις δεν έχουν σταλεί ακόμα.';
		}
	}

	function drainQueue() {
		return queueFlush().then(function (rep) {
			if (rep.sent) {
				toast(rep.sent === 1 ? 'Στάλθηκε 1 αίτηση σε αναμονή.' : 'Στάλθηκαν ' + rep.sent + ' αιτήσεις σε αναμονή.');
			}

			// Το nonce έχει λήξει (ή έφυγε το cookie). Το (259) έδειξε ότι
			// φρέσκο nonce έρχεται σε κάθε ΕΠΙΤΥΧΗ απάντηση -- εδώ όμως δεν
			// υπήρξε καμία επιτυχής απάντηση για ώρες, οπότε δεν υπάρχει
			// τίποτα να το ανανεώσει. Το ΜΟΝΟ που δουλεύει είναι νέα φόρτωση
			// σελίδας, που ξανατυπώνει nonce όσο ζει η σύνδεση του χρήστη.
			// Λέγεται όπως είναι· η σιωπηλή απόρριψη απαγορεύεται ρητά (§2Δ).
			if (rep.auth) {
				toast('Ανανέωσε τη σελίδα για να σταλούν οι αιτήσεις που περιμένουν.', false);
			}

			if (rep.blocked) {
				toast(rep.blocked === 1
					? 'Μία αίτηση απορρίφθηκε και περιμένει διόρθωση.'
					: rep.blocked + ' αιτήσεις απορρίφθηκαν και περιμένουν διόρθωση.', false);
			}

			return rep;
		});
	}

	if (queueBtn) {
		queueBtn.addEventListener('click', function (e) {
			// Δεν πρέπει το «Στείλε τώρα» να ανοιγοκλείνει και το πάνελ από
			// κάτω -- σταματά τη διάδοση όπως ακριβώς το καμπανάκι.
			e.stopPropagation();
			queueBtn.disabled = true;
			retryNow().finally(function () { queueBtn.disabled = false; });
		});
	}

	// ---- πάνελ ουράς (Επίπεδο Ε, docs/UI-QUEUE-PANEL.html, εγκρίθηκε 09/09) --
	// Ίδιο σχήμα με το πάνελ ειδοποιήσεων (bellPanel) παρακάτω -- ίδιο μοτίβο
	// ανοίγματος/κλεισίματος, καμία νέα αφαίρεση. Μόνη ενέργεια πάνω σε
	// μπλοκαρισμένη εγγραφή είναι η διαγραφή (forget) -- σκόπιμα καμία inline
	// επεξεργασία (βλ. σημείωση στη μακέτα).
	var queuePanelToggle = app.querySelector('[data-queue-toggle]');
	var queuePanelEl     = app.querySelector('[data-queue-panel]');
	var queuePanelCount  = app.querySelector('[data-queue-panel-count]');
	var queuePanelList   = app.querySelector('[data-queue-panel-list]');

	function queueItemLabel(r) {
		if (r.payload) {
			var name = ((r.payload.first_name || '') + ' ' + (r.payload.last_name || '')).trim() || 'Χωρίς όνομα';
			return name + (r.payload.afm ? ' — ΑΦΜ ' + r.payload.afm : '');
		}
		// Εγγραφή μόνο-αρχείων (enqueueFiles) -- η σύμβαση ήδη υπάρχει, δεν
		// υπάρχει payload να διαβάσουμε όνομα/ΑΦΜ από αυτό.
		return 'Έγγραφα για σύμβαση #' + r.contractId;
	}

	function renderQueuePanel() {
		if (!queuePanelEl || !queuePanelList) return;

		queuePending().then(function (records) {
			if (queuePanelCount) {
				queuePanelCount.textContent = records.length === 1 ? '1 αίτηση' : records.length + ' αιτήσεις';
			}

			if (!records.length) {
				queuePanelList.innerHTML = '<div class="ecrm-queuepanel__empty">Καμία αίτηση σε αναμονή</div>';
				return;
			}

			queuePanelList.innerHTML = records.map(function (r) {
				var name = esc(queueItemLabel(r));
				var html = '<div class="ecrm-queueitem' + (r.blocked ? ' is-blocked' : '') + '">' +
					'<div class="ecrm-queueitem__dot"></div>' +
					'<div class="ecrm-queueitem__main">' +
					'<span class="ecrm-queueitem__name">' + name + '</span>';

				if (r.blocked) {
					html += '<span class="ecrm-queueitem__meta">Απορρίφθηκε από τον server</span>' +
						'<span class="ecrm-queueitem__err">' + esc(r.lastError || '') + '</span>' +
						'<div class="ecrm-queueitem__actions">' +
						'<button type="button" class="ecrm-queueitem__del" data-queue-del="' + r.id + '">Διαγραφή</button>' +
						'</div>';
				} else {
					html += '<span class="ecrm-queueitem__meta">Σε αναμονή δικτύου · θα σταλεί αυτόματα</span>';
				}

				html += '</div></div>';
				return html;
			}).join('');

			queuePanelList.querySelectorAll('[data-queue-del]').forEach(function (b) {
				b.addEventListener('click', function () {
					var id = this.getAttribute('data-queue-del');
					// Ίδιο μοτίβο με τη διαγραφή αρχείου στη φόρμα -- ένα
					// window.confirm() αρκεί, καμία δική του συνιστώσα διαλόγου.
					if (!window.confirm('Η αίτηση θα διαγραφεί οριστικά — δεν θα σταλεί ποτέ, ούτε τα έγγραφά της. Συνέχεια;')) {
						return;
					}
					queueForget(id).then(renderQueuePanel);
				});
			});
		});
	}

	if (queuePanelToggle) {
		queuePanelToggle.addEventListener('click', function (e) {
			e.stopPropagation();
			if (queuePanelEl) {
				queuePanelEl.hidden = !queuePanelEl.hidden;
				queuePanelToggle.setAttribute('aria-expanded', queuePanelEl.hidden ? 'false' : 'true');
				if (!queuePanelEl.hidden) { renderQueuePanel(); }
			}
		});
		document.addEventListener('click', function (e) {
			if (queuePanelEl && !queuePanelEl.hidden && !queuePanelEl.contains(e.target) &&
				e.target !== queuePanelToggle && !queuePanelToggle.contains(e.target)) {
				queuePanelEl.hidden = true;
				queuePanelToggle.setAttribute('aria-expanded', 'false');
			}
		});
	}

	onQueueChange(function (n) {
		paintQueue(n);
		// Το πάνελ ξαναζωγραφίζεται μόνο όσο είναι ανοιχτό -- ίδια λογική με
		// το loadBell() παρακάτω (κλειστό πάνελ = καμία δουλειά μέχρι το
		// επόμενο άνοιγμα).
		if (queuePanelEl && !queuePanelEl.hidden) { renderQueuePanel(); }
	});
	queueCount().then(paintQueue);

	// Ο,τι πέρασε το TTL φεύγει πριν από κάθε άλλη κουβέντα -- και ο
	// συνεργάτης το μαθαίνει, γιατί «έληξε και σβήστηκε» είναι ακριβώς το
	// είδος του γεγονότος που δεν επιτρέπεται να συμβεί σιωπηλά.
	purgeExpired().then(function (n) {
		if (n) {
			toast(n === 1
				? 'Μία αίτηση σε αναμονή έληξε και διαγράφηκε — δεν στάλθηκε.'
				: n + ' αιτήσεις σε αναμονή έληξαν και διαγράφηκαν — δεν στάλθηκαν.', false);
		}

		return drainQueue();
	}).catch(function () {});

	// ---- εμφάνιση: ανοιχτό / σκούρο -----------------------------------------
	// Το data-theme το γράφει ήδη η PHP στο ίδιο το .ecrm, οπότε εδώ μένει μόνο
	// η εναλλαγή. Αλλάζει ΠΡΩΤΑ η οθόνη και μετά ειδοποιείται ο διακομιστής: ο
	// χρήστης δεν περιμένει δίκτυο για να δει το κλικ του. Αν το POST αποτύχει,
	// η επιλογή ισχύει για τη συνεδρία και χάνεται στο επόμενο refresh — δεν
	// γυρίζουμε την οθόνη πίσω, γιατί ένα φλας είναι χειρότερο από μια χαμένη
	// προτίμηση.
	// Ένα μόνο σημείο εναλλαγής πλέον — ο διακόπτης του topbar (23/08, το παλιό
	// κουμπί στο footer του πλαϊνού μενού αφαιρέθηκε). querySelectorAll μένει
	// ούτως ή άλλως ανεκτικό αν ξαναχρειαστεί δεύτερο σημείο κάποια στιγμή.
	var themeBtns = app.querySelectorAll('[data-theme-toggle]');
	themeBtns.forEach(function (themeBtn) {
		themeBtn.addEventListener('click', function () {
			var next = app.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
			app.setAttribute('data-theme', next);
			themeBtns.forEach(function (b) {
				if (b.hasAttribute('aria-checked')) b.setAttribute('aria-checked', next === 'dark' ? 'true' : 'false');
			});
			fetch(api('/theme'), {
				method: 'POST',
				headers: Object.assign({ 'Content-Type': 'application/json' }, H()),
				body: JSON.stringify({ theme: next })
			// Best-effort: το tab άλλαξε ήδη οπτικά. Αν δεν αποθηκευτεί η
			// προτίμηση, το επόμενο load απλά ξαναδείχνει το προηγούμενο θέμα.
			}).catch(function () {});
		});
	});

	app.addEventListener('click', function (e) {
		var btn = e.target.closest('[data-go]');
		if (!btn) return;
		e.preventDefault();
		var g = btn.getAttribute('data-go');
		// Ένα KPI που ξέρει ποια κατάσταση δείχνει φιλτράρει τη λίστα αντί απλώς
		// να τη δείχνει. Μπαίνει ΠΡΙΝ το go(), γιατί το go() είναι που φορτώνει —
		// αλλιώς θα γινόταν δεύτερο fetch για ένα κλικ.
		if (g === 'contracts' && btn.hasAttribute('data-status')) {
			setContractsFilter(btn.getAttribute('data-status'));
		}
		// Clicking the sidebar "Νέα Σύμβαση" starts a fresh form -- ΑΛΛΑ
		// όχι σιωπηλά πάνω σε μια ήδη μισο-συμπληρωμένη: αναφέρθηκε 06/09 σαν
		// μέρος του ίδιου προβλήματος με το beforeunload (ecrm-form.js) --
		// εκεί προστατεύει από refresh/κλείσιμο, εδώ από αυτό το ΙΔΙΟ κλικ.
		if (g === 'new-contract' && btn.classList.contains('ecrm-nav__item') && window.ECRMForm && window.ECRMForm.reset) {
			if (window.ECRMForm.isDirty && window.ECRMForm.isDirty() &&
				!window.confirm('Η τρέχουσα αίτηση έχει μη αποθηκευμένες αλλαγές. Να ξεκινήσει νέα αίτηση και να χαθούν;')) {
				return;
			}
			window.ECRMForm.reset();
		}
		go(g);
	});

	// Sidebar collapse (persisted).
	try { if (localStorage.getItem('ecrm_sidebar') === '1') app.setAttribute('data-collapsed', '1'); } catch (e) {}
	var collapseBtn = app.querySelector('[data-collapse]');
	if (collapseBtn) collapseBtn.addEventListener('click', function () {
		var on = app.getAttribute('data-collapsed') === '1';
		app.setAttribute('data-collapsed', on ? '0' : '1');
		try { localStorage.setItem('ecrm_sidebar', on ? '0' : '1'); } catch (e) {}
	});

	// «Περισσότερα» στο πλαϊνό μενού — πρόταση #2 του χαμηλής-εξοικείωσης πάσου
	// (docs/UI-NAV-MORE-COLLAPSE.html, εγκρίθηκε 23/08). Ανοιχτό από προεπιλογή
	// ΜΟΝΟ όσο δεν υπάρχει καμία αποθηκευμένη προτίμηση — δηλαδή στο πρώτο login
	// κάποιου, ώστε καμία διαδρομή να μη χαθεί αναξήτητα· μετά θυμάται ό,τι
	// διάλεξε ο χρήστης, ανοιχτό ή κλειστό.
	var moreBtn = app.querySelector('[data-nav-more-toggle]');
	var moreBody = app.querySelector('[data-nav-more-body]');
	if (moreBtn && moreBody) {
		var moreOpen = true;
		try {
			var saved = localStorage.getItem('ecrm_nav_more');
			if (saved !== null) moreOpen = saved === '1';
		} catch (e) {}
		function paintMore() {
			moreBtn.setAttribute('aria-expanded', moreOpen ? 'true' : 'false');
			moreBody.classList.toggle('is-open', moreOpen);
		}
		paintMore();
		moreBtn.addEventListener('click', function () {
			moreOpen = !moreOpen;
			paintMore();
			try { localStorage.setItem('ecrm_nav_more', moreOpen ? '1' : '0'); } catch (e) {}
		});
	}

	// ---- mobile nav drawer (off-canvas) ----------------------------------
	var mq = window.matchMedia('(max-width: 860px)');
	function closeMob() { app.removeAttribute('data-mobnav'); }
	var mobToggle = app.querySelector('[data-mobnav-toggle]');
	if (mobToggle) mobToggle.addEventListener('click', function () {
		app.setAttribute('data-mobnav', app.getAttribute('data-mobnav') === '1' ? '0' : '1');
	});
	app.querySelectorAll('[data-mobnav-close]').forEach(function (b) { b.addEventListener('click', closeMob); });
	app.querySelectorAll('.ecrm-nav__item[data-go]').forEach(function (b) {
		b.addEventListener('click', function () { if (mq.matches) closeMob(); });
	});

	// ---- global search (topbar) ------------------------------------------
	var gEl = app.querySelector('[data-gsearch]');
	var gRes = app.querySelector('[data-gsearch-results]');
	var gT;
	if (gEl && gRes) {
		function gRender(list) {
			if (!list.length) { gRes.innerHTML = '<div class="ecrm-gsearch__empty">Κανένα αποτέλεσμα.</div>'; gRes.hidden = false; return; }
			gRes.innerHTML = list.map(function (r) {
				return '<button type="button" class="ecrm-gsearch__row" data-gid="' + r.id + '">' +
					'<span class="ecrm-gsearch__main">' + esc(r.customer) + (r.afm ? ' · ' + esc(r.afm) : '') + '</span>' +
					'<span class="ecrm-gsearch__meta">' + esc(r.code || '') + (r.provider ? ' · ' + esc(r.provider) : '') +
					' <span class="ecrm-badge ecrm-badge--' + esc(r.status) + '">' + esc(r.status_label) + '</span></span></button>';
			}).join('');
			gRes.hidden = false;
			gRes.querySelectorAll('[data-gid]').forEach(function (b) {
				b.addEventListener('click', function () {
					var id = +this.getAttribute('data-gid');
					gRes.hidden = true; gEl.value = '';
					if (typeof go === 'function') go('contracts');
					setTimeout(function () { openDetail(id); }, 50);
				});
			});
		}
		gEl.addEventListener('input', function () {
			var q = this.value.trim();
			clearTimeout(gT);
			if (q.length < 2) { gRes.hidden = true; return; }
			gT = setTimeout(function () {
				fetch(api('/search') + '?q=' + encodeURIComponent(q), { headers: H() })
					.then(function (r) { return r.json(); })
					.then(function (d) { if (d && d.ok) gRender(d.results || []); })
					// Background αναζήτηση: αποτυχία σημαίνει απλά καμία λίστα
					// αποτελεσμάτων -- δεν υπάρχει κάτι να γυρίσει πίσω.
					.catch(function () {});
			}, 250);
		});
		document.addEventListener('click', function (e) {
			if (!gEl.contains(e.target) && !gRes.contains(e.target)) gRes.hidden = true;
		});
	}

	// ---- notifications bell ----------------------------------------------
	var bellBtn = app.querySelector('[data-bell]');
	var bellPanel = app.querySelector('[data-bellpanel]');
	var bellBadge = app.querySelector('[data-bell-badge]');

	function loadBell() {
		if (!bellBtn) return;
		fetch(api('/notifications'), { headers: H() })
			.then(function (r) { return r.json(); })
			.then(function (d) {
				if (!d || !d.ok) return;
				renderBell(d);
			})
			// Polling: αν αποτύχει, το κουδούνι μένει στην τελευταία γνωστή
			// κατάσταση μέχρι το επόμενο loadBell().
			.catch(function () {});
	}

	function renderBell(d) {
		var stale = d.stale || 0;
		var unread = d.unread || 0;
		if (bellBadge) {
			var total = stale + unread;
			if (total > 0) { bellBadge.hidden = false; bellBadge.textContent = total > 99 ? '99+' : total; }
			else { bellBadge.hidden = true; }
		}
		if (!bellPanel) return;
		var notifs = (d.notifs || []);
		var rows = (d.rows || []);
		var html = '';

		if (notifs.length) {
			html += '<div class="ecrm-bellpanel__head"><b>Ειδοποιήσεις</b><span>' + (unread ? unread + ' νέες' : '') + '</span></div>';
			html += '<div class="ecrm-bellpanel__list">' + notifs.slice(0, 10).map(function (n) {
				return '<button type="button" class="ecrm-bellitem' + (n.read ? '' : ' is-stale') + '" data-bell-open="' + n.contract_id + '">' +
					'<span class="ecrm-bellitem__dot ecrm-badge--processing"></span>' +
					'<span class="ecrm-bellitem__main"><span class="ecrm-bellitem__name">' + esc(n.title) + '</span>' +
					'<span class="ecrm-bellitem__meta">' + esc(n.body || '') + '</span></span></button>';
			}).join('') + '</div>';
		}

		html += '<div class="ecrm-bellpanel__head"><b>Εκκρεμότητες</b><span>' + (stale ? stale + ' πάνω από ' + d.threshold + ' ημέρες' : 'όλα εντάξει') + '</span></div>';
		if (!rows.length) {
			html += '<div class="ecrm-bellpanel__empty">Καμία ανοιχτή σύμβαση</div>';
		} else {
			html += '<div class="ecrm-bellpanel__list">' + rows.slice(0, 12).map(function (r) {
				return '<button type="button" class="ecrm-bellitem' + (r.stale ? ' is-stale' : '') + '" data-bell-open="' + r.id + '">' +
					'<span class="ecrm-bellitem__dot ecrm-badge--' + esc(r.status) + '"></span>' +
					'<span class="ecrm-bellitem__main"><span class="ecrm-bellitem__name">' + esc(r.customer) + '</span>' +
					'<span class="ecrm-bellitem__meta">' + esc(r.code || '') + ' · ' + esc(r.status_label) + '</span></span>' +
					'<span class="ecrm-bellitem__age">' + r.age_days + 'η</span></button>';
			}).join('') + '</div>';
		}
		bellPanel.innerHTML = html;
		bellPanel.querySelectorAll('[data-bell-open]').forEach(function (b) {
			b.addEventListener('click', function () { bellPanel.hidden = true; openDetail(this.getAttribute('data-bell-open')); });
		});

		// Ρητό αίτημα ιδιοκτήτη (06/09): «μόλις πατήσω το καμπανάκι να φεύγουν»
		// -- και οι δύο μετρητές, όχι μόνο οι αποθηκευμένες ειδοποιήσεις. Ο
		// αριθμός μηδενίζει αμέσως εδώ (οπτικά, αισιόδοξα)· ο server
		// φωτογραφίζει τις τρέχουσες εκκρεμότητες ξεχωριστά (βλ.
		// ECRM_Notifications::dismiss_stale_for()) ώστε να ξαναμετρηθούν
		// μόνο αν πραγματικά αλλάξει κάτι πάνω τους -- καμία σύμβαση δεν
		// χάνεται, απλά σταματά να χτυπάει το καμπανάκι γι' αυτήν.
		if ((unread > 0 || stale > 0) && bellPanel && !bellPanel.hidden) {
			fetch(api('/notifications/read'), { method: 'POST', headers: H() })
				.then(function () { if (bellBadge) { bellBadge.hidden = true; } })
				// Best-effort: το badge έμεινε ήδη σωστό οπτικά· αν η σήμανση
				// read στο server αποτύχει, θα ξανασταλεί στο επόμενο άνοιγμα.
				.catch(function () {});
		}
	}

	if (bellBtn) {
		bellBtn.addEventListener('click', function (e) {
			e.stopPropagation();
			if (bellPanel) { bellPanel.hidden = !bellPanel.hidden; if (!bellPanel.hidden) loadBell(); }
		});
		document.addEventListener('click', function (e) {
			if (bellPanel && !bellPanel.hidden && !bellPanel.contains(e.target) && e.target !== bellBtn && !bellBtn.contains(e.target)) {
				bellPanel.hidden = true;
			}
		});
		loadBell();
		setInterval(function () { if (bellPanel && bellPanel.hidden) { loadBell(); } }, 60000);
	}

	function openEdit(c) {
		// Ίδιος έλεγχος με το κλικ στο "Νέα Σύμβαση" παραπάνω: το άνοιγμα
		// επεξεργασίας ΑΛΛΗΣ σύμβασης καλεί reset() πριν το prefill -- χωρίς αυτό
		// θα έσβηνε σιωπηλά μια μισο-συμπληρωμένη νέα αίτηση.
		if (window.ECRMForm && window.ECRMForm.isDirty && window.ECRMForm.isDirty() &&
			!window.confirm('Η τρέχουσα αίτηση έχει μη αποθηκευμένες αλλαγές. Να ανοίξει η επεξεργασία και να χαθούν;')) {
			return;
		}
		go('new-contract');
		if (window.ECRMForm && window.ECRMForm.edit) {
			// Clear whatever a previous edit session left behind before
			// prefilling this contract. Without this, a field this contract
			// doesn't have (e.g. price_type, father_name, a supply address)
			// keeps whatever the last-opened contract left in the DOM, and
			// collect() sends it on save as though it belonged here —
			// confirmed live on crm-test, CHANGELOG 2026-08-16 (4)/(5).
			if (window.ECRMForm.reset) { window.ECRMForm.reset(); }
			// give the view a tick to become visible, then prefill
			setTimeout(function () { window.ECRMForm.edit(c); }, 30);
		}
	}

	// The three the views are allowed to call, handed over once. They are
	// declared above rather than imported, so this is the only place the
	// direction of the dependency is decided — see ecrm-navigate.js.
	wire({
		go: go, openDetail: openDetail, openEdit: openEdit, openPartner: openPartner,
		openCustomerCard: openCustomerCard,
		// Build queue 08, 25/08 — παραμένει για το "match card" της φόρμας
		// (βλ. ContractSaveController): εκεί δεν υπάρχει customer id έτοιμο
		// πριν την αποθήκευση, μόνο το ΑΦΜ, οπότε η φόρμα ανοίγει τη λίστα
		// συμβάσεων φιλτραρισμένη σε αυτό. Build queue 09, 05/09 πρόσθεσε την
		// ίδια την καρτέλα πελάτη (openCustomerCard) -- τη χρησιμοποιεί η
		// λίστα «Πελάτες», που έχει customer id σε κάθε γραμμή.
		openCustomerContracts: function (q) { setContractsFilter('', q); go('contracts'); },
	});

		// ---- boot -------------------------------------------------------------
	// Back/forward navigation via URL hash.
	window.addEventListener('popstate', function () {
		var v = (location.hash || '').slice(1);
		if (VIEWS.indexOf(v) < 0) v = 'dashboard';
		suppressHash = true; go(v); suppressHash = false;
	});

	// Initial view: respect a #hash so links are copy/paste-able and bookmarkable.
	(function () {
		var v = (location.hash || '').slice(1);
		if (VIEWS.indexOf(v) < 0) v = 'dashboard';
		suppressHash = true; go(v); suppressHash = false;
	})();
})();
