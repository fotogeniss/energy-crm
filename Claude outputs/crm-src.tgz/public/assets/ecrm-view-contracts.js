/* Energy CRM — η λίστα συμβάσεων.
 *
 * Η μεγαλύτερη οθόνη του CRM και η τελευταία που έμενε στο κέλυφος: καρτέλες
 * κατάστασης με μετρητές, αναζήτηση, αποθηκευμένα φίλτρα, σελιδοποίηση στον
 * client, ανάπτυξη γραμμής, και μαζικές ενέργειες.
 *
 * Το contractsState μένει εδώ γιατί εδώ ανήκει — εκτός από το scope, που το
 * μοιράζεται με τις Εκκρεμότητες και γι' αυτό ζει στο @energy-crm/scope.
 * Δες το docblock εκεί: αν έμενε ιδιότητα αυτού του αρχείου, οι Εκκρεμότητες
 * θα εισήγαγαν τη λίστα συμβάσεων για να διαβάσουν μία λέξη.
 *
 * Η σελιδοποίηση είναι στον client: το /contracts επιστρέφει όλες τις γραμμές
 * του φίλτρου και κόβονται εδώ. Δουλεύει επειδή τα φίλτρα κρατάνε το σύνολο
 * μικρό· αν ποτέ μια σελίδα αργήσει, το πρόβλημα είναι εδώ και όχι στο δίκτυο. */

import { api, can, esc, fetch, H, toast, viewEl } from '@energy-crm/util';
import { fmtDate, initials, svgIcon, timeAgo, tint, up } from '@energy-crm/format';
import { openDetail, openEdit } from '@energy-crm/navigate';
import { openExportModal } from '@energy-crm/export-modal';
import { confirmTyped, confirmTypedWithReason } from '@energy-crm/dialog';
import { scope, setScope } from '@energy-crm/scope';

var contractsState = { status: '', q: '', page: 1, pageSize: 12 };

/* Ορίζει το φίλτρο κατάστασης από ΕΞΩ, χωρίς να φορτώσει.
 *
 * Το καλεί το κέλυφος όταν πατηθεί ένα KPI του dashboard που ξέρει ποια
 * κατάσταση δείχνει. Δεν φορτώνει μόνο του επίτηδες: το go('contracts') που
 * ακολουθεί είναι που φορτώνει, και δύο fetch για ένα κλικ είναι σπατάλη σε
 * σύστημα με 20-40 ταυτόχρονες αιτήσεις. */
export function setContractsFilter(status, q) {
	contractsState.status = typeof status === 'string' ? status : '';
	// q προαιρετικό — προστέθηκε 25/08 (build queue 08) για το
	// openCustomerContracts(): οι προϋπάρχουσες κλήσεις με ένα όρισμα (τα KPI
	// του dashboard) συνεχίζουν να αφήνουν την αναζήτηση όπως ήταν.
	if (typeof q === 'string') contractsState.q = q;
	contractsState.page = 1;
}

export function loadContracts() {
	var view = viewEl('contracts');
	var url = api('/contracts') + '?status=' + encodeURIComponent(contractsState.status) + '&q=' + encodeURIComponent(contractsState.q) + '&scope=' + encodeURIComponent(scope());
	fetch(url, { headers: H() })
		.then(function (r) { return r.json(); })
		.then(function (d) { renderContracts(view, d); })
		.catch(function () { view.innerHTML = '<div class="ecrm-card"><div class="ecrm-empty">Σφάλμα φόρτωσης.</div></div>'; });
}

var expandCache = {};
function loadExpand(id, view) {
	var box = view.querySelector('[data-exppanel="' + id + '"]');
	if (!box) return;
	if (expandCache[id]) { box.innerHTML = expandPanel(expandCache[id], view); bindExpand(box, expandCache[id], view); return; }
	fetch(api('/contracts/' + id), { headers: H() })
		.then(function (r) { return r.json(); })
		.then(function (d) {
			if (!d || !d.ok) { box.innerHTML = '<div class="ecrm-empty">Σφάλμα φόρτωσης.</div>'; return; }
			expandCache[id] = d.contract || d;
			box.innerHTML = expandPanel(expandCache[id], view);
			bindExpand(box, expandCache[id], view);
		})
		.catch(function () { box.innerHTML = '<div class="ecrm-empty">Σφάλμα δικτύου.</div>'; });
}

function expandPanel(c, view) {
	var statuses = (window.ECRM && ECRM.statuses) || {};
	var stLabel = statuses[c.status] || c.status;
	var name = c.company_name || ((c.first_name || '') + ' ' + (c.last_name || '')).trim() || '—';
	var mobile = c.mobile || c.phone || '';
	var dl = function (l, v) { return '<div class="ecrm-tr"><span>' + l + '</span><b>' + (v ? esc(v) : '—') + '</b></div>'; };

	var banner =
		'<div class="ecrm-expbanner ecrm-expbanner--' + esc(c.status) + '">' +
		'<span class="ecrm-expbanner__ico">' + (c.status === 'draft' ? '<svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/></svg>' : (c.status === 'cancelled' || c.status === 'terminated' ? '✕' : '!')) + '</span>' +
		'<div><div class="ecrm-expbanner__eyebrow">' + esc(up(stLabel)) + '</div>' +
		'<div class="ecrm-expbanner__title">' + esc(stLabel) + ' για ' + esc(name) + '</div>' +
		'<div class="ecrm-expbanner__sub">Δημιουργήθηκε: <b>' + fmtDate(c.created_at) + '</b> · Αριθμός συμβολαίου: <b>' + esc(c.code || '—') + '</b></div></div></div>';

	var cards =
		'<div class="ecrm-expcards">' +
		'<div class="ecrm-card"><div class="ecrm-step">Στοιχεία πελάτη</div>' + dl('Ονοματεπώνυμο', name) + dl('ΑΦΜ', c.afm) + dl('Κινητό', mobile) + '</div>' +
		// Ίδιο θέμα με το (112) στο ecrm-view-detail.js, εδώ στο πλαϊνό
		// «άνοιγμα» της λίστας: καμία φόρμα Orizon δεν συλλέγει ΗΚΑΣΠ/Παροχή
		// ή Τιμολόγιο — δύο γραμμές πάντα «—» σε κάθε αίτηση κινητής, με
		// τίτλο «Παροχή» που δεν έχει καν νόημα όταν δεν μένει τίποτα άλλο.
		'<div class="ecrm-card"><div class="ecrm-step">' +
		(c.energy_type === 'mobile' ? 'Πάροχος' : 'Παροχή') + '</div>' +
		(c.energy_type !== 'mobile'
			? dl('ΗΚΑΣΠ/Παροχή', c.supply_number) + dl('Τιμολόγιο', c.invoice_code)
			: '') +
		dl('Πάροχος', c.provider_name) + '</div>' +
		'<div class="ecrm-card"><div class="ecrm-step">Tracking</div>' + dl('Ημ. δημιουργίας', fmtDate(c.created_at)) + dl('Ημ. Thalis', '') + dl('Ημ. Εκπροσώπησης', '') + dl('Ημ. Τερματισμού', '') + dl('Τελ. ενημέρωση', fmtDate(c.updated_at)) + '</div>' +
		'</div>';

	var phone = mobile || c.phone || '';
	var email = c.email || '';
	var viberNum = (phone || '').replace(/[^0-9+]/g, '');
	if (viberNum && viberNum.charAt(0) !== '+') { viberNum = '+30' + viberNum.replace(/^0+/, ''); }
	var actions = '<div class="ecrm-expactions">' +
		'<button type="button" class="ecrm-btn ecrm-btn--primary ecrm-btn--sm" data-exp-edit>' + svgIcon('edit') + ' Προβολή / Επεξεργασία</button>' +
		(phone ? '<a class="ecrm-btn ecrm-btn--ghost ecrm-btn--sm" href="tel:' + esc(phone) + '">' + svgIcon('phone') + ' Κάλεσε</a>' : '') +
		(viberNum ? '<a class="ecrm-btn ecrm-btn--viber ecrm-btn--sm" href="viber://chat?number=' + encodeURIComponent(viberNum) + '" target="_blank" rel="noopener">' + svgIcon('viber') + ' Viber</a>' : '') +
		(email ? '<a class="ecrm-btn ecrm-btn--ghost ecrm-btn--sm" href="mailto:' + esc(email) + '">' + svgIcon('mail') + ' Email</a>' : '') +
		// (191) Ίδιο κριτήριο διαγραφής με την καρτέλα αίτησης: ο server
		// (DeletionGate) αρνείται μόνο ό,τι υπογράφηκε ΠΟΤΕ, όχι ό,τι έχει
		// τρέχον status διαφορετικό από draft -- πριν έδειχνε το κουμπί ΜΟΝΟ
		// σε πρόχειρο, οπότε μια αίτηση «Σε επεξεργασία» που ποτέ δεν
		// υπογράφηκε δεν είχε ΚΑΜΙΑ επιλογή διαγραφής από εδώ.
		(can('ecrm_delete_contract') ? '<button type="button" class="ecrm-btn ecrm-btn--danger ecrm-btn--sm" data-exp-del>' + svgIcon('trash') + ' Διαγραφή</button>' : '') +
		'</div>';

	return banner + cards + actions;
}

function bindExpand(box, c, view) {
	var edit = box.querySelector('[data-exp-edit]');
	if (edit) edit.addEventListener('click', function () { openEdit(c); });
	var del = box.querySelector('[data-exp-del]');
	if (del) del.addEventListener('click', function () {
		var b = this;

		function doDelete() {
			b.disabled = true;
			fetch(api('/contracts/' + c.id), { method: 'DELETE', headers: H() })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (d && d.ok) { toast('Διαγράφηκε.'); delete expandCache[c.id]; loadContracts(); }
					// build queue #15: ίδιο σκεπτικό με το ecrm-view-detail.js
					// -- η δεύτερη πύλη ανοίγει μόνο μετά την άρνηση, μόνο
					// για admin, ξαναελέγχεται στον server.
					else if (d && d.code === 'was_signed' && window.ECRM && window.ECRM.isAdmin) {
						b.disabled = false;
						offerForceDelete(c, b);
					}
					else { toast((d && d.error) || 'Αποτυχία.', false); b.disabled = false; }
				})
				.catch(function () { toast('Σφάλμα δικτύου.', false); b.disabled = false; });
		}

		function offerForceDelete(c, b) {
			var hasCode = !!c.code;
			confirmTypedWithReason({
				eyebrow: 'Παράκαμψη admin',
				expect: hasCode ? String(c.code) : String(c.id),
				expectLabel: hasCode ? 'Πληκτρολόγησε τον κωδικό της αίτησης' : 'Πληκτρολόγησε τον αριθμό της αίτησης',
				reasonLabel: 'Γιατί χρειάζεται να διαγραφεί αυτή η υπογεγραμμένη σύμβαση;',
				title: 'Οριστική διαγραφή υπογεγραμμένης — ' + (c.code || ('#' + c.id)),
				lead: ['Αυτή η σύμβαση ', { b: 'υπογράφηκε' }, '. Η κανονική διαγραφή την αρνείται εσκεμμένα. Ως admin μπορείς να προχωρήσεις, αλλά η ενέργεια είναι ', { b: 'οριστική' }, ' και καταγράφεται μόνιμα ποιος, πότε και γιατί.'],
				confirm: 'Οριστική διαγραφή (admin)',
				onConfirm: function (reason) { doForceDelete(c, b, reason); },
			});
		}

		function doForceDelete(c, b, reason) {
			b.disabled = true;
			fetch(api('/contracts/' + c.id + '/force'), {
				method: 'DELETE',
				headers: Object.assign({ 'Content-Type': 'application/json' }, H()),
				body: JSON.stringify({ reason: reason }),
			})
				.then(function (r) { return r.json(); })
				.then(function (d) { if (d && d.ok) { toast('Διαγράφηκε.'); delete expandCache[c.id]; loadContracts(); } else { toast((d && d.error) || 'Αποτυχία.', false); b.disabled = false; } })
				.catch(function () { toast('Σφάλμα δικτύου.', false); b.disabled = false; });
		}

		// (191) Ίδια πύλη με το ecrm-view-detail.js: πρόχειρο δεν έχει έγγραφα
		// ούτε υπογραφή -- απλό confirm() αρκεί. Οτιδήποτε άλλο περνάει από
		// πληκτρολόγηση κωδικού, ίδιο confirmTyped() dialog με την καρτέλα.
		if (c.status === 'draft') {
			if (!confirm('Διαγραφή πρόχειρης σύμβασης; Δεν αναιρείται.')) return;
			doDelete();
			return;
		}

		var hasCode = !!c.code;
		confirmTyped({
			expect: hasCode ? String(c.code) : String(c.id),
			expectLabel: hasCode ? 'Πληκτρολόγησε τον κωδικό της αίτησης' : 'Πληκτρολόγησε τον αριθμό της αίτησης',
			title: 'Διαγραφή αίτησης ' + (c.code || ('#' + c.id)),
			lead: ['Η ενέργεια είναι ', { b: 'οριστική' }, ' και θα διαγράψει και τα σχετικά έγγραφα και τις ', { b: 'υπογραφές' }, '.'],
			confirm: 'Οριστική διαγραφή',
			onConfirm: doDelete,
		});
	});
}

/* Δύο γραμμές σε ένα κελί — η μορφή του UX kit (A2). Ο λόγος δεν είναι
 * αισθητικός: έντεκα στήλες δεν χωράνε σε καμία οθόνη χωρίς οριζόντιο σκρολ,
 * και ό,τι δεν χωράει δεν διαβάζεται. Πάροχος+πρόγραμμα, πελάτης+ταυτότητα,
 * παροχή+τιμολόγιο γίνονται τρία κελιά αντί για έξι στήλες. ΚΑΝΕΝΑ δεδομένο δεν
 * χάνεται· αλλάζει μόνο πού κάθεται. */
function person(main, sub, cls) {
	return '<span class="ecrm-person"><strong' + (cls ? ' class="' + cls + '"' : '') + '>' +
		esc(main || '—') + '</strong><span>' + esc(sub || '—') + '</span></span>';
}

/* Η δεύτερη γραμμή του πελάτη: ΑΦΜ και αριθμός συμβολαίου, όπως στο kit.
 *
 * Ο ΑΦΜ γράφεται ΜΑΣΚΑΡΙΣΜΕΝΟΣ, με τα τέσσερα τελευταία ψηφία. Δεν είναι θέμα
 * δικαιωμάτων — ο πλήρης ΑΦΜ ταξιδεύει ΗΔΗ στην απάντηση του /contracts
 * (SELECT cu.afm — ContractQueries::search) και φαίνεται ολόκληρος στο
 * άνοιγμα της γραμμής και στη λεπτομέρεια. Είναι θέμα ΠΟΣΟΤΗΤΑΣ: η
 * λεπτομέρεια δείχνει ΕΝΑΝ ΑΦΜ, η λίστα εικοσιπέντε — και μια φωτογραφία
 * οθόνης ή ένας περαστικός τους παίρνει όλους μαζί. Τα τέσσερα ψηφία αρκούν
 * για να αναγνωρίσει ο συνεργάτης τη γραμμή του. */
function subLine(r) {
	var bits = [];
	var afm  = r.afm ? String(r.afm) : '';
	if (afm)    bits.push('ΑΦΜ ' + (afm.length > 4 ? '••••' + afm.slice(-4) : afm));
	if (r.code) bits.push('#' + r.code);
	return bits.join(' · ');
}

/* Η μία λέξη που λέει τι χρειάζεται η γραμμή — και κυρίως ΠΟΙΟΣ έχει τη μπάλα.
 *
 * Ο χάρτης δεν είναι καινούριος: το ecrm-view-dashboard.js τον τρέχει ήδη για τη
 * λίστα «Τι χρειάζεται εσένα», με τις ίδιες λέξεις. Εδώ επεκτείνεται και στις
 * δώδεκα καταστάσεις αντί για τρεις.
 *
 * `quiet` σημαίνει «δεν περιμένει εσένα». Γράφεται πιο σβηστά ώστε το μάτι να
 * πέφτει στις γραμμές που περιμένουν — αυτό είναι όλο το νόημα της ουράς. Το
 * routed είναι quiet για τον ίδιο λόγο που λείπει από το dashboard, γραμμένο στο
 * DashboardAttentionTest: εκεί η μπάλα είναι στον πάροχο.
 *
 * Το κουμπί ΔΕΝ κάνει τίποτα δικό του. Αφήνεται να ανέβει στο κλικ της γραμμής,
 * που ήδη καλεί openDetail — μηδέν νέα λειτουργία, μηδέν δεύτερος δρόμος. */
function primaryAction(status) {
	switch (status) {
		case 'draft':              return { txt: 'Συνέχεια',      quiet: false };
		case 'presale':            return { txt: 'Δικαιολογητικά', quiet: false };
		case 'awaiting_signature': return { txt: 'Υπενθύμιση',    quiet: false };
		case 'pending_issue':
		case 'debt':               return { txt: 'Άνοιγμα',       quiet: false };
		case 'active':
		case 'cancelled':          return { txt: 'Άνοιγμα',       quiet: true };
		default:                   return { txt: 'Παρακολούθηση', quiet: true };
	}
}

function renderContracts(view, d) {
	var statuses = d.statuses || {}, counts = d.counts || {};
	var allRows = d.rows || [];

	// status tabs — show ALL statuses with counts + colour dots (like PSS)
	//
	// Χωρίς εξαιρέσεις πλέον: η παράκαμψη που έκρυβε το 'awaiting_signature'
	// υπήρχε επειδή δύο ονόματα έδειχναν στο ίδιο βήμα. Το νέο μοντέλο έχει
	// ένα (07/09/2026), οπότε κάθε κατάσταση παίρνει την καρτέλα της.
	var tabs = '<button type="button" class="ecrm-tab' + (contractsState.status === '' ? ' is-on' : '') + '" data-status=""><span class="ecrm-tabdot ecrm-tabdot--all"></span>ΟΛΕΣ <b>' + (counts.all || 0) + '</b></button>';
	// 05/10/2026: με δύο λίστες οι καταστάσεις έγιναν 18, οπότε καρτέλα
	// παίρνουν μόνο όσες έχουν αιτήσεις, συν αυτή που είναι επιλεγμένη.
	Object.keys(statuses).forEach(function (st) {
		if (!counts[st] && contractsState.status !== st) return;
		tabs += '<button type="button" class="ecrm-tab' + (contractsState.status === st ? ' is-on' : '') + '" data-status="' + st + '"><span class="ecrm-tabdot ecrm-tabdot--' + esc(st) + '"></span>' + esc(up(statuses[st])) + ' <b>' + (counts[st] || 0) + '</b></button>';
	});

	// client-side pagination
	var total = allRows.length;
	var pages = Math.max(1, Math.ceil(total / contractsState.pageSize));
	if (contractsState.page > pages) contractsState.page = pages;
	var startI = (contractsState.page - 1) * contractsState.pageSize;
	var rowsPage = allRows.slice(startI, startI + contractsState.pageSize);

	// Ownership only matters when more than one partner is in view.
	var showOwner = scope() === 'team';

	var body = rowsPage.map(function (r) {
		var name = r.company_name || ((r.first_name || '') + ' ' + (r.last_name || '')).trim() || '—';
		var stLabel = statuses[r.status] || r.status;
		var prov = r.provider_logo
			? '<img class="ecrm-cell-logo" src="' + esc(r.provider_logo) + '" alt="">'
			: '<span class="ecrm-cell-mark" style="--h:' + tint(r.provider_name || r.provider_slug || '') + '">' + esc(initials(r.provider_name || '·')) + '</span>';
		var cust = '<span class="ecrm-cell-mark ecrm-cell-mark--cust" style="--h:' + tint(name) + '">' + esc(initials(name)) + '</span>';
		var act = primaryAction(r.status);
		return '<tr class="ecrm-rowlink" data-id="' + r.id + '">' +
			'<td class="ecrm-checkcol"><input type="checkbox" class="ecrm-rowcheck" data-cid="' + r.id + '"></td>' +
			'<td class="ecrm-expandcol"><button type="button" class="ecrm-expand" data-expand="' + r.id + '" aria-label="Λεπτομέρειες">+</button></td>' +
			'<td><span class="ecrm-cell-cust">' + cust + person(name, subLine(r)) + '</span></td>' +
			'<td><span class="ecrm-cell-prov">' + prov + person(r.provider_name, r.program_name) + '</span></td>' +
			(showOwner ? '<td class="ecrm-col-sec"><span class="ecrm-cell-owner">' + esc(r.partner_name || '—') + '</span></td>' : '') +
			'<td class="ecrm-col-sec">' + person(r.supply_number, r.invoice_code, 'ecrm-mono') + '</td>' +
			// 3β-Γ, 04/09: πλήθος «1/2» δίπλα στο status badge, ΜΟΝΟ όταν η
			// αίτηση χρειάζεται δύο υπογραφές και ΔΕΝ έχουν ολοκληρωθεί --
			// όταν ολοκληρωθούν, το status το λέει ήδη (π.χ. «Υπογράφηκε»),
			// δεύτερη σήμανση θα ήταν διπλή πληροφορία. Κάθε άλλη σύμβαση
			// (η συντριπτική πλειοψηφία) δεν βλέπει τίποτα νέο εδώ.
			'<td><span class="ecrm-badge ecrm-badge--' + esc(r.status) + '">' + esc(stLabel) + '</span>' +
			(r.signatures && !r.signatures.complete
				? '<span class="ecrm-sigpill" title="Υπογραφές: ' + r.signatures.collected.length + ' από ' + r.signatures.required.length + '">' + r.signatures.collected.length + '/' + r.signatures.required.length + '</span>'
				: '') +
			'</td>' +
			'<td class="ecrm-cell-date ecrm-col-sec"><div>' + fmtDate(r.updated_at) + '</div><div class="ecrm-muted">' + timeAgo(r.updated_at) + '</div></td>' +
			'<td class="ecrm-rowactcol"><button type="button" class="ecrm-rowact' + (act.quiet ? ' is-quiet' : '') + '">' + esc(act.txt) + '</button></td>' +
			'</tr>' +
			'<tr class="ecrm-exprow" data-exprow="' + r.id + '" hidden><td class="ecrm-expaccent" data-status="' + esc(r.status) + '"></td><td colspan="' + (showOwner ? 8 : 7) + '"><div class="ecrm-exppanel" data-exppanel="' + r.id + '"><div class="ecrm-loading">Φόρτωση…</div></div></td></tr>';
	}).join('');

	var table = total
		? '<div class="ecrm-bulkbar" data-bulkbar hidden><span class="ecrm-bulkbar__n"><b data-bulk-n>0</b> επιλεγμένες</span>' +
			'<select class="ecrm-input ecrm-input--sm" data-bulk-status><option value="">— Αλλαγή κατάστασης —</option>' +
			Object.keys(statuses).map(function (s) { return '<option value="' + esc(s) + '">' + esc(statuses[s]) + '</option>'; }).join('') +
			'</select><button type="button" class="ecrm-btn ecrm-btn--sm ecrm-btn--primary" data-bulk-apply-status>Εφαρμογή</button>' +
			(scope() === 'team' ? '<select class="ecrm-input ecrm-input--sm" data-bulk-assign><option value="">— Ανάθεση σε… —</option></select><button type="button" class="ecrm-btn ecrm-btn--sm" data-bulk-apply-assign>Ανάθεση</button>' : '') +
			(can('ecrm_export_data') ? '<button type="button" class="ecrm-btn ecrm-btn--sm ecrm-btn--ghost" data-bulk-export><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16"/></svg> Export επιλογής</button>' : '') +
			(can('ecrm_delete_contract') ? '<button type="button" class="ecrm-btn ecrm-btn--sm ecrm-btn--danger" data-bulk-delete><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13"/></svg> Διαγραφή</button>' : '') +
			'<button type="button" class="ecrm-btn ecrm-btn--sm ecrm-btn--ghost" data-bulk-clear>Καθαρισμός</button></div>' +
			'<div class="ecrm-tablewrap"><table class="ecrm-table ecrm-table--rich"><thead><tr>' +
			'<th class="ecrm-checkcol"><input type="checkbox" data-checkall></th><th></th><th>Πελάτης</th><th>Πάροχος / πρόγραμμα</th>' +
			(showOwner ? '<th class="ecrm-col-sec">Συνεργάτης</th>' : '') +
			'<th class="ecrm-col-sec">Παροχή / τιμολόγιο</th><th>Κατάσταση</th><th class="ecrm-col-sec">Ενημέρωση</th><th></th>' +
			'</tr></thead><tbody>' + body + '</tbody></table></div>' +
			'<div class="ecrm-pager"><span>Σύνολο <b>' + total + '</b> συμβάσεις</span>' +
			'<div class="ecrm-pager__nav"><button type="button" class="ecrm-pager__b" data-page="prev"' + (contractsState.page <= 1 ? ' disabled' : '') + '>‹ Προηγούμενη</button>' +
			'<span class="ecrm-pager__pos">Σελίδα ' + contractsState.page + ' από ' + pages + '</span>' +
			'<button type="button" class="ecrm-pager__b" data-page="next"' + (contractsState.page >= pages ? ' disabled' : '') + '>Επόμενη ›</button></div></div>'
		// counts.all (όχι το filtered total) ξεχωρίζει το «καμία αίτηση ποτέ»
		// από το «καμία αίτηση με αυτό το φίλτρο/αναζήτηση» — μόνο το πρώτο
		// χρειάζεται CTA, το δεύτερο έχει ήδη λύση: αλλαγή φίλτρου.
		: '<div class="ecrm-empty">' + (
			(contractsState.q || contractsState.status)
				? 'Δεν υπάρχουν συμβάσεις' + (contractsState.q ? ' για «' + esc(contractsState.q) + '»' : '') + '.'
				: (counts.all
					? 'Δεν υπάρχουν συμβάσεις.'
					: 'Δεν έχεις καμία αίτηση ακόμα. Πάτα «Νέα αίτηση» για να ξεκινήσεις.')
		) + '</div>';

	view.innerHTML = '' +
		'<header class="ecrm-head ecrm-head--row"><div><h2 class="ecrm-title">Οι συμβάσεις μου</h2><p class="ecrm-sub">' + total + ' συμβάσεις · κάνε click σε γραμμή για λεπτομέρειες</p></div>' +
		'<div class="ecrm-head__actions">' +
		'<div class="ecrm-scope"><button type="button" class="ecrm-scope__b' + (scope()==="own"?" is-on":"") + '" data-scope="own">Δικά μου</button><button type="button" class="ecrm-scope__b' + (scope()==="team"?" is-on":"") + '" data-scope="team">Ομάδας</button></div>' +
		'<button type="button" class="ecrm-btn ecrm-btn--ghost ecrm-btn--sm" data-export><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16"/></svg> Export Excel</button></div></header>' +
		'<div class="ecrm-card">' +
		'<div class="ecrm-search-row"><div class="ecrm-search"><input type="search" class="ecrm-input" placeholder="Αναζήτηση πελάτη, ΑΦΜ, ΗΚΑΣΠ, αριθμού συμβολαίου…" value="' + esc(contractsState.q) + '" data-search></div>' +
		'<button type="button" class="ecrm-btn ecrm-btn--ghost ecrm-btn--sm" data-save-filter><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.9 6 6.6.9-4.8 4.6 1.2 6.5-5.9-3.1-5.9 3.1 1.2-6.5L2.5 9.9 9.1 9z"/></svg> Αποθήκευση φίλτρου</button>' +
		'<button type="button" class="ecrm-btn ecrm-btn--ghost ecrm-btn--sm" data-toggle-filters><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4"/></svg> Φίλτρα</button></div>' +
		'<div class="ecrm-savedfilters" data-savedfilters></div>' +
		'<div class="ecrm-tabs" data-tabs>' + tabs + '</div>' +
		table + '</div>';

	view.querySelectorAll('.ecrm-tab').forEach(function (t) {
		t.addEventListener('click', function () { contractsState.status = this.getAttribute('data-status'); contractsState.page = 1; loadContracts(); });
	});
	var search = view.querySelector('[data-search]');
	if (search) {
		var timer;
		search.addEventListener('input', function () { clearTimeout(timer); var val = this.value; timer = setTimeout(function () { contractsState.q = val; contractsState.page = 1; loadContracts(); }, 350); });
	}
	var ft = view.querySelector('[data-toggle-filters]');
	if (ft) ft.addEventListener('click', function () { var t = view.querySelector('[data-tabs]'); if (t) t.classList.toggle('is-hidden'); });

	// ---- saved filters ----
	var sfBox = view.querySelector('[data-savedfilters]');
	function renderSavedFilters(list) {
		if (!sfBox) return;
		if (!list.length) { sfBox.innerHTML = ''; return; }
		sfBox.innerHTML = '<span class="ecrm-savedfilters__lbl">Αποθηκευμένα:</span>' + list.map(function (f, i) {
			return '<span class="ecrm-savedchip" data-sf="' + i + '"><button type="button" class="ecrm-savedchip__go" data-sfgo="' + i + '">' + esc(f.name) + '</button>' +
				'<button type="button" class="ecrm-savedchip__x" data-sfdel="' + i + '" aria-label="Διαγραφή">×</button></span>';
		}).join('');
		sfBox.querySelectorAll('[data-sfgo]').forEach(function (b) {
			b.addEventListener('click', function () {
				var f = list[+this.getAttribute('data-sfgo')];
				contractsState.status = f.status || ''; contractsState.q = f.q || ''; setScope((f.scope === 'team' ? 'team' : 'own')); contractsState.page = 1;
				loadContracts();
			});
		});
		sfBox.querySelectorAll('[data-sfdel]').forEach(function (b) {
			b.addEventListener('click', function () {
				fetch(api('/filters/' + this.getAttribute('data-sfdel')), { method: 'DELETE', headers: H() })
					.then(function (r) { return r.json(); })
					.then(function (d) { if (d && d.ok) renderSavedFilters(d.filters || []); else toast((d && d.error) || 'Αποτυχία διαγραφής.', false); })
					.catch(function () { toast('Σφάλμα δικτύου.', false); });
			});
		});
	}
	// Best-effort: αν αποτύχει, απλά δεν εμφανίζονται αποθηκευμένα φίλτρα --
	// η υπόλοιπη οθόνη δουλεύει κανονικά χωρίς αυτά.
	fetch(api('/filters'), { headers: H() }).then(function (r) { return r.json(); })
		.then(function (d) { if (d && d.ok) renderSavedFilters(d.filters || []); }).catch(function () {});

	var saveBtn = view.querySelector('[data-save-filter]');
	if (saveBtn) saveBtn.addEventListener('click', function () {
		var dflt = (statuses[contractsState.status] || 'Όλες') + (contractsState.q ? ' · ' + contractsState.q : '') + (scope() === 'team' ? ' · Ομάδας' : '');
		var name = prompt('Όνομα φίλτρου:', dflt);
		if (!name) return;
		fetch(api('/filters'), { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, H()),
			body: JSON.stringify({ name: name, status: contractsState.status, q: contractsState.q, scope: scope() }) })
			.then(function (r) { return r.json(); })
			.then(function (d) { if (d && d.ok) { toast('Αποθηκεύτηκε φίλτρο.'); renderSavedFilters(d.filters || []); } else { toast((d && d.error) || 'Αποτυχία.', false); } })
			.catch(function () { toast('Σφάλμα δικτύου.', false); });
	});

	view.querySelectorAll('.ecrm-rowlink').forEach(function (tr) {
		tr.addEventListener('click', function () { openDetail(this.getAttribute('data-id')); });
	});
	view.querySelectorAll('[data-expand]').forEach(function (b) {
		b.addEventListener('click', function (e) {
			e.stopPropagation();
			var id = this.getAttribute('data-expand');
			var row = view.querySelector('[data-exprow="' + id + '"]');
			if (!row) return;
			row.hidden = !row.hidden;
			this.textContent = row.hidden ? '+' : '×';
			this.classList.toggle('is-open', !row.hidden);
			if (!row.hidden) loadExpand(id, view);
		});
	});
	view.querySelectorAll('[data-page]').forEach(function (b) {
		b.addEventListener('click', function () {
			if (this.disabled) return;
			contractsState.page += (this.getAttribute('data-page') === 'next' ? 1 : -1);
			loadContracts();
		});
	});

	var exportBtn = view.querySelector('[data-export]');
	if (exportBtn) exportBtn.addEventListener('click', function () {
		openExportModal({ status: contractsState.status, scope: scope(), q: contractsState.q });
	});
	view.querySelectorAll('[data-scope]').forEach(function (b) { b.addEventListener('click', function () { setScope(this.getAttribute('data-scope')); contractsState.page = 1; loadContracts(); }); });

	// ---- bulk selection & actions ----
	var bar = view.querySelector('[data-bulkbar]');
	function selectedIds() { return Array.prototype.slice.call(view.querySelectorAll('.ecrm-rowcheck:checked')).map(function (c) { return +c.getAttribute('data-cid'); }); }
	function refreshBar() {
		if (!bar) return;
		var ids = selectedIds();
		bar.hidden = ids.length === 0;
		var n = bar.querySelector('[data-bulk-n]'); if (n) n.textContent = ids.length;
		syncCheckAll();
	}

	// Η κεφαλίδα έχει ΤΡΕΙΣ καταστάσεις, όχι δύο: καμία, μερικές, όλες. Μέχρι
	// τώρα έδειχνε κενή και για «καμία» και για «μερικές» — δηλαδή έλεγε ψέματα
	// σε κάθε μερική επιλογή. Το indeterminate είναι ιδιότητα του DOM, δεν
	// γράφεται σε HTML και δεν στυλάρεται χωρίς να τεθεί από εδώ.
	function syncCheckAll() {
		var box = view.querySelector('[data-checkall]');
		if (!box) return;

		var all = view.querySelectorAll('.ecrm-rowcheck').length;
		var on = view.querySelectorAll('.ecrm-rowcheck:checked').length;

		box.checked = all > 0 && on === all;
		box.indeterminate = on > 0 && on < all;
	}

	view.querySelectorAll('.ecrm-rowcheck').forEach(function (cb) {
		cb.addEventListener('click', function (e) { e.stopPropagation(); refreshBar(); });
	});
	var checkAll = view.querySelector('[data-checkall]');
	if (checkAll) checkAll.addEventListener('click', function (e) {
		e.stopPropagation();
		// Από «μερικές», το κλικ επιλέγει ΟΛΕΣ. Ο browser δίνει checked=false σε
		// indeterminate κουτί, που θα σήμαινε «καθάρισε» — το ανάποδο από αυτό
		// που περιμένει ο χρήστης όταν βλέπει παύλα και πατάει.
		var on = this.indeterminate ? true : this.checked;
		this.indeterminate = false;
		this.checked = on;
		view.querySelectorAll('.ecrm-rowcheck').forEach(function (c) { c.checked = on; });
		refreshBar();
	});
	syncCheckAll();
	if (bar) {
		// populate assignee list (team scope)
		var assignSel = bar.querySelector('[data-bulk-assign]');
		if (assignSel) {
			// Best-effort: αν αποτύχει, το dropdown μένει άδειο -- η μαζική
			// ενέργεια απλά δεν προσφέρει ανάθεση σε συγκεκριμένο μέλος.
			fetch(api('/team'), { headers: H() }).then(function (r) { return r.json(); }).then(function (t) {
				(t && t.members || []).forEach(function (m) { var o = document.createElement('option'); o.value = m.id; o.textContent = m.name; assignSel.appendChild(o); });
			}).catch(function () {});
		}
		/* Το body.ids υπερισχύει της τρέχουσας επιλογής όταν δίνεται.
		   Χρειάστηκε μόλις μπήκε ο διάλογος με πληκτρολόγηση: ο χρήστης
		   πληκτρολογεί «12» επειδή διάβασε ότι είναι δώδεκα, και το πλήθος που
		   φεύγει στον server πρέπει να είναι ΑΥΤΟ, όχι ό,τι βρεθεί επιλεγμένο
		   δευτερόλεπτα αργότερα. Το πέπλο σήμερα δεν αφήνει την επιλογή να
		   αλλάξει· ο κανόνας δεν πρέπει να εξαρτάται από αυτό. */
		function runBulk(body, okMsg) {
			var ids = body.ids || selectedIds();
			if (!ids.length) { toast('Δεν επιλέχθηκαν συμβάσεις.', false); return; }
			body.ids = ids;
			fetch(api('/contracts/bulk'), { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, H()), body: JSON.stringify(body) })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (!d || !d.ok) { toast((d && d.error) || 'Αποτυχία.', false); return; }
					if (d.b64) {
						var bin = atob(d.b64), len = bin.length, arr = new Uint8Array(len);
						for (var i = 0; i < len; i++) arr[i] = bin.charCodeAt(i);
						var url = URL.createObjectURL(new Blob([arr], { type: d.mime }));
						var a = document.createElement('a'); a.href = url; a.download = d.filename || 'export.xlsx'; document.body.appendChild(a); a.click(); a.remove();
						setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
						toast('Εξήχθησαν ' + d.count + ' συμβάσεις.');
						return;
					}
					// Nothing moved and the pipeline explained why: lead with
					// that, instead of reporting a success that never happened.
					if (d.notice && !d.updated) { toast(d.notice, false); loadContracts(); return; }

					var msg = okMsg + (d.updated != null ? ' (' + d.updated + ')' : '');
					if (d.notice) msg += ' · ' + d.notice;
					if (d.skipped) msg += ' · παραλείφθηκαν ' + d.skipped + ' (ελλιπή δικαιολογητικά)';
					toast(msg);
					loadContracts();
				})
				.catch(function () { toast('Σφάλμα δικτύου.', false); });
		}
		var bs = bar.querySelector('[data-bulk-apply-status]');
		if (bs) bs.addEventListener('click', function () {
			var v = bar.querySelector('[data-bulk-status]').value;
			if (!v) { toast('Διάλεξε κατάσταση.', false); return; }
			runBulk({ action: 'status', value: v }, 'Ενημερώθηκαν');
		});
		var ba = bar.querySelector('[data-bulk-apply-assign]');
		if (ba) ba.addEventListener('click', function () {
			var v = assignSel ? assignSel.value : '';
			if (!v) { toast('Διάλεξε μέλος.', false); return; }
			runBulk({ action: 'assign', value: +v }, 'Ανατέθηκαν');
		});
		var be = bar.querySelector('[data-bulk-export]');
		if (be) be.addEventListener('click', function () { runBulk({ action: 'export' }, ''); });
		var bd = bar.querySelector('[data-bulk-delete]');
		if (bd) bd.addEventListener('click', function () {
			var ids = selectedIds();
			if (!ids.length) { toast('Δεν επιλέχθηκαν αιτήσεις.', false); return; }
			// Το πλήθος, όχι λέξη-κλειδί. Όποιος πληκτρολογεί «12» έχει διαβάσει
			// ότι είναι δώδεκα — και αυτό ακριβώς είναι που έπρεπε να κοιτάξει.
			confirmTyped({
				expect: String(ids.length),
				expectLabel: 'Πληκτρολόγησε το πλήθος για επιβεβαίωση',
				title: 'Διαγραφή ' + ids.length + (ids.length === 1 ? ' αίτησης' : ' αιτήσεων'),
				lead: ['Η ενέργεια είναι ', { b: 'οριστική' }, ' και θα διαγράψει και τα σχετικά έγγραφα και τις ', { b: 'υπογραφές' }, '.'],
				confirm: 'Διαγραφή ' + ids.length,
				onConfirm: function () { runBulk({ action: 'delete', ids: ids }, 'Διαγράφηκαν'); },
			});
		});
		var bc = bar.querySelector('[data-bulk-clear]');
		if (bc) bc.addEventListener('click', function () {
			view.querySelectorAll('.ecrm-rowcheck').forEach(function (c) { c.checked = false; });
			if (checkAll) checkAll.checked = false;
			refreshBar();
		});
	}
}
