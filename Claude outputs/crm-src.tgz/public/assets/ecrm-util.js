/* Energy CRM — the helpers every screen needs, in one copy.
 *
 * These three lived three times each: esc() in all of ecrm-app.js,
 * ecrm-form.js and ecrm-litsa.js, api() in all three, toast() byte-identical
 * in two. Copies drift, and one of them drifting is not a cosmetic problem —
 * FrontendEscapingTest had to assert that all three esc() bodies still covered
 * the same characters, which is a guard papering over a duplication rather
 * than a duplication being fixed.
 *
 * A native ES module, deliberately: no bundler, no node_modules, no build
 * artifact, and therefore no way to ship a stale one. The browser resolves the
 * import; WordPress never needs to know this file exists.
 *
 * One consequence worth knowing: an imported module gets no `?ver=` from
 * WordPress, so cache-busting here relies on the server's Last-Modified /
 * ETag revalidation rather than on a changed query string.
 */

/**
 * The only thing standing between a customer's name and the DOM.
 *
 * Covers & < > " — right for text and for double-quoted attributes. It is NOT
 * enough for an unquoted attribute, a javascript: URL, or anything inside a
 * <script> or a style=. No such site exists in this codebase, and
 * FrontendEscapingTest is what keeps it that way.
 */
export function esc(s) {
	return (s == null ? '' : String(s)).replace(/[&<>"]/g, function (c) {
		return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
	});
}

/** Absolute URL for a REST path, from the base wp_localize_script handed us. */
export function api(path) {
	return ECRM.rest.replace(/\/$/, '') + path;
}

/** The nonce header every write needs. */
export function H() {
	return { 'X-WP-Nonce': ECRM.nonce };
}

/**
 * Hiding a control the user may not use.
 *
 * Presentation only. Every one of these is enforced again on the server,
 * because anything that reaches the browser is a suggestion.
 */
export function can(capability) {
	return !!(ECRM.caps && ECRM.caps[capability]);
}

/**
 * Never serve our own API responses from the browser or proxy cache.
 *
 * An agent who changes a contract's status and clicks back to the list must
 * see the new status, not the one the browser kept. Only our REST base is
 * touched; everything else passes through untouched, which is why this can
 * safely shadow the global fetch in the modules that import it.
 *
 * It lived in the app shell and moved here when the views started splitting
 * out - each one needs it, and a second copy would be a second thing to keep
 * in step. ecrm-form.js and ecrm-litsa.js still call the global fetch; giving
 * them this one is a behaviour change and wants its own commit.
 */
var _origFetch = window.fetch.bind(window);

/*
 * Το nonce ανανεώνεται μόνο του, από την κεφαλίδα που ήδη στέλνει το WordPress.
 *
 * Το `wp-includes/rest-api.php` (rest_cookie_check_errors) στέλνει σε ΚΑΘΕ
 * επιτυχημένη REST απάντηση με cookie auth ένα φρέσκο `X-WP-Nonce`. Το
 * διαβάζαμε ποτέ: το `ECRM.nonce` έμενε αυτό που τυπώθηκε inline στο
 * wp_footer τη στιγμή που φόρτωσε η σελίδα. Μια καρτέλα ανοιχτή πάνω από
 * δώδεκα ώρες -- κανονικό για συνεργάτη σε tablet -- περνούσε στο δεύτερο
 * tick του nonce και μετά έληγε, και κάθε αποθήκευση γινόταν 403.
 *
 * Αυτό ΔΕΝ σώζει ένα ήδη ληγμένο nonce, και δεν υπάρχει τρόπος να το σώσει
 * κανείς: με ληγμένο nonce το WordPress κόβει το αίτημα με 403 πριν φτάσει
 * σε οποιοδήποτε permission_callback -- ένα δικό μας «GET /nonce» θα έπαιρνε
 * το ίδιο 403. Κρατά το παράθυρο ανοιχτό όσο ο χρήστης είναι περιοδικά
 * online· όταν έχει ήδη κλείσει, η απάντηση είναι να ξανασυνδεθεί.
 *
 * Γι' αυτό ΔΕΝ γράφτηκε το endpoint που προδιέγραφε το docs/OFFLINE-MODEL.md
 * §2Γ: θα ήταν δεύτερος τρόπος να πάρεις κάτι που ήδη έρχεται μόνο του.
 */
function refreshNonce(response) {
	try {
		var fresh = response && response.headers && response.headers.get('X-WP-Nonce');

		if (fresh) { ECRM.nonce = fresh; }
	} catch (e) {}

	return response;
}

export function fetch(url, opts) {
	opts = opts || {};

	var ours = false;

	try {
		var base = ECRM.rest.replace(/\/$/, '');

		if (typeof url === 'string' && url.indexOf(base) === 0) {
			ours = true;
			opts.cache = 'no-store';
			opts.headers = Object.assign({ 'Cache-Control': 'no-cache', 'Pragma': 'no-cache' }, opts.headers || {});
		}
	} catch (e) {}

	// Μόνο για τις δικές μας διαδρομές: η κεφαλίδα άλλου API δεν μας αφορά,
	// και το `ours` το έχει ήδη αποφασίσει ο έλεγχος από πάνω.
	return ours ? _origFetch(url, opts).then(refreshNonce) : _origFetch(url, opts);
}

/*
 * Το αναγνωριστικό μιας «πρόθεσης δημιουργίας».
 *
 * Ενα uuid v4 που ταξιδεύει με το POST /contracts και ξαναστέλνεται αυτούσιο
 * σε κάθε επανάληψη του ΙΔΙΟΥ αιτήματος: ο server δεσμεύει το κλειδί πριν
 * γράψει οτιδήποτε, οπότε διπλό tap ή retry σε ασταθές δίκτυο επιστρέφει την
 * αρχική σύμβαση αντί να φτιάξει δεύτερη. Δες RequestKey.php.
 *
 * Το `crypto.randomUUID` λείπει σε παλιότερα WebView (και σε κάθε μη-ασφαλές
 * context), οπότε υπάρχει fallback πάνω σε `getRandomValues` -- τα bits της
 * έκδοσης και της παραλλαγής γράφονται με το χέρι, γιατί ο server ελέγχει
 * ρητά ότι είναι v4 και όχι v1.
 */
export function requestId() {
	try {
		if (crypto && typeof crypto.randomUUID === 'function') { return crypto.randomUUID(); }

		var b = new Uint8Array(16);
		crypto.getRandomValues(b);
		b[6] = (b[6] & 0x0f) | 0x40;
		b[8] = (b[8] & 0x3f) | 0x80;

		var hex = Array.prototype.map.call(b, function (n) {
			return ('0' + n.toString(16)).slice(-2);
		}).join('');

		return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-' + hex.slice(12, 16) +
			'-' + hex.slice(16, 20) + '-' + hex.slice(20);
	} catch (e) {
		// Χωρίς πηγή τυχαιότητας δεν στέλνουμε κλειδί καθόλου: ένα προβλέψιμο
		// uuid θα ήταν χειρότερο από κανένα -- ο server αγνοεί το κενό και
		// συμπεριφέρεται όπως πριν το Επίπεδο Γ.
		return '';
	}
}

/**
 * The container a view renders into.
 *
 * Here rather than passed in from the router: a view module that looks up its
 * own container needs nothing from the shell but the call, which is what keeps
 * the extraction of the next one a move rather than a rewrite.
 */
export function viewEl(name) {
	return document.querySelector('#ecrm-app .ecrm-view[data-view="' + name + '"]');
}

/**
 * The application root, for the few things that are not inside a view.
 *
 * An overlay or a toast belongs to the app, not to whichever screen happened
 * to open it — appending to a view would take it down with the next render.
 */
export function root() {
	return document.getElementById('ecrm-app');
}

/**
 * Κάνει ένα πάτημα του πραγματικού κουμπιού "πίσω" του browser να κλείνει μια
 * υπο-όψη (καρτέλα σύμβασης, καρτέλα πελάτη) αντί να προσπερνά τη λίστα από
 * κάτω και να πηδά σε ό,τι όψη ήταν ενεργή πριν από αυτήν.
 *
 * Το go('contract-detail')/go('customer-detail') δεν αγγίζει καθόλου το
 * hash/ιστορικό -- τα ονόματα αυτά δεν είναι στο VIEWS του ecrm-app.js (δεν
 * έχουν δικό τους URL, δεν παίρνουν id σε refresh). Αυτό σημαίνει ότι το
 * πραγματικό ιστορικό του browser ΔΕΝ ξέρει καν ότι ανοίξαμε μια καρτέλα --
 * παραμένει στην εγγραφή της λίστας (π.χ. #contracts) από πριν. Πατώντας
 * back, ο browser προσπερνά λοιπόν τη λίστα (αφού δεν άλλαξε ποτέ hash) και
 * πάει κατευθείαν στην ΠΡΟΗΓΟΥΜΕΝΗ κορυφαία όψη -- π.χ. το Dashboard --
 * επιβεβαιωμένο live 06/09: Συμβάσεις -> άνοιγμα σύμβασης -> back του browser
 * -> Αρχική, όχι Συμβάσεις.
 *
 * Η διόρθωση: προσθέτουμε ΕΜΕΙΣ μια εγγραφή ιστορικού με το ΙΔΙΟ hash τη
 * στιγμή που ανοίγει η καρτέλα. Δεν αλλάζει τίποτα οπτικά (το hash μένει το
 * ίδιο, δεν πυροδοτείται popstate από το ίδιο το pushState). Ενα back του
 * browser μετά καταναλώνει ΑΥΤΗ την εγγραφή -- ίδιο hash, το popstate του
 * ecrm-app.js ξαναδιαβάζει το ίδιο hash και ξανακάνει go() στη λίστα, δηλαδή
 * ο χρήστης βλέπει ακριβώς τη λίστα που άφησε. Ενα δεύτερο back προχωράει
 * κανονικά παραπέρα, σαν να μην υπήρχε καν η καρτέλα.
 */
export function markSubViewOpen() {
	try { history.pushState({}, '', location.hash || location.pathname); } catch (e) {}
}

/**
 * The one-line message at the bottom of the screen.
 *
 * Creates its own node on first use, so no view has to remember to render a
 * container it does not otherwise care about.
 */
/*
 * Τα αρχεία που δεν πέρασαν, σε μία πρόταση.
 *
 * Ο server στέλνει λόγο ανά αρχείο. Χωρίς αυτό ο συνεργάτης έβλεπε
 * «Προστέθηκαν 0 έγγραφα» και δεν μάθαινε ποτέ γιατί.
 */
export function rejectedNote(list) {
	if (!list || !list.length) { return ''; }
	return list.map(function (r) {
		var name = (r && r.filename) || 'Το αρχείο';
		return name + ': ' + ((r && r.reason) || 'δεν έγινε δεκτό.');
	}).join(' — ');
}

/**
 * Τα chips πολλαπλής επιλογής παρόχων (279) -- ίδια σήμανση σε τρεις οθόνες
 * (νέο μέλος, καρτέλα μέλους, μαζικά -- docs/UI-PROVIDER-ACCESS.html,
 * εγκεκριμένη μακέτα 21/09), οπότε ζουν εδώ μία φορά αντί για τρεις σχεδόν
 * ίδιες συναρτήσεις που θα ξέφευγαν η μία από την άλλη με τον καιρό -- ίδιο
 * μάθημα με το esc()/api()/toast() πιο πάνω σε αυτό το αρχείο.
 *
 * readonly=true βγάζει το κουτάκι και το κλικ: η καρτέλα κάποιου που δεν
 * επεξεργάζεσαι εσύ δείχνει τι έχει, δεν αποφασίζεις εσύ γι' αυτόν.
 */
export function providerChipsHtml(providers, checkedIds, readonly) {
	if (!providers || !providers.length) { return '<div class="ecrm-empty">Δεν υπάρχουν πάροχοι.</div>'; }
	var checked = (checkedIds || []).map(function (id) { return parseInt(id, 10); });
	return '<div class="ecrm-pchips" data-pwrap>' + providers.map(function (p) {
		var pid = parseInt(p.id, 10);
		if (readonly) { return '<span class="ecrm-pchip ecrm-pchip--ro">' + esc(p.name) + '</span>'; }
		var on = checked.indexOf(pid) !== -1;
		return '<button type="button" class="ecrm-pchip' + (on ? ' is-on' : '') + '" data-pchip="' + pid + '">' +
			'<span class="ecrm-pchip__b"></span>' + esc(p.name) + '</button>';
	}).join('') + '</div>';
}

/** Τα id των chips τσεκαρισμένα αυτή τη στιγμή μέσα σε ένα container. */
export function checkedProviderIds(scope) {
	return Array.prototype.map.call(scope.querySelectorAll('.ecrm-pchip.is-on[data-pchip]'), function (b) {
		return parseInt(b.getAttribute('data-pchip'), 10);
	});
}

/**
 * Κλικ σε chip = toggle, χωρίς αίτημα -- αποθηκεύεται μαζί όταν πατηθεί το
 * κουμπί της φόρμας. «Ολοι»/«Κανενας» (data-pall/data-pnone μέσα στο ίδιο
 * scope) τσεκάρουν/ξετσεκάρουν όλα μαζί.
 */
export function wireProviderChips(scope) {
	scope.querySelectorAll('.ecrm-pchip[data-pchip]').forEach(function (b) {
		b.addEventListener('click', function () { b.classList.toggle('is-on'); });
	});
	var all = scope.querySelector('[data-pall]');
	var none = scope.querySelector('[data-pnone]');
	if (all) all.addEventListener('click', function (e) {
		e.preventDefault();
		scope.querySelectorAll('.ecrm-pchip[data-pchip]').forEach(function (b) { b.classList.add('is-on'); });
	});
	if (none) none.addEventListener('click', function (e) {
		e.preventDefault();
		scope.querySelectorAll('.ecrm-pchip[data-pchip]').forEach(function (b) { b.classList.remove('is-on'); });
	});
}

/**
 * POST JSON σε δική μας διαδρομή και φέρε πίσω ΚΑΙ τον κωδικό HTTP.
 *
 * Το σκέτο `r.json()` έχανε τον κωδικό, και ένα σφάλμα του ίδιου του
 * WordPress (rest_invalid_param, rest_forbidden) έχει `message`, όχι `error`
 * -- οπότε η οθόνη έγραφε σκέτο «Αποτυχία.» χωρίς κανέναν λόγο.
 */
export function postJson(url, body) {
	return fetch(url, {
		method: 'POST',
		headers: Object.assign({ 'Content-Type': 'application/json' }, H()),
		body: JSON.stringify(body),
	}).then(function (r) {
		return r.json().then(
			function (d) { return { status: r.status, d: d }; },
			function () { return { status: r.status, d: null }; }
		);
	});
}

/** Ο λόγος μιας αποτυχημένης απάντησης, σε μία πρόταση που διαβάζεται. */
export function failureText(res) {
	var d = res && res.d;
	var why = d && (d.error || d.message);
	return why ? String(why) : 'Αποτυχία (HTTP ' + ((res && res.status) || '?') + ').';
}

/**
 * Μήνυμα που ΜΕΝΕΙ στη θέση του -- όχι toast που σβήνει σε 4 δευτερόλεπτα.
 * Για αποτελέσματα φόρμας: ο χρήστης κοιτάζει το κουμπί που πάτησε, όχι το
 * κάτω μέρος της οθόνης. Ίδιες κλάσεις με το banner της εισαγωγής Excel.
 */
export function banner(el, text, ok) {
	if (!el) { return; }
	el.innerHTML = '<div class="ecrm-import-banner ' + (ok ? 'is-ok' : 'is-warn') + '" style="margin:10px 0 0">' +
		esc(text) + '</div>';
}

export function toast(msg, ok) {
	var t = document.getElementById('ecrm-toast');

	if (!t) {
		t = document.createElement('div');
		t.id = 'ecrm-toast';
		t.className = 'ecrm-toast';
		document.body.appendChild(t);
	}

	t.textContent = msg;
	t.className = 'ecrm-toast is-show ' + (ok === false ? 'is-err' : 'is-ok');
	setTimeout(function () { t.className = 'ecrm-toast'; }, 4000);
}
