<?php
/**
 * Front-end app shell: [energy_crm_app]
 * Renders the full CRM layout — navy sidebar nav, topbar, and the view
 * containers. Client-side routing + data fetching live in ecrm-app.js.
 *
 * Views: dashboard, new-contract (embeds the shared form partial),
 * contracts (list), network, team. The last two are scaffolded with empty
 * states, ready to wire in upcoming modules.
 *
 * @package EnergyCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ECRM_App {

	public static function init(): void {
		add_shortcode( 'energy_crm_app', [ __CLASS__, 'render' ] );
	}

	public static function render(): string {
		if ( ! is_user_logged_in() ) {
			return '<div class="ecrm-gate">Συνδέσου για να μπεις στο CRM.</div>';
		}

		// Form assets (also defines window.ECRMForm) + shell assets.
		ECRM_Shortcodes::enqueue_form_assets();
		wp_enqueue_style( 'ecrm-app', ECRM_URL . 'public/assets/ecrm-app.css', [ 'ecrm-form' ], ECRM_Shortcodes::asset_version( 'ecrm-app.css' ) );

		// Enqueued after the form module, and module tags execute in document
		// order, so window.ECRMForm exists before the shell asks for it. The
		// shell only reads it inside handlers anyway, with one exception: a
		// page opened straight at #new-contract calls it during startup.
		wp_enqueue_script_module( '@energy-crm/app' );
		wp_enqueue_script_module( '@energy-crm/litsa' );

		self::pwa_assets();

		global $wpdb;
		$user   = wp_get_current_user();
		$accent = class_exists( 'ECRM_Admin' ) ? (string) ECRM_Admin::get( 'accent_color' ) : '';
		$style  = $accent ? ' style="--amber:' . esc_attr( $accent ) . ';--amber-bright:' . esc_attr( $accent ) . ';"' : '';

		// Topbar org + avatar initials.
		$company = class_exists( 'ECRM_Admin' ) ? (string) ECRM_Admin::get( 'company_name' ) : '';
		// Ο Καταχωρητής συγχωνεύτηκε στον Πωλητή (Roles::matrix() v6, 25/08) --
		// δεν υπάρχει πια σαν ρόλος, οπότε δεν χρειάζεται πια κλάδος εδώ.
		$role_label = 'ΣΥΝΕΡΓΑΤΗΣ';
		if ( in_array( 'ecrm_seller', (array) $user->roles, true ) ) { $role_label = 'ΠΩΛΗΤΗΣ'; }
		elseif ( user_can( $user, 'manage_options' ) ) { $role_label = 'ADMIN'; }

		$parts = preg_split( '/\s+/', trim( (string) $user->display_name ) );
		$initials = '';
		foreach ( array_slice( $parts, 0, 2 ) as $w ) { $initials .= mb_substr( $w, 0, 1, 'UTF-8' ); }
		$initials = mb_strtoupper( $initials ?: mb_substr( $user->display_name, 0, 1, 'UTF-8' ), 'UTF-8' );

		// Το σήμα δίπλα στις «Εκκρεμότητες» (δικό μου scope).
		//
		// 07/09/2026: μετρούσε `status = 'pending'` -- κατάσταση που έγινε
		// **εμπόδιο** και ζει πλέον σε δικό της πίνακα. Ως τότε μετράει τα
		// presale, δηλαδή τις αιτήσεις που περιμένουν χαρτιά από τον ίδιο τον
		// συνεργάτη· είναι η πιο κοντινή «δουλειά δική σου» που υπάρχει σήμερα
		// στη στήλη `status`, και θα ξαναδείξει στα ανοιχτά εμπόδια όταν
		// υπάρχουν (commit 255).
		$pending_ct = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . ECRM_DB::table( 'contracts' ) . " WHERE partner_user_id = %d AND status = 'presale'",
			$user->ID
		) );
		$tasks_ct = class_exists( 'ECRM_Tasks' ) ? ECRM_Tasks::due_count( (int) $user->ID ) : 0;

		// Η εμφάνιση διαβάζεται ΕΔΩ, πριν τυπωθεί το πρώτο byte HTML, ώστε το
		// data-theme να βρίσκεται ήδη στο markup. Αν το έγραφε JS μετά το load,
		// η σελίδα θα άναβε λευκή και μετά θα σκούραινε — ορατό τρεμόπαιγμα σε
		// κάθε πλοήγηση. Το κλειδί του user meta το ξέρει ΜΟΝΟ το ThemePreference.
		$theme = \EnergyCRM\Infrastructure\ThemePreference::forUser( (int) $user->ID );

		// Leads with a callback due today or overdue, still open (own scope).
		$leads_due = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . ECRM_DB::table( 'leads' ) . "
			 WHERE partner_user_id = %d AND stage NOT IN ('won','lost')
			   AND callback_at IS NOT NULL AND callback_at <= %s",
			$user->ID, current_time( 'mysql' )
		) );

		/*
		 * Δύο ομάδες αντί για μία επίπεδη λίστα έντεκα-έως-δεκαέξι στοιχείων.
		 *
		 * Η «Καθημερινά» αντιγράφει επίτηδες το ίδιο σύνολο πέντε διαδρομών
		 * που έχει ήδη η κάτω μπάρα κινητού ($botnav πιο κάτω) — μια απόφαση
		 * που υπάρχει ήδη, όχι νέα εικασία δική μου: αν το «με το ένα χέρι
		 * στο κινητό» θεωρήθηκε αυτή η πεντάδα, το ίδιο σύνολο είναι λογικό
		 * να πρωτοστατεί και στο desktop. Ό,τι δεν είναι εκεί πάει στην
		 * «Περισσότερα» — δεν αλλάζει καμία διαδρομή, μόνο πού πέφτει το
		 * μάτι πρώτο. Οι πίνακες μένουν επίπεδοι (`$navDaily`/`$navMore`),
		 * το markup απλώς τους τυπώνει σε σειρά με μια ενδιάμεση ετικέτα.
		 */
		$navDaily = [
			[ 'view' => 'dashboard',    'label' => 'Αρχική',         'icon' => 'dashboard' ],
			[ 'view' => 'new-contract', 'label' => 'Νέα αίτηση',     'icon' => 'new' ],
			[ 'view' => 'contracts',    'label' => 'Συμβάσεις',      'icon' => 'contracts' ],
			[ 'view' => 'tasks', 'label' => 'Εργασίες', 'icon' => 'tasks', 'badge' => $tasks_ct ],
			[ 'view' => 'customers',    'label' => 'Πελάτες',        'icon' => 'customers' ],
		];
		$navMore = [
			[ 'view' => 'pending', 'label' => 'Εκκρεμότητες', 'icon' => 'pending', 'badge' => $pending_ct ],
			[ 'view' => 'documents', 'label' => 'Έγγραφα', 'icon' => 'documents' ],
			[ 'view' => 'renewals',     'label' => 'Λήξεις',         'icon' => 'renew' ],
			[ 'view' => 'network',      'label' => 'Το δίκτυό μου',  'icon' => 'network' ],
			[ 'view' => 'team',         'label' => 'Η ομάδα μου',    'icon' => 'team' ],
			[ 'view' => 'calc',         'label' => 'Προσφορά',       'icon' => 'calc' ],
			[ 'view' => 'kb',           'label' => 'Βάση Γνώσης',     'icon' => 'book' ],
			[ 'view' => 'training',     'label' => 'Εκπαίδευση',     'icon' => 'cap' ],
		];

		// The menu mirrors the capability matrix rather than guessing from the
		// role, so a change in EnergyCRM\Access\Roles is reflected here for free.
		if ( current_user_can( \EnergyCRM\Access\Capability::MANAGE_LEADS ) ) {
			array_splice( $navDaily, 2, 0, [
				// Ήταν 'Leads' — αγγλικό σε ελληνική οθόνη (κανόνας 4).
				[ 'view' => 'leads', 'label' => 'Υποψήφιοι', 'icon' => 'funnel', 'badge' => $leads_due ],
			] );
		}
		if ( current_user_can( \EnergyCRM\Access\Capability::VIEW_COMMISSIONS ) ) {
			$navMore[] = [ 'view' => 'commissions', 'label' => 'Προμήθειες', 'icon' => 'euro' ];
		}
		if ( current_user_can( \EnergyCRM\Access\Capability::MANAGE_TEAM ) ) {
			// Ήταν 'Ομάδα Live' — «live» έμεινε αμετάφραστο (κανόνας 4).
			$navMore[] = [ 'view' => 'teamlive', 'label' => 'Ομάδα τώρα', 'icon' => 'pulse' ];
			// Νέο 31/08: το «Της ομάδας σου» section του email digest (197),
			// τώρα και σαν δική του οθόνη -- ίδιο capability, ίδιος λόγος:
			// μόνο όποιος διαχειρίζεται ομάδα έχει «της ομάδας σου» να δει.
			// Ο ιδιοκτήτης το ζήτησε ρητά μέσα στο CRM, όχι μόνο σε email
			// («δεν υπάρχει λόγος να στέλνονται mail και μαλακίες»).
			$navMore[] = [ 'view' => 'escalations', 'label' => 'Καθυστερήσεις ομάδας', 'icon' => 'flag' ];
		}
		if ( current_user_can( \EnergyCRM\Access\Capability::VIEW_ANALYTICS ) ) {
			$navMore[] = [ 'view' => 'analytics', 'label' => 'Στατιστικά', 'icon' => 'analytics' ];
		}
		if ( current_user_can( \EnergyCRM\Access\Capability::IMPORT_DATA ) ) {
			$navMore[] = [ 'view' => 'import', 'label' => 'Εισαγωγή Excel', 'icon' => 'import' ];
		}

		ob_start();
		?>
		<?php // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $style is a whole attribute fragment, ' style="…"', whose only variable part went through esc_attr() where it was built. Escaping it here would escape the attribute syntax itself. ?>
		<div class="ecrm ecrm-app" id="ecrm-app" lang="el" data-view="dashboard" data-collapsed="0" data-theme="<?php echo esc_attr( $theme ); ?>"<?php echo $style; ?>>

			<div class="ecrm-backdrop" data-mobnav-close></div>

			<aside class="ecrm-sidebar">
				<div class="ecrm-brand">
					<span class="ecrm-brand__mark">E</span>
					<span class="ecrm-brand__txt">Energy <strong>CRM</strong></span>
					<button type="button" class="ecrm-collapse" data-collapse aria-label="Σύμπτυξη μενού"><?php echo self::icon( 'menu' ); // phpcs:ignore ?></button>
				</div>
				<nav class="ecrm-nav">
					<div class="ecrm-nav__label">Καθημερινά</div>
					<?php foreach ( $navDaily as $item ) :
						$go = $item['go'] ?? $item['view'];
						$badge = $item['badge'] ?? 0;
						?>
						<button type="button" class="ecrm-nav__item<?php echo $go === 'dashboard' ? ' is-active' : ''; ?>" data-go="<?php echo esc_attr( $go ); ?>" title="<?php echo esc_attr( $item['label'] ); ?>">
							<span class="ecrm-nav__icon"><?php echo self::icon( $item['icon'] ); // phpcs:ignore ?><?php if ( $badge > 0 ) : ?><span class="ecrm-nav__badge"><?php echo (int) $badge; ?></span><?php endif; ?></span>
							<span class="ecrm-nav__txt"><?php echo esc_html( $item['label'] ); ?></span>
						</button>
					<?php endforeach; ?>
					<?php
					/*
					 * Το «Περισσότερα» ξεκινά ΔΙΠΛΩΜΕΝΟ (πρόταση #2 του χαμηλής-
					 * εξοικείωσης πάσου, docs/UI-NAV-MORE-COLLAPSE.html, εγκρίθηκε
					 * 23/08) — ίδιο πνεύμα με την κάτω μπάρα κινητού: 5 βασικές
					 * διαδρομές μπροστά, τα υπόλοιπα πίσω από ένα κλικ. Ανοίγει
					 * μόνο του στο ΠΡΩΤΟ login κάποιου (καμία διαδρομή δεν χάνεται
					 * αναξήτητα), μετά θυμάται με localStorage — δες ecrm-app.js. */
					$more_badges = array_sum( array_map( fn( $it ) => $it['badge'] ?? 0, $navMore ) );
					?>
					<button type="button" class="ecrm-nav__more-toggle" data-nav-more-toggle aria-expanded="false">
						<span>Περισσότερα</span>
						<?php if ( $more_badges > 0 ) : ?><span class="ecrm-nav__badge ecrm-nav__badge--more"><?php echo (int) $more_badges; ?></span><?php endif; ?>
						<span class="ecrm-nav__more-chev" aria-hidden="true"><?php echo self::icon( 'chevron-down' ); // phpcs:ignore ?></span>
					</button>
					<div class="ecrm-nav__more-body" data-nav-more-body>
						<?php foreach ( $navMore as $item ) :
							$go = $item['go'] ?? $item['view'];
							$badge = $item['badge'] ?? 0;
							?>
							<button type="button" class="ecrm-nav__item" data-go="<?php echo esc_attr( $go ); ?>" title="<?php echo esc_attr( $item['label'] ); ?>">
								<span class="ecrm-nav__icon"><?php echo self::icon( $item['icon'] ); // phpcs:ignore ?><?php if ( $badge > 0 ) : ?><span class="ecrm-nav__badge"><?php echo (int) $badge; ?></span><?php endif; ?></span>
								<span class="ecrm-nav__txt"><?php echo esc_html( $item['label'] ); ?></span>
							</button>
						<?php endforeach; ?>
					</div>
				</nav>
				<div class="ecrm-sidebar__foot">
					<?php
					/*
					 * Ο διακόπτης εμφάνισης ΕΦΥΓΕ από εδώ (23/08, ιδιοκτήτης): «αφού
					 * πήγε πάνω, πρέπει να φύγει από το πλάι» — μετακόμισε ολόκληρος
					 * στο topbar (`.ecrm-themesw`, πάνω στο `<header>`), ορατός και σε
					 * desktop και σε mobile πλέον, βλ. CHANGELOG. Δεν μένει διπλό
					 * σημείο ελέγχου.
					 */
					?>
					<?php if ( current_user_can( 'manage_options' ) ) : ?>
					<a class="ecrm-nav__item" href="<?php echo esc_url( admin_url( 'admin.php?page=energy-crm' ) ); ?>" title="Ρυθμίσεις (WP Admin)">
						<span class="ecrm-nav__icon"><?php echo self::icon( 'gear' ); // phpcs:ignore ?></span>
						<span class="ecrm-nav__txt">Ρυθμίσεις</span>
					</a>
					<?php endif; ?>
					<a class="ecrm-nav__item" href="<?php echo esc_url( wp_logout_url() ); ?>" title="Έξοδος">
						<span class="ecrm-nav__icon"><?php echo self::icon( 'logout' ); // phpcs:ignore ?></span>
						<span class="ecrm-nav__txt">Έξοδος</span>
					</a>
				</div>
			</aside>

			<main class="ecrm-main">
				<?php
				/*
				 * Offline banner (docs/OFFLINE-MODEL.md §2Β, commit Β) — άδειο
				 * markup εδώ, η ecrm-app.js αποφασίζει πότε φαίνεται
				 * (`navigator.onLine` + events `online`/`offline`). Ζει ΜΕΣΑ στο
				 * `.ecrm-main`, πριν το topbar, ώστε να το σπρώχνει προς τα κάτω
				 * σε κανονική ροή αντί για `position: fixed` πάνω από αυτό --
				 * απλούστερο από το να συγχρονίζονται δύο sticky στοιχεία με
				 * μεταβλητό ύψος. Σκόπιμα ΔΕΝ είναι sticky: σε scroll χάνεται
				 * μαζί με το περιεχόμενο, όπως και το topbar παραμένει κολλημένο
				 * -- αποδεκτός συμβιβασμός για πρώτη γραφή, όχι ξεχασμένο bug.
				 */
				?>
				<div class="ecrm-offline" id="ecrm-offline" role="status" aria-live="polite" hidden>
					Εκτός σύνδεσης — ό,τι κάνεις τώρα μπαίνει σε ουρά και θα σταλεί μόλις γυρίσει η σύνδεση.
				</div>
				<?php
				/*
				 * Η ουρά εκτός σύνδεσης (260, docs/OFFLINE-MODEL.md §2Δ).
				 *
				 * Ξεχωριστή λωρίδα από το banner από πάνω, και όχι δεύτερο
				 * μήνυμα μέσα σε εκείνο: λένε διαφορετικά πράγματα και
				 * εμφανίζονται σε διαφορετικές στιγμές. Το πρώτο είναι «δεν
				 * έχεις δίκτυο τώρα». Αυτό είναι «κάτι δικό σου δεν έχει
				 * φύγει ακόμα» -- και μένει ορατό ΚΑΙ όταν η σύνδεση έχει
				 * επανέλθει, όσο υπάρχει έστω μία αίτηση σε αναμονή. Ακριβώς
				 * τότε χρειάζεται περισσότερο: ο συνεργάτης βλέπει «online»
				 * και θα υπέθετε ότι όλα στάλθηκαν.
				 */
				?>
				<?php
				/*
				 * Το πάνελ από κάτω (Επίπεδο Ε, μακέτα docs/UI-QUEUE-PANEL.html,
				 * εγκεκριμένη 09/09) -- ίδιο σχήμα με το .ecrm-bellpanel του
				 * καμπανακιού ειδοποιήσεων, όχι νέο component. Η λωρίδα γίνεται
				 * κλικαριστή (data-queue-toggle) εκτός από το ρητό κουμπί
				 * «Στείλε τώρα», που σταματά τη διάδοση για να μην ανοιγοκλείνει
				 * το πάνελ κάθε φορά που πατιέται.
				 */
				?>
				<div class="ecrm-queuewrap" id="ecrm-queue" hidden>
					<div class="ecrm-queuebar" role="status" aria-live="polite">
						<button type="button" class="ecrm-queuebar__toggle" data-queue-toggle aria-expanded="false">
							<span data-queue-text></span>
						</button>
						<button type="button" class="ecrm-queuebar__btn" data-queue-retry>Στείλε τώρα</button>
					</div>
					<div class="ecrm-queuepanel" data-queue-panel hidden>
						<div class="ecrm-queuepanel__head">
							<b>Ουρά εκτός σύνδεσης</b>
							<span data-queue-panel-count></span>
						</div>
						<div class="ecrm-queuepanel__list" data-queue-panel-list></div>
					</div>
				</div>
				<header class="ecrm-topbar">
					<button type="button" class="ecrm-burger" data-mobnav-toggle aria-label="Μενού"><?php echo self::icon( 'menu' ); // phpcs:ignore ?></button>
					<span class="ecrm-topbar__brand">Energy <strong>CRM</strong></span>
					<div class="ecrm-topbar__hello">Καλώς ήρθες, <strong><?php echo esc_html( $user->display_name ); ?></strong></div>
					<div class="ecrm-gsearch">
						<input type="search" data-gsearch placeholder="Αναζήτηση σύμβασης ή πελάτη — ΑΦΜ, όνομα, ΗΚΑΣΠ, κωδικός…" autocomplete="off">
						<div class="ecrm-gsearch__results" data-gsearch-results hidden></div>
					</div>
					<div class="ecrm-topbar__right">
						<?php
						/*
						 * Δεύτερο σημείο εναλλαγής εμφάνισης — ρητό αίτημα ιδιοκτήτη
						 * (23/08): «στο πάνω desktop, σαν κουμπί on/off», γιατί το
						 * υπάρχον στο footer του μενού μοιάζει με απλή γραμμή κειμένου
						 * και δεν ξεχωρίζει σαν διακόπτης. Το ίδιο attribute
						 * `data-theme-toggle` σε ΔΥΟ στοιχεία — το ecrm-app.js πλέον
						 * τα πιάνει και τα δύο με querySelectorAll, ό,τι πατηθεί
						 * ενημερώνει άμεσα και τα δύο (ίδιο data-theme στο .ecrm). */
						?>
						<button type="button" class="ecrm-themesw" data-theme-toggle role="switch" aria-checked="<?php echo 'dark' === $theme ? 'true' : 'false'; ?>" aria-label="Σκούρα εμφάνιση" title="Εναλλαγή ανοιχτής/σκούρας εμφάνισης">
							<span class="ecrm-themesw__ico ecrm-themesw__ico--sun"><?php echo self::icon( 'sun' ); // phpcs:ignore ?></span>
							<span class="ecrm-themesw__ico ecrm-themesw__ico--moon"><?php echo self::icon( 'moon' ); // phpcs:ignore ?></span>
							<span class="ecrm-themesw__knob"></span>
						</button>
						<span class="ecrm-live"><span class="ecrm-live__dot"></span> Live</span>
						<div class="ecrm-bellwrap">
							<button type="button" class="ecrm-bell" data-bell aria-label="Ειδοποιήσεις">
								<?php echo self::icon( 'bell' ); // phpcs:ignore ?>
								<span class="ecrm-bell__badge" data-bell-badge hidden>0</span>
							</button>
							<div class="ecrm-bellpanel" data-bellpanel hidden></div>
						</div>
						<?php if ( $company ) : ?>
						<div class="ecrm-org"><strong><?php echo esc_html( $company ); ?></strong><span><?php echo esc_html( $role_label ); ?></span></div>
						<?php endif; ?>
						<span class="ecrm-avatar" title="<?php echo esc_attr( $user->display_name ); ?>"><?php echo esc_html( $initials ); ?></span>
					</div>
				</header>

				<div class="ecrm-content">
					<!-- Dashboard -->
					<section class="ecrm-view is-active" data-view="dashboard">
						<div class="ecrm-loading">Φόρτωση…</div>
					</section>

					<!-- New contract (shared form partial) -->
					<section class="ecrm-view" data-view="new-contract">
						<?php echo ECRM_Shortcodes::form_inner_html(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</section>

					<!-- Contracts list -->
					<section class="ecrm-view" data-view="contracts">
						<div class="ecrm-loading">Φόρτωση…</div>
					</section>

					<!-- Contract detail -->
					<section class="ecrm-view" data-view="contract-detail">
						<div class="ecrm-loading">Φόρτωση…</div>
					</section>

					<!-- Network -->
					<section class="ecrm-view" data-view="network"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Team -->
					<section class="ecrm-view" data-view="team"><div class="ecrm-loading">Φόρτωση…</div></section>
					<?php // Καρτέλα ενός μέλους. Όπως το contract-detail, δεν είναι
					// στοιχείο του μενού: ανοίγει από τη λίστα της ομάδας και
					// γυρίζει πίσω σε αυτήν, οπότε δεν έχει δικό του κουμπί. ?>
					<section class="ecrm-view" data-view="partner"></section>

					<!-- Import provider Excel -->
					<section class="ecrm-view" data-view="import"></section>

					<!-- Εκκρεμότητες -->
					<section class="ecrm-view" data-view="pending"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Έγγραφα -->
					<section class="ecrm-view" data-view="documents"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Εργασίες -->
					<section class="ecrm-view" data-view="tasks"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Customers -->
					<section class="ecrm-view" data-view="customers"><div class="ecrm-loading">Φόρτωση…</div></section>
					<?php // Καρτέλα ενός πελάτη (247). Οπως το partner/contract-detail,
					// δεν είναι στοιχείο του μενού: ανοίγει από τη λίστα «Πελάτες»
					// και γυρίζει πίσω σε αυτήν. ?>
					<section class="ecrm-view" data-view="customer-detail"></section>

					<!-- Λήξεις -->
					<section class="ecrm-view" data-view="renewals"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Commissions -->
					<section class="ecrm-view" data-view="commissions"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Analytics (managers) -->
					<section class="ecrm-view" data-view="analytics"><div class="ecrm-loading">Φόρτωση…</div></section>
					<section class="ecrm-view" data-view="teamlive"><div class="ecrm-loading">Φόρτωση…</div></section>
					<section class="ecrm-view" data-view="escalations"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Προσφορά / Calculator -->
					<section class="ecrm-view" data-view="calc"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Βάση Γνώσης -->
					<section class="ecrm-view" data-view="kb"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Εκπαίδευση -->
					<section class="ecrm-view" data-view="training"><div class="ecrm-loading">Φόρτωση…</div></section>

					<!-- Leads / χωνί -->
					<section class="ecrm-view" data-view="leads"><div class="ecrm-loading">Φόρτωση…</div></section>
				</div>
			</main>

			<?php
			/*
			 * Κάτω μπάρα, μόνο σε κινητό (το CSS την κρύβει από τα 768 και πάνω).
			 *
			 * Δεν χρειάζεται ούτε γραμμή JS: τα κουμπιά φοράνε την ίδια κλάση
			 * .ecrm-nav__item και το ίδιο data-go με το πλαϊνό, οπότε ο
			 * delegated handler του ecrm-app.js τα πιάνει για την πλοήγηση και
			 * η go() τους βάζει is-active μαζί με τα αντίστοιχα του πλαϊνού.
			 *
			 * Πέντε θέσεις, όχι έντεκα: η μπάρα είναι για τις διαδρομές που
			 * τρέχει κανείς με το ένα χέρι. Τα υπόλοιπα μένουν στο συρτάρι,
			 * που δεν καταργείται.
			 */
			$botnav = [
				[ 'view' => 'dashboard',    'label' => 'Αρχική',   'icon' => 'dashboard' ],
				[ 'view' => 'contracts',    'label' => 'Συμβάσεις', 'icon' => 'contracts' ],
				[ 'view' => 'new-contract', 'label' => 'Νέα αίτηση', 'icon' => 'new' ],
				[ 'view' => 'tasks',        'label' => 'Εργασίες',  'icon' => 'tasks' ],
				[ 'view' => 'customers',    'label' => 'Πελάτες',   'icon' => 'customers' ],
			];
			?>
			<nav class="ecrm-botnav" aria-label="Κύρια πλοήγηση">
				<?php foreach ( $botnav as $item ) : ?>
					<button type="button" class="ecrm-nav__item ecrm-botnav__item<?php echo $item['view'] === 'dashboard' ? ' is-active' : ''; ?>" data-go="<?php echo esc_attr( $item['view'] ); ?>">
						<span class="ecrm-nav__icon"><?php echo self::icon( $item['icon'] ); // phpcs:ignore ?></span>
						<span class="ecrm-botnav__txt"><?php echo esc_html( $item['label'] ); ?></span>
					</button>
				<?php endforeach; ?>
			</nav>

			<!-- Λίτσα assistant -->
			<div class="ecrm-litsa" id="ecrm-litsa" data-open="0">
				<button type="button" class="ecrm-litsa__fab" data-litsa-toggle aria-label="Άνοιγμα βοηθού AlfrAId">
					<span class="ecrm-litsa__fab-ico"><?php echo self::alfraid_icon(); // phpcs:ignore ?></span>
				</button>
				<div class="ecrm-litsa__panel" role="dialog" aria-label="Βοηθός AlfrAId">
					<div class="ecrm-litsa__head">
						<div class="ecrm-litsa__id"><span class="ecrm-litsa__avatar"><?php echo self::alfraid_icon(); // phpcs:ignore ?></span><div><strong>AlfrAId</strong><span class="ecrm-litsa__sub">βοηθός CRM</span></div></div>
						<div class="ecrm-litsa__headbtns">
							<button type="button" class="ecrm-litsa__clear" data-litsa-clear aria-label="Διαγραφή συνομιλίας" title="Διαγραφή συνομιλίας"><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13"/></svg></button>
							<button type="button" class="ecrm-litsa__x" data-litsa-toggle aria-label="Κλείσιμο">✕</button>
						</div>
					</div>
					<div class="ecrm-litsa__body" data-litsa-body></div>
					<div class="ecrm-litsa__foot">
						<input type="text" class="ecrm-litsa__input" data-litsa-input placeholder="Ρώτησέ με κάτι…" autocomplete="off">
						<button type="button" class="ecrm-litsa__send" data-litsa-send aria-label="Αποστολή"><svg class="ecrm-i" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12l16-8-6 16-2.5-6z"/></svg></button>
					</div>
				</div>
			</div>

			<div class="ecrm-toast" id="ecrm-toast" aria-live="assertive"></div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Το manifest link στο <head> + η εγγραφή του service worker.
	 *
	 * Ζει ΕΔΩ και όχι μέσα στο κοινό `ECRM_Shortcodes::print_config()` -- το
	 * «εγκατέστησέ το σαν app» έχει νόημα μόνο για το `[energy_crm_app]`, όχι
	 * για το αυτόνομο `[energy_crm_new_contract]` (ο πελάτης/πωλητής που
	 * ανοίγει μόνο τη φόρμα δεν χρειάζεται εικονίδιο CRM στην αρχική οθόνη
	 * του). Το πλήρες σκεπτικό είναι στο `docs/OFFLINE-MODEL.md` §2Α.
	 *
	 * ## AUDIT 08/09: γιατί ΔΕΝ περνά από `wp_head`
	 *
	 * Πρώτη γραφή έβαζε το `<link rel="manifest">` σε `add_action('wp_head', ...)`
	 * μέσα από ΕΔΩ -- λάθος, και το έπιασε ζωντανή δοκιμή πριν το commit, όχι
	 * κάποιο test. Το `wp_head` εκτελείται ΠΡΙΝ από το `<body>` -- δηλαδή πριν
	 * καν τρέξει το ίδιο το shortcode που καλεί αυτή τη μέθοδο. Ένα
	 * `add_action('wp_head', ...)` που καταχωρείται ΜΕΣΑ σε shortcode callback
	 * φτάνει πάντα αργά: το hook έχει ήδη πυροδοτηθεί, τίποτα δεν τυπώνεται,
	 * και το manifest link απουσιάζει ολοκληρωτικά -- επιβεβαιώθηκε με πλήρη
	 * αναζήτηση στο `document.documentElement.outerHTML`, όχι μόνο σε ένα
	 * κομμάτι του `<head>`. Το `wp_footer` δουλεύει (γι' αυτό η εγγραφή SW,
	 * ίδιο μοτίβο με το `print_config()`, ΠΕΡΝΟΥΣΕ κανονικά): εκτελείται ΜΕΤΑ
	 * το `<body>`, άρα μετά και το ίδιο το shortcode.
	 *
	 * Διόρθωση: το link element φτιάχνεται και μπαίνει στο `<head>` με JS,
	 * μέσα στο ίδιο inline script του `wp_footer` που κάνει την εγγραφή SW.
	 * Δουλεύει ανεξάρτητα από τη σειρά hooks -- `document.head` υπάρχει ήδη
	 * πολύ πριν φτάσει το script στο footer -- και είναι το ίδιο μοτίβο που
	 * χρησιμοποιούν browsers/frameworks για δυναμικά manifest links.
	 */
	private static function pwa_assets(): void {
		static $done = false;

		if ( $done || ! class_exists( 'ECRM_Pwa' ) ) {
			return;
		}

		$done = true;

		add_action( 'wp_footer', static function (): void {
			$manifest_url = wp_json_encode( ECRM_Pwa::manifest_url() );
			$sw_url       = wp_json_encode( ECRM_Pwa::sw_url() );

			wp_print_inline_script_tag(
				'(function () {'
					. ' var l = document.createElement("link"); l.rel = "manifest"; l.href = ' . $manifest_url . ';'
					. ' document.head.appendChild(l);'
					. ' if ("serviceWorker" in navigator) {'
					. ' window.addEventListener("load", function () {'
					. ' navigator.serviceWorker.register(' . $sw_url . ').catch(function () {});'
					. ' }); }'
					. ' })();',
				[ 'id' => 'ecrm-pwa-register' ]
			);
		} );
	}

	/**
	 * Το σήμα του AlfrAId: ημίψηλο καπέλο μπάτλερ με σπινθήρα. Χωριστό από το
	 * icon() γιατί είναι γεμάτο σχήμα, όχι γραμμή, και τα χρώματά του ζουν στο
	 * CSS (.ecrm-alfraid*), όχι εδώ.
	 */
	public static function alfraid_icon(): string {
		return '<svg class="ecrm-alfraid" viewBox="1.5 0.8 21.5 18.8" aria-hidden="true"><rect x="2.5" y="16.2" width="19" height="2.6" rx="1.3"/><path d="M6.6 16.4V6.2a1.2 1.2 0 011.2-1.2h8.4a1.2 1.2 0 011.2 1.2v10.2z"/><rect class="ecrm-alfraid__band" x="6.6" y="12.4" width="10.8" height="2.2"/><path class="ecrm-alfraid__spark" d="M18.6 1.6L19.61 4.19L22.2 5.2L19.61 6.21L18.6 8.8L17.59 6.21L15 5.2L17.59 4.19z"/></svg>';
	}

	/** Inline SVG icon set (stroke, currentColor). */
	public static function icon( string $name ): string {
		$p = [
			'dashboard' => '<path d="M3 13a9 9 0 0 1 18 0"/><path d="M12 13l4-3"/><circle cx="12" cy="13" r="1.4"/>',
			'new'       => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M12 12v5"/><path d="M9.5 14.5h5"/>',
			'contracts' => '<path d="M8 4H6a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2"/><rect x="8" y="2.5" width="8" height="4" rx="1.2"/><path d="M8.5 11h7"/><path d="M8.5 15h5"/>',
			'documents' => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h6"/>',
			'network'   => '<circle cx="6" cy="12" r="2.4"/><circle cx="18" cy="6" r="2.4"/><circle cx="18" cy="18" r="2.4"/><path d="M8.2 10.8 15.8 7.2"/><path d="M8.2 13.2 15.8 16.8"/>',
			'pending'   => '<path d="M12 8v5"/><circle cx="12" cy="16.5" r=".4"/><path d="M10.3 3.8 2.6 17.5A2 2 0 0 0 4.3 20.5h15.4a2 2 0 0 0 1.7-3L13.7 3.8a2 2 0 0 0-3.4 0z"/>',
			'renew'     => '<path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/>',
			'customers' => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8" cy="11" r="2"/><path d="M5 16.5a3.5 3.5 0 0 1 6 0"/><path d="M14 9h4"/><path d="M14 13h4"/>',
			'team'      => '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 6.2a3 3 0 0 1 0 5.6"/><path d="M18.5 20a6 6 0 0 0-3-5.1"/>',
			'import'    => '<path d="M12 14V3"/><path d="M8 9l4 4 4-4"/><path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
			'euro'      => '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.6a4 4 0 1 0 0 6.8"/><path d="M7.5 10.8h6"/><path d="M7.5 13.2h6"/>',
			'analytics' => '<path d="M4 20V4"/><path d="M4 20h16"/><rect x="7" y="12" width="3" height="5"/><rect x="12" y="8" width="3" height="9"/><rect x="17" y="5" width="3" height="12"/>',
			'pulse'     => '<path d="M3 12h4l2 6 4-14 2 8h6"/>',
			'flag'      => '<path d="M5 21V4"/><path d="M5 4h13l-3 4.5L18 13H5"/>',
			'tasks'     => '<path d="M9 11l2 2 4-4"/><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 4V2.5"/><path d="M16 4V2.5"/>',
			'calc'      => '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8"/><path d="M8 12h.01"/><path d="M12 12h.01"/><path d="M16 12h.01"/><path d="M8 16h.01"/><path d="M12 16h.01"/><path d="M16 16h.01"/>',
			'book'      => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
			'cap'       => '<path d="M12 4 2 9l10 5 10-5-10-5z"/><path d="M6 11.5V16c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.5"/>',
			'funnel'    => '<path d="M3 4h18l-7 8v6l-4 2v-8z"/>',
			'logout'    => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
			'gear'      => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
			'menu'      => '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
			'bell'      => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
			'chat'      => '<path d="M21 11.5a8.5 8.5 0 0 1-12.3 7.6L3 21l1.9-5.7A8.5 8.5 0 1 1 21 11.5z"/>',
			'moon'      => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
			'sun'       => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.9 4.9l1.4 1.4"/><path d="M17.7 17.7l1.4 1.4"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M4.9 19.1l1.4-1.4"/><path d="M17.7 6.3l1.4-1.4"/>',
			'chevron-down' => '<path d="M6 9l6 6 6-6"/>',
		];
		$d = $p[ $name ] ?? '';
		return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d . '</svg>';
	}

}
