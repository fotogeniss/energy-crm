<?php

/**
 * The one way a contract changes status.
 *
 * Every status change in the system goes through here, so the lifecycle behaves
 * identically wherever it is triggered: the status is written, the event log
 * gains an entry, the agent gets an in-app notification and the customer gets a
 * message. Five callers, one behaviour.
 *
 * Lifted out of ECRM_REST in roadmap step 10. It was never REST's business —
 * cron and the customer-facing tracking page both call it, and neither is a
 * REST request.
 *
 * ## Authorisation is not here
 *
 * `moveTo()` takes a bare contract id and trusts it. That is deliberate and it
 * is why its two database methods live in ContractTransitions, which takes no
 * UserScope: the callers resolve the contract through a scoped read first, and
 * the sweep runs from cron on behalf of nobody at all. The policy admitting
 * them is in ARCHITECTURE.md under «Αναγνώσεις χωρίς actor». What is enforced
 * here is the *pipeline* —
 * which move is legal — not who may make it.
 *
 * Three questions are asked before the write, and none of them can be skipped
 * by choosing a different door: is the move legal for this status
 * (ContractStatus), may this particular contract be cancelled (CancellationGate),
 * and is its paperwork complete enough for where it is going (StatusEntryGate).
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Domain\Contract;

use ECRM_Messaging;
use ECRM_Notifications;
use EnergyCRM\Persistence\ContractTransitions;
use EnergyCRM\Persistence\EventRepository;
use EnergyCRM\Persistence\PayoutRepository;

final class ContractLifecycle
{
    /**
     * Fired after a status actually changed — not when the move was refused,
     * and not when the contract was already in the target status.
     *
     * Arguments: contract id, new status, previous status ('' when unknown).
     * ContractNotices and RejectionFollowUp listen for it; that is how the
     * things that react to a move happen without the lifecycle needing to know
     * that notifications or tasks exist.
     */
    public const STATUS_CHANGED = 'ecrm_contract_status_changed';

    /**
     * Fired once, right after `logCreation()` writes the "created" event --
     * never on a replayed idempotent request (Επίπεδο ΣΤ, docs/OFFLINE-MODEL.md
     * §2ΣΤ). `DuplicateFollowUp` listens for it, the same decoupling reason as
     * `STATUS_CHANGED`: creation itself does not need to know that an
     * automatic duplicate check exists.
     *
     * Arguments: contract id, status the contract was created with.
     */
    public const CREATED = 'ecrm_contract_created';

    public function __construct(
        private readonly ContractTransitions $transitions,
        private readonly EventRepository $events,
        private readonly CancellationGate $cancellation,
        private readonly PayoutRepository $payouts,
        private readonly StatusEntryGate $entry,
    ) {
    }

    /**
     * Move a contract to a new status.
     *
     * @param array{
     *     user_id?: int,
     *     from?: string|null,
     *     message?: string|null,
     *     extra?: array<string, mixed>,
     *     inapp?: bool,
     *     sms?: bool,
     *     force?: bool
     * } $options
     *
     * @return bool True when applied, or already there. False when the status
     *              does not exist or the pipeline forbids the move.
     */
    public function moveTo(int $contractId, string $to, array $options = []): bool
    {
        $target = ContractStatus::tryFromSlug($to);

        if ($target === null) {
            return false;
        }

        // A caller that knows the previous status says so; the signing routes
        // pass null because they genuinely do not.
        $from = array_key_exists('from', $options)
            ? (string) $options['from']
            : $this->transitions->statusOf($contractId);

        // AUDIT 30/08: ξεχωριστό από το $from παραπάνω -- εκείνο γίνεται ήδη
        // '' όταν ο καλών περάσει null, και χρησιμοποιείται σωστά αλλού (το
        // «ήδη εκεί» κλαδί, το ιστορικό). Εδώ χρειάζεται να ξέρουμε αν ο
        // καλών ΡΗΤΑ δήλωσε άγνωστη προέλευση, ώστε η applyTransition() να
        // ΜΗΝ δεσμεύσει τη γραφή πάνω σε '' -- καμία σύμβαση δεν έχει ποτέ
        // status='', άρα μια τέτοια δέσμευση θα απέτυχε πάντα.
        $originUnknown = array_key_exists('from', $options) && $options['from'] === null;

        // Already there. True, because the caller asked for a state and the
        // contract is in it — but nothing is logged, since nothing happened.
        if ($from === $to && empty($options['force'])) {
            return true;
        }

        $current = ContractStatus::tryFromSlug($from);

        // Refuse what the pipeline does not allow: reviving a cancelled
        // contract, or rewinding a signed one past its own signature.
        //
        // AUDIT 07/09: `allowedNext()` δεν έχει πλέον self-loops -- κανένα
        // status δεν αναφέρει τον εαυτό του ως νόμιμο επόμενο σταθμό, γιατί
        // η ιδεμποτεντία «ήδη εκεί» ζει αποκλειστικά στο κλαδί λίγες γραμμές
        // πιο πάνω. Χωρίς το `$from !== $to` εδώ, ένα `force => true` πάνω
        // στην ΙΔΙΑ κατάσταση θα έφτανε σε αυτόν τον έλεγχο (το κλαδί από
        // πάνω το προσπερνά ρητά όταν force είναι αληθές) και θα αρνιόταν
        // πάντα, αφού canMoveTo(εαυτού) είναι πάντα false -- σκοτώνοντας τη
        // δυνατότητα που το ίδιο το `ContractTransitions::applyTransition()`
        // σχεδιάζει ρητά να υποστηρίξει («force => true χωρίς πραγματική
        // αλλαγή», δες το δικό του docblock). Δεν είναι μετάβαση σε άλλο
        // κόμβο του γράφου -- είναι ανανέωση επιτόπου, και ο γράφος δεν έχει
        // λόγο να κρίνει κάτι που δεν αφορά καμία ακμή του.
        if ($current !== null && $from !== $to && ! $current->canMoveTo($target)) {
            return false;
        }

        // Κάθε είδος αίτησης έχει τη δική του λίστα (05/10/2026): μια αίτηση
        // ρεύματος δεν πάει σε «Παράδοση SIM», μια κινητής δεν πάει σε
        // «Επιβεβαίωση ΘΑΛΗΣ».
        $track = $this->transitions->trackOf($contractId);

        if ($track !== null && ! $target->appliesTo($track)) {
            return false;
        }

        // Χαρτιά και υπογραφή, για τις καταστάσεις που τα απαιτούν. Ο έλεγχος
        // ζούσε ως τις 07/09 μόνο σε δύο controllers -- ο τρίτος δρόμος που
        // γράφει status (η αποθήκευση της φόρμας) και η εισαγωγή Excel τον
        // προσπερνούσαν, με τον Πωλητή να έχει CHANGE_STATUS και το `active`
        // να είναι πληρωτέο. Εδώ είναι το σημείο που δεν παρακάμπτεται:
        // ίδιος λόγος και ίδια θέση με τον CancellationGate από πάνω.
        //
        // ΔΕΝ ελέγχεται στη δημιουργία μέσω αυτής της διαδρομής -- ο
        // ContractSaveController φυλάει μόνος του την πρώτη αποθήκευση, όπου
        // δεν υπάρχει ακόμη `$contractId` να ρωτηθεί.
        //
        // AUDIT 22/09: περνάμε το `extra` που πάει να γραφτεί ΣΕ ΑΥΤΗ ΤΗΝ
        // ΚΛΗΣΗ -- η πύλη το χρειάζεται για να δει π.χ. το `signed_at` που η
        // ίδια η υπογραφή κουβαλάει, πριν αυτό υπάρχει στη βάση (βλ. docblock
        // του StatusEntryGate).
        if ($this->entry->refusalOnEntry($target, $contractId, (array) ($options['extra'] ?? [])) !== null) {
            return false;
        }

        $applied = $this->transitions->applyTransition(
            $contractId,
            $to,
            $originUnknown ? null : $from,
            (array) ($options['extra'] ?? [])
        );

        if (! $applied) {
            // AUDIT 30/08: guarded write στο ContractTransitions -- κάποιος
            // άλλος moveTo() έφτασε πρώτος και μετακίνησε τη σύμβαση μακριά από
            // το $from ανάμεσα στο statusOf() εδώ πάνω και τη γραφή. Αν έφτασε
            // ΑΚΡΙΒΩΣ στο ίδιο $to που ζητούσαμε κι εμείς, το αποτέλεσμα που
            // ζητήθηκε ήδη ισχύει -- idempotent true, ΧΩΡΙΣ δεύτερο log/notify, γιατί
            // αυτός που κέρδισε το πέρασε ήδη από το ΔΙΚΟ ΤΟΥ moveTo() και
            // τα έκανε αυτά μία φορά. Αν έφτασε αλλού, η μετάβαση χάθηκε
            // πραγματικά -- false, όχι σιωπηλή αντικατάσταση της κατάστασης.
            return $this->transitions->statusOf($contractId) === $to;
        }

        // Μια σύμβαση που μόλις ακυρώθηκε δεν πρέπει να συνεχίσει να μετράει
        // στο σύνολο μιας παρτίδας που δεν έχει πληρωθεί ακόμα -- ίδιο σημείο
        // με το CancellationGate παραπάνω, εύρημα ελέγχου #2 (26/08),
        // επιβεβαιωμένο ρητά από τον ιδιοκτήτη. Παρτίδα ήδη πληρωμένη δεν
        // αγγίζεται: αυτή τη διαδρομή την έχει ήδη κόψει η πύλη λίγες γραμμές
        // πιο πάνω, πριν φτάσουμε ποτέ σε αυτό το σημείο.
        // Από 05/10/2026 ακυρώνεται και αίτηση που δούλεψε (η παλιά Διακοπή).
        // Αυτή κρατάει την προμήθειά της, οπότε δεν βγαίνει από την παρτίδα.
        if ($target->isCancellation() && ! $this->cancellation->keepsCommission($contractId)) {
            $this->payouts->releaseFromPendingBatch($contractId);
        }

        $this->events->record($contractId, (int) ($options['user_id'] ?? 0), 'status_change', [
            'from_status' => $from,
            'to_status'   => $to,
            'message'     => $options['message'] ?? null,
        ]);

        $this->announce($contractId, $to, $from, $options);

        return true;
    }

    /** The "contract created" entry, written once when a contract first exists. */
    public function logCreation(int $contractId, int $userId, string $status): void
    {
        $this->events->record($contractId, $userId, 'created', [
            'to_status' => $status,
            'message'   => 'Αποθήκευση αίτησης',
        ]);

        /*
         * Same convention as announce(): the constant is declared once at the
         * top of this class, and spelling the string out here again would put
         * it in two places.
         */
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
        do_action(self::CREATED, $contractId, $status);
    }

    /**
     * Everything that happens because the status changed.
     *
     * Both notifications keep their opt-out flags: a bulk action does not want
     * to send fifty texts, and the signing route sends its own richer message
     * instead of the generic one.
     *
     * @param array<string, mixed> $options
     */
    private function announce(int $contractId, string $to, string $from, array $options): void
    {
        if (($options['inapp'] ?? true) && class_exists(ECRM_Notifications::class)) {
            ECRM_Notifications::notify_status_change($contractId, $to);
        }

        if (($options['sms'] ?? true) && class_exists(ECRM_Messaging::class)) {
            ECRM_Messaging::on_status_change($contractId, $to);
        }

        /*
         * The hook name is prefixed: the constant is
         * 'ecrm_contract_status_changed', declared at the top of this class.
         * The sniff cannot read inside a constant, and spelling the literal out
         * here would put the same string in two places — which is exactly the
         * mistake the constant exists to prevent.
         */
        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound
        do_action(self::STATUS_CHANGED, $contractId, $to, $from);
    }
}
