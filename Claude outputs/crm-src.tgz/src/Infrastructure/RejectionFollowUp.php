<?php

/**
 * Μια αίτηση που απορρίφθηκε ή ακυρώθηκε αφήνει πίσω της μια εργασία.
 *
 * ## Από 05/10/2026
 *
 * Η «Ακυρώθηκε από εμάς» δεν υπάρχει πια. Εργασία φτιάχνεται σε τρεις
 * καταστάσεις: Απόρριψη ΘΑΛΗΣ, MP reject (ο πάροχος απέρριψε) και Ακυρώθηκε.
 * Το κείμενο παρακάτω περιγράφει πώς φτάσαμε εδώ.
 *
 * ## Το κομμάτι του pipeline που καλύπτει
 *
 * Από το διάγραμμα του ιδιοκτήτη (31/08): «...Αν απορριφθεί → δημιουργεί
 * task». Τα δύο βήματα πριν από αυτό — αυτόματη υποβολή στον πάροχο,
 * αυτόματη λήψη της απάντησής του — παραμένουν εξωτερικά μπλοκαρισμένα
 * (`HANDOVER.md` §1.13, κανένας πάροχος δεν έχει συμφωνήσει API). Αυτό εδώ
 * δεν προσποιείται ότι λύνει εκείνα· υποθέτει μόνο ότι ΚΑΠΟΙΟΣ — σήμερα ένας
 * άνθρωπος στο dropdown κατάστασης, αύριο ίσως ένα webhook — έγραψε ήδη
 * `CancelledByUs` πάνω στη σύμβαση, και αναλαμβάνει από εκεί και πέρα.
 *
 * ## AUDIT 07/09 (μετά το commit 254): ΤΙ ΚΕΙΜΕΝΟ γράφει, και γιατί άλλαξε
 *
 * Το status `Rejected` που άκουγε αρχικά αυτή η κλάση ΕΦΥΓΕ στο (254) --
 * συγχωνεύτηκε στο `cancelled_by_us` μαζί με το γενικό `cancelled`
 * (`MigrateStatusVocabulary::MAP`). Το νέο `cancelled_by_us` καλύπτει και
 * τους **τρεις** λόγους ακύρωσης «από εμάς» του `docs/STATUS-MODEL.md` §7
 * (Δέσμευση συμβολαίου, Πολιτική αποδοχής, Δεν ολοκληρώθηκαν δικαιολογητικά)
 * -- όχι μόνο την απόρριψη παρόχου. Χωρίς στήλη `cancellation_reason` (έρχεται
 * στο commit 256) δεν υπάρχει τρόπος να ξεχωρίσει ΠΟΙΟΣ από τους τρεις λόγους
 * ισχύει σε κάθε συγκεκριμένη ακύρωση.
 *
 * Το κείμενο της εργασίας ΕΠΡΕΠΕ να άλλαζε μαζί με το σκοπό: μέχρι τις 07/09
 * έγραφε ρητά «Απορρίφθηκε από πάροχο -- ο πάροχος απέρριψε την αίτηση»,
 * πράγμα που είναι απλά ψέμα για μια ακύρωση λόγω δέσμευσης συμβολαίου ή
 * ημιτελών δικαιολογητικών. Δεν το έπιασε κανένα test -- δεν υπάρχει καθόλου
 * test αρχείο για αυτή την κλάση. Το κείμενο παρακάτω είναι πλέον γενικό,
 * αληθές για και τους τρεις λόγους· θα ξαναγίνει συγκεκριμένο (π.χ. μόνο για
 * «Πολιτική αποδοχής», όπως προέβλεπε αρχικά το CHANGELOG (254)) μόλις
 * υπάρξει η στήλη του λόγου να το ρωτήσει.
 *
 * ## Γιατί Infrastructure και όχι Domain
 *
 * Πρώτη γραφή αυτού του αρχείου ήταν σε `Domain\Contract` -- λάθος, και το
 * έπιασε ο υπάρχων έλεγχος `DomainStaysFrameworkFreeTest` στο πρώτο
 * `composer check:all` (31/08): η κλάση καλεί `add_action()`/`current_time()`,
 * πλατφόρμα, όχι καθαρή λογική. Ο `ContractNotices` κάνει ΑΚΡΙΒΩΣ την ίδια
 * δουλειά -- ακούει το ίδιο γεγονός, αγγίζει WordPress και Persistence -- και
 * ήδη ζει σωστά εδώ, στο `Infrastructure`.
 *
 * ## Γιατί ακούει το ίδιο γεγονός με τον ContractNotices
 *
 * Ο `ContractLifecycle` δεν πρέπει να ξέρει ότι υπάρχουν εργασίες, όπως δεν
 * ξέρει ότι υπάρχει καμπανάκι (`ContractNotices`). Και οι δύο συνδέονται στο
 * ίδιο `STATUS_CHANGED` για
 * τον ίδιο λόγο: όποιος κι αν είναι ο καλών — χειροκίνητη αλλαγή, μαζική
 * ενέργεια, μελλοντικό webhook παρόχου — περνά ΠΑΝΤΑ από εδώ, άρα η εργασία
 * δημιουργείται μία φορά, με τον ίδιο τρόπο, ανεξάρτητα ποιος γύρισε τη
 * σύμβαση σε CancelledByUs.
 *
 * ## Γιατί εργασία και όχι μόνο καμπανάκι
 *
 * Το `ContractNotices` ήδη χτυπά καμπανάκι για το CancelledByUs (είναι στο
 * δικό του `ANNOUNCED`) — αυτό ενημερώνει. Η εργασία εδώ είναι διαφορετική:
 * δεν λέει απλώς «κάτι έγινε», λέει «κάτι πρέπει να γίνει», και μένει στη
 * λίστα «Ανοιχτές» μέχρι κάποιος να την κλείσει ρητά — ο συνεργάτης δεν
 * μπορεί να τη χάσει σαν καμπανάκι σε λίστα από δέκα.
 *
 * ## Γιατί προθεσμία «σήμερα»
 *
 * Ρητή απόφαση ιδιοκτήτη (31/08): μια ακύρωση από εμάς είναι επιχειρηματικό
 * ρίσκο, όχι κάτι που περιμένει. Προθεσμία «τώρα» σημαίνει ότι η εργασία
 * μπαίνει αμέσως και στο `ECRM_Tasks::due_count()` -- το μπατζάκι δίπλα στο
 * «Εργασίες» στο sidebar -- αντί να εμφανιστεί εκεί μόνο την επόμενη μέρα.
 *
 * ## Γιατί δεν εμπιστεύεται customer_id
 *
 * Το `ContractDetails::noticeSubject()` -- η ίδια πηγή που ήδη χρησιμοποιεί
 * το `ContractNotices` -- δεν επιστρέφει `customer_id`, μόνο τα στοιχεία
 * εμφάνισης. Η εργασία συνδέεται με τη σύμβαση μέσω `contract_id`· από εκεί
 * ο πελάτης είναι ένα κλικ μακριά. Δεν αξίζει δεύτερο ερώτημα SQL μόνο για
 * μια στήλη προαιρετική στο σχήμα του πίνακα `tasks`.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Infrastructure;

use EnergyCRM\Domain\Contract\ContractLifecycle;
use EnergyCRM\Domain\Contract\ContractStatus;
use EnergyCRM\Persistence\ContractDetails;
use EnergyCRM\Persistence\TaskRepository;

final class RejectionFollowUp
{
    public function __construct(
        private readonly ContractDetails $details,
        private readonly TaskRepository $tasks,
    ) {
    }

    /**
     * Οι καταστάσεις που θέλουν κάποιον να κάνει κάτι.
     *
     * @var list<ContractStatus>
     */
    private const FOLLOWED_UP = [
        ContractStatus::ThalisRejected,
        ContractStatus::MnpReject,
        ContractStatus::Cancelled,
    ];

    /** Ίδιο σημείο σύνδεσης με τον ContractNotices. */
    public function register(): void
    {
        add_action(ContractLifecycle::STATUS_CHANGED, [$this, 'onStatusChanged'], 10, 2);
    }

    public function onStatusChanged(int $contractId, string $to): void
    {
        $status = ContractStatus::tryFromSlug($to);

        if (! in_array($status, self::FOLLOWED_UP, true)) {
            return;
        }

        $row = $this->details->noticeSubject($contractId);

        if ($row === null) {
            return;
        }

        // Χωρίς ιδιοκτήτη δεν υπάρχει σε ποιον να ανατεθεί -- και το
        // `assigned_to` του πίνακα `tasks` είναι NOT NULL, δεν δέχεται 0.
        $owner = (int) $row['partner_user_id'];

        if ($owner <= 0) {
            return;
        }

        $code = (string) ($row['code'] ?? '');
        $name = $this->customerName($row);

        $this->tasks->create([
            'contract_id' => $contractId,
            'customer_id' => null,
            'assigned_to' => $owner,
            'created_by'  => null,
            'title'       => trim($status->label() . ' — ' . $code),
            'note'        => sprintf(
                $status === ContractStatus::Cancelled
                    ? '%s: η αίτηση ακυρώθηκε. Έλεγξε την αιτία και ενημέρωσε τον πελάτη αν χρειάζεται.'
                    : '%s: ο πάροχος απέρριψε την αίτηση. Δες τι χρειάζεται για να ξαναμπεί.',
                $name
            ),
            'due_at'   => current_time('mysql'),
            'priority' => 'high',
            'status'   => 'open',
        ]);
    }

    /**
     * @param array<string, mixed> $row
     */
    private function customerName(array $row): string
    {
        $company = (string) ($row['company_name'] ?? '');
        $person  = trim(
            (string) ($row['first_name'] ?? '') . ' ' . (string) ($row['last_name'] ?? '')
        );

        return ($company ?: $person) ?: 'Ο πελάτης';
    }
}
