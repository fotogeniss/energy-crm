<?php

/**
 * Deletes personal data the CRM no longer has a reason to keep.
 *
 * `contracts.extracted_json` holds the raw payload the model returned when
 * reading a customer's ID card and utility bill: name, father's name, ID
 * number, date of birth, full address. Every field of it is already stored,
 * validated, in the customers table. The blob exists so an agent can check
 * what the extraction actually said — useful for days, not for years.
 *
 * GDPR calls this storage limitation: keeping a second copy of identity
 * documents indefinitely, for a purpose that expired, is the kind of thing
 * that turns an ordinary breach into a reportable one.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Infrastructure;

use EnergyCRM\Persistence\ContractRepository;
use EnergyCRM\Persistence\MetricsRepository;
use EnergyCRM\Persistence\RequestKeyRepository;

final class Retention
{
    public const HOOK = 'ecrm_retention_sweep';

    /** Days an extraction payload is kept before being cleared. */
    private const DEFAULT_DAYS = 90;

    /**
     * Ημέρες που κρατιέται μια δέσμευση idempotency (Επίπεδο Γ).
     *
     * Η δέσμευση χρησιμεύει όσο ο client μπορεί ακόμα να επαναλάβει το ίδιο
     * αίτημα. Η ουρά του (Δ) θα έχει δικό της TTL ωρών, οπότε επτά ημέρες
     * είναι άνετο περιθώριο και όχι στόχος -- ένα uuid ανά νέα σύμβαση σε
     * ~2.000 καρτέλες είναι μερικές χιλιάδες γραμμές, όχι όγκος.
     */
    private const REQUEST_KEY_DAYS = 7;

    public function __construct(private readonly ContractRepository $contracts)
    {
    }

    public function register(): void
    {
        add_action(self::HOOK, [$this, 'onScheduledSweep']);

        if (! wp_next_scheduled(self::HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::HOOK);
        }
    }

    public static function unschedule(): void
    {
        wp_clear_scheduled_hook(self::HOOK);
    }

    /**
     * How long extraction payloads live.
     *
     * Filterable so a company whose retention policy says otherwise can set it
     * without patching the plugin. Zero disables the sweep entirely.
     */
    public function days(): int
    {
        $days = (int) get_option('ecrm_extraction_retention_days', self::DEFAULT_DAYS);

        return max(0, (int) apply_filters('ecrm_extraction_retention_days', $days));
    }

    /**
     * @return int Number of contracts cleared.
     */
    /**
     * Cron entry point. WordPress discards return values, so the count is
     * logged here rather than handed back into a void.
     */
    public function onScheduledSweep(): void
    {
        Heartbeat::mark(self::HOOK);

        $cleared = $this->sweep();

        if ($cleared > 0) {
            error_log(sprintf('[Energy CRM] Καθαρίστηκαν δεδομένα εξαγωγής από %d συμβάσεις.', $cleared));
        }

        // Το ιστορικό λειτουργίας κλαδεύεται εδώ και όχι σε δική του εργασία:
        // είναι ημερήσιο σβήσιμο λίγων γραμμών, και μια πέμπτη cron εγγραφή
        // θα ήταν ένα ακόμη πράγμα που μπορεί να μην τρέξει -- ακριβώς το
        // πρόβλημα που μετράει ο ίδιος ο πίνακας.
        (new MetricsRepository())->prune(Metrics::keepDays());

        // Ιδιος λόγος με το ιστορικό λειτουργίας ακριβώς από πάνω: σβήσιμο
        // λίγων γραμμών μια φορά την ημέρα δεν αξίζει δική του cron εγγραφή --
        // κάθε προγραμματισμένη εργασία είναι ένα ακόμη πράγμα που μπορεί να
        // μην τρέξει.
        (new RequestKeyRepository())->purge(self::REQUEST_KEY_DAYS);
    }

    /**
     * @return int Number of contracts cleared.
     */
    public function sweep(): int
    {
        return $this->contracts->clearExtractionPayloads($this->days());
    }
}
