<?php

/**
 * POST /contracts — create or update a contract together with its customer.
 *
 * The single most dangerous endpoint in the system: it writes customer identity
 * data, it decides who owns the contract, and it is where the IDOR closed in
 * step 2 lived. The ownership rules are therefore not repeated here — every
 * read and write goes through a repository that will not run without a scope.
 *
 * What is left here is the orchestration: resolve the target, refuse what the
 * actor may not touch, write, audit, enqueue. Turning the request into columns
 * moved to ContractSaveMapping — 220 lines that change when a provider adds a
 * field, next to code that changes when an ownership rule does.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Http;

use ECRM_Audit;
use ECRM_Validate;
use EnergyCRM\Access\Capability;
use EnergyCRM\Access\ProviderVisibility;
use EnergyCRM\Access\ScopeResolver;
use EnergyCRM\Access\UserScope;
use EnergyCRM\Domain\Contract\StatusEntryGate;
use EnergyCRM\Domain\Contract\ContractLifecycle;
use EnergyCRM\Domain\Contract\ContractStatus;
use EnergyCRM\Domain\Contract\RequestKey;
use EnergyCRM\Infrastructure\DocumentQueue;
use EnergyCRM\Infrastructure\DraftExitGate;
use EnergyCRM\Persistence\ContractRepository;
use EnergyCRM\Persistence\CustomerRepository;
use EnergyCRM\Persistence\RequestKeyRepository;
use WP_REST_Request;
use WP_REST_Response;

final class ContractSaveController implements Controller
{
    public function __construct(
        private readonly ScopeResolver $scopes,
        private readonly ContractRepository $contracts,
        private readonly CustomerRepository $customers,
        private readonly ContractLifecycle $lifecycle,
        private readonly DraftExitGate $draftExit,
        private readonly StatusEntryGate $paperwork,
        private readonly RequestKeyRepository $requestKeys,
        private readonly ProviderVisibility $providerAccess,
    ) {
    }

    public function routes(): void
    {
        register_rest_route(Router::NAMESPACE, '/contracts', [
            'methods'             => 'POST',
            'callback'            => [$this, 'save'],
            // Ο φύλακας εδώ είναι το δάπεδο, όχι όλη η απόφαση. Η ίδια
            // διαδρομή δημιουργεί σύμβαση, την επεξεργάζεται και τη
            // μετακινεί, και αυτά είναι τρία διαφορετικά δικαιώματα. Ένα
            // μόνο cap πάνω στη διαδρομή θα ζητούσε άδεια αλλαγής
            // κατάστασης από κάποιον που απλώς διορθώνει ένα τηλέφωνο —
            // ή, όπως ήταν ως τώρα, δεν θα ζητούσε τίποτα από κάποιον που
            // οριστικοποιεί. Το κάθε δικαίωμα ελέγχεται εκεί που φαίνεται
            // τι ζητά η αίτηση, όπως κάνει ήδη ο ContractsBulkController
            // για τις τέσσερις μαζικές ενέργειές του.
            'permission_callback' => Guards::crmUser(),
            // Field-level shapes are declared where they are read; what matters
            // at the route is that the two ids are integers, because they are
            // what decides which rows get written.
            'args'                => [
                'contract_id' => ['type' => 'integer', 'default' => 0, 'minimum' => 0],
                'customer_id' => ['type' => 'integer', 'default' => 0, 'minimum' => 0],
                // Δηλωμένο εδώ ώστε να φαίνεται στο σχήμα της διαδρομής, αλλά
                // η μορφή του ελέγχεται στο RequestKey -- ένα 'format' του WP
                // δεν ξέρει τι είναι uuid v4 σε αντίθεση με v1.
                'client_request_id' => ['type' => 'string', 'default' => ''],
            ],
        ]);
    }

    /**
     * Η μία πόρτα -- και το μόνο σημείο που ξέρει από idempotency.
     *
     * ## Γιατί περιτύλιγμα και όχι έξι κλήσεις μέσα στο perform()
     *
     * Η δέσμευση πρέπει να ελευθερώνεται σε ΚΑΘΕ άρνηση, αλλιώς ο συνεργάτης
     * που διορθώνει ένα ΑΦΜ και ξαναπατά κλειδώνεται έξω από τη δική του
     * δημιουργία. Το `perform()` επιστρέφει από επτά διαφορετικά σημεία, και
     * ένας κανόνας που τηρείται σε έξι από τα επτά δεν είναι κανόνας -- είναι
     * ακριβώς το σχήμα του σφάλματος που έκλεισε η (10). Εδώ υπάρχει μία
     * απόφαση: 200 σημαίνει ολοκλήρωση, οτιδήποτε άλλο σημαίνει απελευθέρωση.
     *
     * ## Μόνο στη δημιουργία
     *
     * Σε ενημέρωση (`contract_id > 0`) το κλειδί αγνοείται: η εγγραφή πάει σε
     * συγκεκριμένη γραμμή που υπάρχει ήδη, και η διπλή μετάβαση κόβεται από
     * τον γράφο (χωρίς self-loops) και από το `ContractLifecycle::moveTo()`.
     *
     * ## Χωρίς κλειδί, όπως πριν
     *
     * Ενα αίτημα που δεν στέλνει `client_request_id` περνά ακριβώς όπως
     * περνούσε ως τώρα. Αυτό είναι σκόπιμο και όχι παράλειψη: μια καρτέλα
     * ανοιχτή από χθες τρέχει ακόμα το προηγούμενο JS από την cache, και δεν
     * υπάρχει λόγος να της χαλάσει η αποθήκευση για ένα πεδίο που δεν ξέρει.
     */
    public function save(WP_REST_Request $request): WP_REST_Response
    {
        $params = $request->get_json_params() ?: $request->get_params();
        $scope  = $this->scopes->forCurrentUser();
        $sent   = (string) ($params['client_request_id'] ?? '');

        if ($sent === '' || ((int) $request['contract_id']) > 0) {
            return $this->perform($request, $params, $scope);
        }

        // Απορρίπτεται αντί να αγνοηθεί σιωπηλά: ένας client που στέλνει
        // κλειδί νομίζει ότι προστατεύεται. Το να το πετούσαμε χωρίς να πούμε
        // τίποτα θα του άφηνε την εντύπωση της προστασίας χωρίς την προστασία.
        if (! RequestKey::isValid($sent)) {
            return new WP_REST_Response([
                'ok'    => false,
                'error' => 'Μη έγκυρο αναγνωριστικό αιτήματος.',
                'field' => 'client_request_id',
            ], 422);
        }

        $key    = RequestKey::normalise($sent);
        $userId = $scope->actorId();

        if (! $this->requestKeys->claim($userId, $key)) {
            return $this->answerForClaimedKey($userId, $key, $scope);
        }

        $response = $this->perform($request, $params, $scope);

        if ($response->get_status() !== 200) {
            $this->requestKeys->release($userId, $key);

            return $response;
        }

        /** @var array<string, mixed> $data */
        $data = $response->get_data();

        $this->requestKeys->complete($userId, $key, (int) $data['contract_id']);

        return $response;
    }

    /**
     * Το κλειδί το κρατά ήδη κάποιος: τι λέμε στον client.
     *
     * Δύο διαφορετικά πράγματα, με διαφορετική απάντηση το καθένα. Αν η
     * δέσμευση έχει αποτέλεσμα, αυτή είναι η επανάληψη που περιμέναμε και
     * επιστρέφουμε την ΑΡΧΙΚΗ σύμβαση -- 200, ίδιο σχήμα με μια κανονική
     * αποθήκευση, ώστε ο client να μη χρειάζεται δεύτερο μονοπάτι. Αν δεν
     * έχει, το πρώτο αίτημα τρέχει αυτή τη στιγμή: 409 και ξαναδοκίμασε, ποτέ
     * δεύτερη δημιουργία.
     *
     * Το `replayed` λέει την αλήθεια στο UI: «αποθηκεύτηκε» και «ήταν ήδη
     * αποθηκευμένο» δεν είναι το ίδιο γεγονός, και το δεύτερο δεν πρέπει να
     * μοιάζει με το πρώτο.
     */
    private function answerForClaimedKey(int $userId, string $key, UserScope $scope): WP_REST_Response
    {
        $contractId = $this->requestKeys->contractFor($userId, $key);

        if ($contractId === null) {
            return new WP_REST_Response([
                'ok'    => false,
                'error' => 'Η ίδια αίτηση βρίσκεται ήδη σε εξέλιξη. Δοκίμασε ξανά σε λίγο.',
            ], 409);
        }

        $existing = $this->contracts->find($contractId, $scope);

        // Η σύμβαση δημιουργήθηκε και μετά διαγράφηκε ή βγήκε από την εμβέλεια.
        // Σιωπηλή νέα δημιουργία εδώ θα ήταν το χειρότερο: ο συνεργάτης θα
        // έβλεπε «αποθηκεύτηκε» και θα είχε δύο αιτήσεις για τον ίδιο πελάτη.
        if ($existing === null) {
            return new WP_REST_Response([
                'ok'    => false,
                'error' => 'Η αίτηση είχε ήδη καταχωρηθεί, αλλά δεν είναι πια διαθέσιμη.',
            ], 409);
        }

        return new WP_REST_Response([
            'ok'          => true,
            'contract_id' => $contractId,
            'customer_id' => (int) ($existing['customer_id'] ?? 0),
            'status'      => $existing['status'] ?? null,
            'replayed'    => true,
        ], 200);
    }

    /**
     * Η αποθήκευση η ίδια -- αμετάβλητη από το Επίπεδο Γ.
     *
     * @param array<string, mixed> $params
     */
    private function perform(WP_REST_Request $request, array $params, UserScope $scope): WP_REST_Response
    {
        // Resolve the target before touching anything: a contract the actor
        // cannot see is indistinguishable from one that does not exist.
        $contractId = (int) $request['contract_id'];
        $existing   = null;

        // Δημιουργία και επεξεργασία είναι δύο δικαιώματα, όχι ένα. Ποιο από
        // τα δύο ζητά η αίτηση το λέει το contract_id, πριν διαβαστεί
        // οτιδήποτε: id που δεν βρίσκεται είναι 404 παρακάτω, δεν γίνεται
        // δημιουργία.
        $refusal = $this->refuseWithout(
            $contractId > 0 ? Capability::EDIT_CONTRACT : Capability::CREATE_CONTRACT
        );

        if ($refusal !== null) {
            return $refusal;
        }

        if ($contractId > 0) {
            $existing = $this->contracts->find($contractId, $scope);

            if ($existing === null) {
                return new WP_REST_Response(['ok' => false, 'error' => 'Η σύμβαση δεν βρέθηκε.'], 404);
            }
        }

        $refusal = $this->refuseProvider($params, $existing, $scope);

        if ($refusal !== null) {
            return $refusal;
        }

        $customer = ContractSaveMapping::customerFrom($params);

        if (isset($customer['afm']) && ! ECRM_Validate::afm($customer['afm'])) {
            return new WP_REST_Response([
                'ok'    => false,
                'error' => 'Μη έγκυρο ΑΦΜ (αποτυχία ελέγχου ψηφίου).',
                'field' => 'afm',
            ], 422);
        }

        // The address is not required — customerFrom() drops empty fields, so
        // reaching this line means one was typed. Refused rather than stored,
        // because the two places it goes are both silent about it: it prints
        // onto the provider's form as though it were an address, and
        // SignLinkController answers `emailed: false` when is_email() rejects
        // it, so the agent sees a saved contract and the customer never gets
        // the signature link. A save that stops with a message is the only
        // version of this the agent finds out about.
        if (isset($customer['email']) && ! is_email($customer['email'])) {
            return new WP_REST_Response([
                'ok'    => false,
                'error' => 'Μη έγκυρη διεύθυνση email. Διόρθωσέ την ή άφησέ την κενή.',
                'field' => 'email',
            ], 422);
        }

        $customerId = $this->resolveCustomer($request, $scope, $existing);

        if ($customerId === false) {
            return new WP_REST_Response(['ok' => false, 'error' => 'Ο πελάτης δεν βρέθηκε.'], 404);
        }

        // No customer named in the request (fresh application, or the screen
        // did not send one) but a ΑΦΜ was typed: reuse the reachable customer
        // row that ΑΦΜ already belongs to, rather than let create() below
        // raise a duplicate — build queue 03, 25/08 audit. findIdByAfm() is
        // scoped the same as every other lookup here, so this only ever
        // resolves into a row the actor could already reach.
        if ($customerId === 0 && isset($customer['afm']) && $customer['afm'] !== '') {
            $customerId = $this->customers->findIdByAfm($scope, $customer['afm']);
        }

        // Before anything is written, including the customer row: a refused
        // save must leave the whole request without effect. Putting this after
        // the customer update would answer 409 having already changed the
        // customer's name. resolveCustomer() above only reads, so it is safe on
        // this side of the line — and the gate needs the id it resolves.
        $refusal = $this->refuseStatusChange($params, $existing, $contractId, $customerId, $scope, $customer);

        if ($refusal !== null) {
            return $refusal;
        }

        $previousCustomer = $customerId > 0 && $customer !== []
            ? $this->customers->find($customerId, $scope)
            : null;

        if ($customer !== []) {
            if ($customerId > 0) {
                // The bool is dropped on purpose: what stood here returned
                // $customerId in both branches of a ternary, which reads as a
                // handled failure and never was one — CHANGELOG 2026-08-16 (7).
                $this->customers->update($customerId, $scope, $customer);
            } else {
                $customerId = $this->customers->create($customer);
            }
        }

        // Whether this is an edit decides how contractFrom() treats a field the
        // request did not send: on create there is no row yet, so every column
        // needs a value and the defaults below are it. On update there is a row
        // already, and a field the agent's screen did not resend must leave
        // that column alone rather than blank it — see contractFrom().
        $isUpdate = $existing !== null;
        $contract = ContractSaveMapping::contractFrom($params, $customerId, $isUpdate);

        // On an edit, a status in the payload is a real transition — the form
        // only ever sends one starting from draft (ecrm-form.js: stay on
        // 'draft', or finalise to 'presale'; refuseStatusChange() above has
        // already refused anything the pipeline forbids). It must go through
        // ContractLifecycle::moveTo(), the only place that writes the
        // status_change event, fires the in-app/SMS notifications and the
        // ecrm_contract_status_changed hook. Writing it as a plain column
        // below skipped all four, silently: ECRM_Audit::excluded() drops
        // 'status' from its own diff on the assumption that "status changes
        // keep their own dedicated events" — true for ContractStatusController
        // and the bulk action, not for this route until now.
        $statusChange = null;

        if ($isUpdate && array_key_exists('status', $contract)) {
            $statusChange = $contract['status'];
            unset($contract['status']);
        }

        if ($isUpdate) {
            $this->contracts->update($contractId, $scope, $contract);
        } else {
            $contractId = $this->contracts->create($contract, $scope);

            if ($contractId <= 0) {
                return new WP_REST_Response(['ok' => false, 'error' => 'Η αποθήκευση απέτυχε.'], 500);
            }

            $this->contracts->assignCode($contractId, $scope);
        }

        if ($statusChange !== null) {
            $this->lifecycle->moveTo($contractId, $statusChange, [
                'user_id' => $scope->actorId(),
                'from'    => (string) $existing['status'],
            ]);
        }

        $this->recordHistory($contractId, $scope, $existing, $previousCustomer, $contract, $customer);

        // Scheduled, not rendered here. Building it inline held a PHP worker
        // and 256 MB for seconds on every save, drafts included — see
        // DocumentQueue. Nothing on this screen waits for the file.
        DocumentQueue::enqueue($contractId);

        // Absent only when this was an edit that neither resent status nor
        // moved it (the field-only "Αποθήκευση Αλλαγών" path) — $existing is
        // guaranteed to exist in that case.
        $responseStatus = $statusChange ?? ($contract['status'] ?? ($existing !== null ? $existing['status'] : null));

        return new WP_REST_Response([
            'ok'          => true,
            'contract_id' => $contractId,
            'customer_id' => $customerId,
            'status'      => $responseStatus,
        ], 200);
    }

    /**
     * Refuse a status the pipeline does not allow from here, or null to proceed.
     *
     * Until 2026-08-16 this route was the only one of the three that writes
     * `status` without consulting anything: ContractStatusController::change()
     * and ContractsBulkController::changeStatus() both ask
     * ContractStatus::canMoveTo() first. That was not a small inconsistency,
     * because finalisation happens here and nowhere else — ecrm-form.js binds
     * [data-finalize] to a POST on this route — and because routed, active and
     * resolved are payable. ContractSaveStatusTest pinned what it allowed:
     * reviving a cancelled contract, and jumping a draft straight to active.
     *
     * The rule itself is not repeated here. It lives in the enum, and this asks
     * the enum the same question ContractStatusController asks, answering with
     * the same shape so one screen can handle both.
     *
     * A request that does not send `status` is not a transition and is not
     * touched: contractFrom() omits the column entirely, which is what makes an
     * ordinary field edit on a signed contract still work.
     *
     * In this order. First the capability, and 403: whether the caller may move
     * a contract at all is not a question about this contract, so it is
     * answered before anything is said about which moves exist. Then the graph
     * decides whether the move exists at all, and answers 409 — a move the
     * graph has never heard of is refused for that reason, not for a missing
     * document, so `testADraftCannotBeMovedStraightToPayableActive` still gets
     * 409 even though ΕΝΕΡΓΟΣ also happens to be a gated status (07/09: this
     * used to run before the graph check and stole its 409 for every illegal
     * jump that happened to land on a gated status). Only for a move the graph
     * allows does PaperworkGate ask whether THIS contract's papers are in
     * order, 422 — a legal move the contract is not ready for is a different
     * thing from an illegal one. Only then does DraftExitGate ask about the ΑΦΜ,
     * also 422. The gates are shared objects rather than `if`s here because
     * ContractStatusController can make the same moves; a rule enforced on one
     * of two doors is the shape of the bug CHANGELOG (10) had just closed —
     * and the capability was exactly that bug, on exactly those two doors.
     *
     * @param array<string, mixed>      $params
     * @param array<string, mixed>|null $existing
     * @param array<string, string>     $customer
     */
    private function refuseStatusChange(
        array $params,
        ?array $existing,
        int $contractId,
        int $customerId,
        UserScope $scope,
        array $customer,
    ): ?WP_REST_Response {
        if (! isset($params['status'])) {
            return null;
        }

        $target = ContractSaveMapping::statusFrom($params);
        $afm    = (string) ($customer['afm'] ?? '');

        // Creation has no previous status, so the graph has nothing to say
        // about it — but "every contract starts as a draft" was a property of
        // the screen rather than of this endpoint, and a contract could be born
        // payable. These two are the only stages a first save can mean.
        if ($existing === null) {
            if ($target !== ContractStatus::Draft && $target !== ContractStatus::Presale) {
                return new WP_REST_Response([
                    'ok'    => false,
                    'error' => 'Νέα σύμβαση μπορεί να ξεκινήσει μόνο ως πρόχειρη ή ως νέα αίτηση.',
                    'field' => 'status',
                ], 422);
            }

            return $this->refuseMissingAfm(
                $this->draftExit->refusalOnCreate($target, $customerId, $scope, $afm)
            );
        }

        $source = ContractStatus::tryFromSlug((string) $existing['status']);

        if ($source === null) {
            return null;
        }

        // Η μετακίνηση θέλει το δικό της δικαίωμα — το ίδιο που ζητά ο
        // ContractStatusController για την ακριβώς ίδια πράξη. Ο έλεγχος
        // μπαίνει πριν από τον γράφο: σε ποιον δεν επιτρέπεται να μετακινήσει
        // καθόλου, δεν απαντάμε ποιες μεταβάσεις θα ήταν νόμιμες.
        //
        // Μόνο όταν η κατάσταση όντως αλλάζει. Η φόρμα ξαναστέλνει «draft» σε
        // κάθε προσωρινή αποθήκευση προχείρου (ecrm-form.js: save('draft')),
        // και αυτό είναι αποθήκευση πεδίων, όχι μετάβαση.
        if ($target !== $source) {
            $refusal = $this->refuseWithout(Capability::CHANGE_STATUS);

            if ($refusal !== null) {
                return $refusal;
            }
        }

        // AUDIT 07/09: το ίδιο «όχι μετάβαση» πρέπει να γλιτώνει και τον
        // γράφο, όχι μόνο το δικαίωμα. Ως τις 07/09 κάθε κατάσταση επέτρεπε
        // να μείνει στον εαυτό της (`allowedNext()` περιείχε ένα self-loop),
        // οπότε το `canMoveTo()` παρακάτω περνούσε σιωπηλά για ένα ξανά-
        // στειλμένο ίδιο status. Το νέο μοντέλο αφαίρεσε επίτηδες τα
        // self-loops -- η ιδιοποτεντία ζει στο ContractLifecycle::moveTo()
        // (γραμμή «$from === $to» εκεί), όχι στον γράφο -- και χωρίς αυτό το
        // early return η ίδια «Προσωρινή αποθήκευση» που η φόρμα στέλνει σε
        // κάθε autosave θα έπαιρνε 409 «δεν επιτρέπεται μετάβαση από Χ σε Χ».
        if ($target === $source) {
            return null;
        }

        // Ο ειδικός φύλακας για ψεύτικο «Υπογράφηκε» αφαιρέθηκε στις 07/09
        // μαζί με την κατάσταση. Η ίδια ανησυχία ζει τώρα στην `PaperworkGate`
        // λίγες γραμμές πιο κάτω -- και όχι μόνο για μία κατάσταση.
        // Ο γράφος πρώτα: μια μετάβαση που δεν υπάρχει καθόλου απορρίπτεται
        // γι' αυτόν τον λόγο, όχι επειδή λείπει ένα χαρτί -- draft → active
        // είναι 409 (δεν υπάρχει τέτοια μετάβαση), όχι 422 (λείπουν
        // δικαιολογητικά), παρότι το active είναι και φυλασσόμενη κατάσταση.
        if (! $source->canMoveTo($target)) {
            return new WP_REST_Response([
                'ok'      => false,
                'error'   => sprintf(
                    'Δεν επιτρέπεται μετάβαση από «%s» σε «%s».',
                    $source->label(),
                    $target->label()
                ),
                'allowed' => array_map(
                    static fn (ContractStatus $s): array => ['status' => $s->value, 'label' => $s->label()],
                    $source->allowedNext()
                ),
            ], 409);
        }

        // Χαρτιά και υπογραφή (07/09). Αυτή η διαδρομή ΔΕΝ τα ρωτούσε: ο
        // έλεγχος ζούσε μόνο στον ContractStatusController και στον
        // ContractsBulkController, ενώ η φόρμα γράφει `status` σαν κανονικό
        // πεδίο -- και ο Πωλητής έχει CHANGE_STATUS. Ο ContractLifecycle
        // αρνείται πλέον την ίδια μετάβαση ούτως ή άλλως· εδώ ρωτάμε πρώτοι
        // ώστε ο χρήστης να πάρει 422 με τον λόγο, αντί για σιωπηλό false.
        // Μετά τον γράφο -- όχι πριν -- ώστε μια μετάβαση που δεν υπάρχει
        // καθόλου να απαντάει 409 και όχι 422.
        $paperwork = $this->paperwork->refusalOnEntry($target, $contractId);

        if ($paperwork !== null) {
            return new WP_REST_Response(['ok' => false, 'error' => $paperwork], 422);
        }

        return $this->refuseMissingAfm(
            $this->draftExit->refusalOnMove($source, $target, $customerId, $scope, $afm)
        );
    }

    /**
     * 403 όταν λείπει το δικαίωμα, αλλιώς null.
     *
     * Ίδιο μήνυμα με τον ContractsBulkController: για τον χρήστη είναι το ίδιο
     * γεγονός, και δύο διατυπώσεις του ίδιου «δεν επιτρέπεται» διαβάζονται σαν
     * δύο διαφορετικά προβλήματα.
     */
    /**
     * Πάροχος που ο δράστης δεν βλέπει (278).
     *
     * Ο έλεγχος ζει εδώ και όχι μόνο στη φόρμα: η φόρμα απλώς δεν δείχνει τον
     * πάροχο, αλλά ένα αίτημα φτιάχνεται και χωρίς φόρμα. Πριν γραφτεί
     * οτιδήποτε, όπως κάθε άρνηση αυτού του controller.
     *
     * Περνάει χωρίς ερώτηση όταν ο πάροχος ΔΕΝ ΑΛΛΑΖΕΙ σε υπάρχουσα αίτηση:
     * απόφαση ιδιοκτήτη 21/09, ο περιορισμός είναι για νέες αιτήσεις, και μια
     * παλιά αίτηση σε πάροχο που αφαιρέθηκε μένει επεξεργάσιμη. Αλλαγή ΠΡΟΣ
     * πάροχο που δεν βλέπει, όμως, είναι νέα επιλογή και ελέγχεται.
     *
     * @param array<string, mixed>      $params
     * @param array<string, mixed>|null $existing
     */
    private function refuseProvider(array $params, ?array $existing, UserScope $scope): ?WP_REST_Response
    {
        $requested = (int) ($params['provider_id'] ?? 0);

        if ($requested <= 0) {
            return null;
        }

        if ($existing !== null && (int) ($existing['provider_id'] ?? 0) === $requested) {
            return null;
        }

        if ($this->providerAccess->forScope($scope)->allows($requested)) {
            return null;
        }

        return new WP_REST_Response([
            'ok'    => false,
            'error' => 'Δεν έχεις πρόσβαση σε αυτόν τον πάροχο. '
                . 'Ζήτα από τον υπεύθυνό σου να σου τον ανοίξει.',
            'field' => 'provider_id',
        ], 403);
    }

    private function refuseWithout(string $capability): ?WP_REST_Response
    {
        if (current_user_can($capability)) {
            return null;
        }

        return new WP_REST_Response(
            ['ok' => false, 'error' => 'Δεν έχεις δικαίωμα για αυτή την ενέργεια.'],
            403
        );
    }

    /**
     * Wrap the gate's answer, or pass null straight through.
     *
     * 422 rather than 409: the transition itself is legal, and the agent fixes
     * this by typing an ΑΦΜ rather than by choosing a different stage. `field`
     * is what the form uses to put the message on the right input, the same way
     * the ΑΦΜ and email validators above already do.
     */
    private function refuseMissingAfm(?string $refusal): ?WP_REST_Response
    {
        if ($refusal === null) {
            return null;
        }

        return new WP_REST_Response(['ok' => false, 'error' => $refusal, 'field' => 'afm'], 422);
    }

    /**
     * The customer this save applies to, or false when the request named one
     * the actor may not touch.
     *
     * @param array<string, mixed>|null $existing
     *
     * @return int|false
     */
    private function resolveCustomer(
        WP_REST_Request $request,
        UserScope $scope,
        ?array $existing,
    ): int|false {
        $customerId = (int) $request['customer_id'];

        if ($customerId <= 0) {
            // No customer named in the request. On a fresh save that means
            // "none yet" — 0 is correct. On an edit it means the screen did
            // not resend it, and the contract already has one: keep it. This
            // used to return 0 unconditionally, which is how customer_id
            // became NULL on every edit that did not resend it (CHANGELOG
            // 2026-08-16 (3)/(4)).
            return $existing !== null ? (int) ($existing['customer_id'] ?? 0) : 0;
        }

        // Honoured when already attached to the contract being edited, or
        // otherwise reachable through one of the actor's contracts.
        $attached = $existing !== null && (int) $existing['customer_id'] === $customerId;

        if (! $attached && ! $this->customers->isReachable($customerId, $scope)) {
            return false;
        }

        return $customerId;
    }

    /**
     * Field-level diff on edits, a creation event on first save.
     *
     * @param array<string, mixed>|null $existing
     * @param array<string, mixed>|null $previousCustomer
     * @param array<string, mixed>      $contract
     * @param array<string, string>     $customer
     */
    private function recordHistory(
        int $contractId,
        UserScope $scope,
        ?array $existing,
        ?array $previousCustomer,
        array $contract,
        array $customer,
    ): void {
        if ($existing === null) {
            $this->lifecycle->logCreation($contractId, $scope->actorId(), (string) $contract['status']);

            return;
        }

        $changes = [];

        if ($previousCustomer !== null) {
            $changes += ECRM_Audit::diff($previousCustomer, $customer);
        }

        // $contract now holds only the columns the request actually sent, so
        // the diff against $existing already reflects exactly what changed —
        // no different from before, except it is no longer a diff against a
        // row full of defaults the agent never asked for.
        $changes += ECRM_Audit::diff($existing, $contract);

        ECRM_Audit::log($contractId, $changes);
    }
}
