<?php

/**
 * Document rows and the bytes behind them, deleted together.
 *
 * Deleting a contract used to remove the `files` rows and leave the actual
 * documents — scanned ID cards, utility bills, signatures — on disk with
 * nothing pointing at them. Unreachable through the app, invisible to the GDPR
 * erase screen, and still perfectly readable to anyone with filesystem access.
 *
 * A row and its file are one thing. This class is the only place that knows
 * how to remove them, so no caller can remove half.
 *
 * See ContractRepository for the note on the phpcs exemptions.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Persistence;

use EnergyCRM\Domain\Document\KindVerdict;
use EnergyCRM\Domain\Document\SystemKind;

final class FileRepository
{
    private string $table;

    private string $contractsTable;

    private DocumentStorage $storage;

    public function __construct(
        string $storageDir,
        ?string $table = null,
        ?string $contractsTable = null,
    ) {
        $this->table          = $table ?? Tables::name(Tables::FILES);
        $this->contractsTable = $contractsTable ?? Tables::name(Tables::CONTRACTS);
        $this->storage        = new DocumentStorage($storageDir);
    }

    /**
     * Documents attached to a contract, for the detail view.
     *
     * @return list<array<string, mixed>>
     */
    public function forContract(int $contractId): array
    {
        global $wpdb;

        if ($contractId <= 0) {
            return [];
        }

        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, doc_kind, kind_source, kind_before, filename, mime,
                        attachment_id, path, protected, expires_at
                 FROM %i WHERE contract_id = %d ORDER BY id',
                $this->table,
                $contractId
            ),
            ARRAY_A
        );

        return $rows;
    }

    /**
     * Ιδιο σχήμα με την forContract(), για πολλές συμβάσεις μαζί -- η
     * καρτέλα πελάτη (247) θέλει "όλα τα έγγραφα του πελάτη", που είναι τα
     * έγγραφα όλων των συμβάσεών του ενωμένα, με ένδειξη από ποια ήρθε το
     * καθένα. contract_id μπαίνει στη SELECT εδώ (η forContract() δεν το
     * χρειάζεται -- ήδη ξέρει τη σύμβαση) ακριβώς για αυτή την ένδειξη.
     *
     * @param list<int> $contractIds
     *
     * @return list<array<string, mixed>>
     */
    public function forContracts(array $contractIds): array
    {
        global $wpdb;

        $ids = array_values(array_unique(array_filter(array_map('intval', $contractIds))));

        if ($ids === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, contract_id, doc_kind, kind_source, kind_before, filename, mime,
                        attachment_id, path, protected, expires_at
                 FROM {$this->table} WHERE contract_id IN ({$placeholders})
                 ORDER BY contract_id, id",
                $ids
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return $rows;
    }

    /**
     * Έγγραφα κρεμασμένα σε ένα lead — ό,τι έστειλε ο πελάτης από τον σύνδεσμο.
     *
     * Ίδιο σχήμα με την `forContract()`, άλλη στήλη. Χωριστή μέθοδος και όχι
     * παράμετρος στην πρώτη: το «ποια στήλη» δεν είναι επιλογή του καλούντος,
     * είναι δύο διαφορετικές ερωτήσεις που τυχαίνει να μοιράζονται πίνακα.
     *
     * @return list<array<string, mixed>>
     */
    public function forLead(int $leadId): array
    {
        global $wpdb;

        if ($leadId <= 0) {
            return [];
        }

        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, doc_kind, filename, mime, attachment_id, path, protected, expires_at
                 FROM %i WHERE lead_id = %d ORDER BY id',
                $this->table,
                $leadId
            ),
            ARRAY_A
        );

        return $rows;
    }

    /**
     * The newest document of a kind whose bytes are actually there.
     *
     * Newest by id, which is insertion order: the signing page inserts a fresh
     * row every time, so a re-signed contract has several and the last one is
     * the drawing that counts. A row whose file is missing is skipped rather
     * than returned — handing back a path that does not exist only moves the
     * failure somewhere less obvious.
     *
     * The same containment check as deletion: a path is only handed out if it
     * resolves inside the protected directory. The caller embeds it in a PDF,
     * so a tampered row would otherwise be a way to read a file off the disk.
     */
    /**
     * Τα αποθηκευμένα έγγραφα μιας αίτησης που έχει νόημα να διαβάσει το AI.
     *
     * Υπάρχει επειδή το /extract δεχόταν ΜΟΝΟ αρχεία που μόλις ανέβηκαν. Όταν
     * τα έγγραφα τα στέλνει ο ίδιος ο πελάτης από τον «σύνδεσμό μου», κανείς
     * δεν τα ξανανεβάζει -- και χωρίς αυτό ο πωλητής θα έβλεπε άδεια πεδία
     * πάνω από φάκελο γεμάτο χαρτιά.
     *
     * Δύο φίλτρα, και τα δύο σκόπιμα:
     *
     * - **Μόνο τα ζητούμενα είδη.** Ο εξαγωγέας είναι γραμμένος για ταυτότητα
     *   και λογαριασμό παρόχου. Το συμπληρωμένο έντυπο ή μια εξουσιοδότηση δεν
     *   προσθέτουν πεδία· προσθέτουν κόστος κλήσης και θόρυβο στο μοντέλο.
     * - **Μόνο διαδρομές μέσα στον προστατευμένο φάκελο.** Η διαδρομή έρχεται
     *   από γραμμή βάσης και ο καλών στέλνει τα bytes σε ΕΞΩΤΕΡΙΚΟ API: χωρίς
     *   τον έλεγχο, μια πειραγμένη γραμμή θα ήταν τρόπος να διαβαστεί
     *   οποιοδήποτε αρχείο του διακομιστή. Ίδιος έλεγχος με το
     *   latestPathOfKind(), για τον ίδιο ακριβώς λόγο.
     *
     * Η εμβέλεια ΔΕΝ ελέγχεται εδώ -- είναι ευθύνη του καλούντος, όπως και στο
     * forContract().
     *
     * @param list<string> $kinds
     * @param list<string> $mimes
     *
     * @return list<array{id: int, path: string, mime: string, kind: string}>
     */
    public function extractableForContract(int $contractId, array $kinds, array $mimes): array
    {
        return self::extractableFrom($this->forContract($contractId), $kinds, $mimes);
    }

    /**
     * Τα ίδια, για έγγραφα που ο ΠΕΛΑΤΗΣ έστειλε πριν υπάρξει αίτηση.
     *
     * Ο «σύνδεσμός μου» αποθηκεύει με `lead_id`, όχι `contract_id` — τα δύο
     * είναι ξεχωριστές στήλες του ίδιου πίνακα (`class-ecrm-db.php`). Μέχρι
     * σήμερα ο εξαγωγέας έφτανε στα έγγραφα μόνο μέσω αίτησης, οπότε η
     * ανάγνωση ήταν αναγκαστικά ΜΕΤΑ τη δημιουργία της. Αυτό υπάρχει για να
     * μπορεί να γίνει ΠΡΙΝ: ο πωλητής βλέπει τι βρέθηκε και μετά αποφασίζει.
     *
     * Η εμβέλεια ΔΕΝ ελέγχεται εδώ, όπως και στην αδελφή από πάνω — ο καλών
     * ρωτά πρώτα το `LeadRepository::find()` με το `UserScope` του.
     *
     * @param list<string> $kinds
     * @param list<string> $mimes
     *
     * @return list<array{id: int, path: string, mime: string, kind: string}>
     */
    public function extractableForLead(int $leadId, array $kinds, array $mimes): array
    {
        return self::extractableFrom($this->forLead($leadId), $kinds, $mimes);
    }

    /**
     * Το φίλτρο, μία φορά.
     *
     * Ήταν το σώμα της `extractableForContract()`. Βγήκε εδώ όταν
     * προστέθηκε η αδελφή της για τα leads: δεύτερη γραφή του ίδιου φίλτρου
     * θα ήταν δεύτερο σημείο να ξεχαστεί ο έλεγχος `contains()` — που είναι
     * ο έλεγχος ασφαλείας, όχι λεπτομέρεια (δες το docblock από πάνω).
     *
     * @param list<array<string, mixed>> $rows
     * @param list<string>               $kinds
     * @param list<string>               $mimes
     *
     * @return list<array{id: int, path: string, mime: string, kind: string}>
     */
    private function extractableFrom(array $rows, array $kinds, array $mimes): array
    {
        $documents = [];

        foreach ($rows as $row) {
            $path = (string) ($row['path'] ?? '');
            $mime = (string) ($row['mime'] ?? '');
            $kind = (string) ($row['doc_kind'] ?? '');

            if ($path === '' || ! in_array($kind, $kinds, true) || ! in_array($mime, $mimes, true)) {
                continue;
            }

            if (! $this->storage->contains($path) || ! is_readable($path)) {
                continue;
            }

            $documents[] = ['id' => (int) ($row['id'] ?? 0), 'path' => $path, 'mime' => $mime, 'kind' => $kind];
        }

        return $documents;
    }

    /**
     * Τα έγγραφα μιας αίτησης που δεν έχει κρίνει ποτέ κανείς.
     *
     * `kind_source IS NULL` σημαίνει ακριβώς αυτό: ούτε ανάγνωση τα κοίταξε,
     * ούτε άνθρωπος κλείδωσε την ετικέτα τους. Ο,τι έχει ήδη κριθεί μένει έξω,
     * και αυτός είναι ο λόγος που η αναγνώριση δεν ξαναπληρώνεται σε κάθε
     * άνοιγμα της καρτέλας.
     *
     * Η εμβέλεια ΔΕΝ ελέγχεται εδώ -- ευθύνη του καλούντος, όπως και στις
     * υπόλοιπες μεθόδους ανάγνωσης αυτής της κλάσης.
     *
     * @param list<string> $mimes
     *
     * @return list<array{id: int, path: string, mime: string, doc_kind: string}>
     */
    public function pendingKindReview(int $contractId, array $mimes): array
    {
        $pending = [];

        foreach ($this->forContract($contractId) as $row) {
            if (($row['kind_source'] ?? null) !== null) {
                continue;
            }

            // Ο,τι έφτιαξε το σύστημα (αίτηση, φύλλα, υπογραφές) το ξέρουμε ήδη
            // τι είναι -- δεν πληρώνουμε ανάγνωση γι' αυτό, και δεν αφήνουμε μια
            // «διόρθωση» να μετονομάσει μια υπογραφή. Δες SystemKind.
            if (SystemKind::isSystem((string) ($row['doc_kind'] ?? ''))) {
                continue;
            }

            $path = (string) ($row['path'] ?? '');
            $mime = (string) ($row['mime'] ?? '');

            if ($path === '' || ! in_array($mime, $mimes, true)) {
                continue;
            }

            // Ιδιος έλεγχος περιορισμού με το extractableFrom(): καμία διαδρομή
            // δεν διαβάζεται αν δεν είναι μέσα στον ασφαλή φάκελο.
            if (! $this->storage->contains($path) || ! is_readable($path)) {
                continue;
            }

            $pending[] = [
                'id'       => (int) $row['id'],
                'path'     => $path,
                'mime'     => $mime,
                'doc_kind' => (string) ($row['doc_kind'] ?? ''),
            ];
        }

        return $pending;
    }

    /**
     * Σημείωσε ότι ένα αρχείο διαβάστηκε -- και άλλαξε την ετικέτα αν χρειάζεται.
     *
     * Το `$correction` είναι null όταν η ανάγνωση συμφώνησε. Και τότε η γραμμή
     * γράφεται: το `kind_source` είναι που λέει «μη ξανακοιτάς», και χωρίς αυτό
     * η επόμενη επίσκεψη θα ξεκινούσε την ίδια ανάγνωση από την αρχή.
     *
     * Το `kind_before` γεμίζει ΜΟΝΟ σε πραγματική αλλαγή -- είναι η τιμή που
     * επαναφέρει η αναίρεση, και μια εγγραφή χωρίς αλλαγή δεν έχει τι να
     * επαναφέρει.
     *
     * Το `contract_id` μπαίνει στο WHERE μαζί με το id του αρχείου: ο καλών
     * έχει ήδη ελέγξει την εμβέλεια πάνω στη σύμβαση, και αυτό το κρατά αληθινό
     * και εδώ κάτω.
     */
    public function markKindReviewed(
        int $fileId,
        int $contractId,
        string $source,
        ?string $correction,
        string $declared
    ): bool {
        global $wpdb;

        if ($fileId <= 0 || $contractId <= 0) {
            return false;
        }

        $data = ['kind_source' => $source];

        if ($correction !== null) {
            $data['doc_kind']    = $correction;
            $data['kind_before'] = $declared;
        }

        return false !== $wpdb->update(
            $this->table,
            $data,
            ['id' => $fileId, 'contract_id' => $contractId]
        );
    }

    /**
     * Ανέτρεψε μια αυτόματη διόρθωση και κλείδωσε την ετικέτα.
     *
     * Επιστρέφει το είδος που επανήλθε, ή null όταν δεν υπάρχει τι να
     * αναιρεθεί -- το αρχείο δεν υπάρχει, δεν ανήκει σε αυτή τη σύμβαση, ή
     * καμία ανάγνωση δεν το άλλαξε ποτέ.
     *
     * Το `kind_source` γίνεται 'human' και το `kind_before` αδειάζει: η
     * αναίρεση είναι τελεσίδικη. Χωρίς αυτό, η επόμενη ανάγνωση θα ξανα-άλλαζε
     * ακριβώς ό,τι μόλις ανέτρεψε ο συνεργάτης.
     */
    public function revertKind(int $fileId, int $contractId): ?string
    {
        global $wpdb;

        if ($fileId <= 0 || $contractId <= 0) {
            return null;
        }

        /** @var string|null $before */
        $before = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT kind_before FROM %i WHERE id = %d AND contract_id = %d AND kind_source = %s',
                $this->table,
                $fileId,
                $contractId,
                KindVerdict::SOURCE_AI
            )
        );

        if ($before === null || $before === '') {
            return null;
        }

        $wpdb->update(
            $this->table,
            ['doc_kind' => $before, 'kind_source' => KindVerdict::SOURCE_HUMAN, 'kind_before' => null],
            ['id' => $fileId, 'contract_id' => $contractId]
        );

        return $before;
    }

    /**
     * Ο συνεργάτης λέει ο ίδιος τι είναι το έγγραφο, ρητά.
     *
     * Υπάρχει για την περίπτωση που η `revertKind()` δεν καλύπτει: ένα αρχείο
     * που ΠΟΤΕ δεν διορθώθηκε αυτόματα (η ανάγνωση δεν βρήκε κάτι σίγουρο, ή
     * βγήκε `confidence` χαμηλότερο από `KindVerdict::CONFIDENCE_REQUIRED`)
     * μένει κλειδωμένο στην αρχική, γενική ετικέτα για πάντα -- χωρίς αυτή τη
     * μέθοδο δεν υπήρχε κανένας τρόπος να το διορθώσει κανείς, ούτε χειροκίνητα.
     *
     * Ίδιο κλείδωμα με την αναίρεση: `kind_source` γίνεται 'human' και το
     * `kind_before` αδειάζει -- η επόμενη αυτόματη ανάγνωση δεν το ξαναγγίζει.
     * Η εγκυρότητα του `$kind` (ένα από τα `ECRM_Docs::kinds()`) ελέγχεται στον
     * caller, όχι εδώ -- ίδιο μοτίβο με το `markKindReviewed()`.
     */
    public function setKind(int $fileId, int $contractId, string $kind): bool
    {
        global $wpdb;

        if ($fileId <= 0 || $contractId <= 0 || $kind === '') {
            return false;
        }

        // Το είδος ενός αρχείου του συστήματος δεν αλλάζει από το χέρι: μια
        // υπογραφή που γίνεται «Ταυτότητα» παύει να βρίσκεται από το
        // latestPathOfKind() και χάνεται από κάθε έντυπο. Δες SystemKind.
        $current = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT doc_kind FROM %i WHERE id = %d AND contract_id = %d',
                $this->table,
                $fileId,
                $contractId
            )
        );

        if ($current === null || SystemKind::isSystem((string) $current)) {
            return false;
        }

        return false !== $wpdb->update(
            $this->table,
            ['doc_kind' => $kind, 'kind_source' => KindVerdict::SOURCE_HUMAN, 'kind_before' => null],
            ['id' => $fileId, 'contract_id' => $contractId]
        );
    }

    /**
     * Ο συνεργάτης σβήνει ΕΝΑ συγκεκριμένο έγγραφο (π.χ. ανέβηκε λάθος
     * αρχείο, ή διπλό) -- bytes και σειρά μαζί, ίδιο μοτίβο με
     * `deleteBytes()` που ήδη χρησιμοποιούν το `deleteKind()`/`purgeGenerated()`.
     *
     * Σκόπιμα ΔΕΝ μοιράζεται μέθοδο με το `deleteKind()`: εκείνο σβήνει με
     * βάση `doc_kind` (ολόκληρη κατηγορία, π.χ. για ξαναϋπογραφή), αυτό με
     * βάση συγκεκριμένο `id` -- διαφορετικός κίνδυνος λάθους αν
     * μπερδευτούν οι παράμετροι.
     *
     * Scoped σε contract_id, ίδιος λόγος με το setKind()/revertKind(): το
     * `$fileId` μόνο του δεν αποδεικνύει ότι ο καλών έχει δικαίωμα πάνω σε
     * αυτή τη σύμβαση -- τον έλεγχο τον κάνει ο caller (ScopeResolver) πριν
     * φτάσει εδώ, εδώ είναι το δεύτερο, φθηνό εμπόδιο.
     */
    public function deleteFile(int $fileId, int $contractId): bool
    {
        global $wpdb;

        if ($fileId <= 0 || $contractId <= 0) {
            return false;
        }

        /** @var array<string, mixed>|null $row */
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT id, path, attachment_id FROM %i WHERE id = %d AND contract_id = %d',
                $this->table,
                $fileId,
                $contractId
            ),
            ARRAY_A
        );

        if ($row === null) {
            return false;
        }

        $this->deleteBytes([$row]);

        return false !== $wpdb->delete($this->table, ['id' => $fileId, 'contract_id' => $contractId]);
    }

    /**
     * Doc_kind/kind_source/mime για ΠΟΛΛΕΣ συμβάσεις μαζί -- ίδιο σχήμα batch
     * με το signatureKindsFor(), για τον ίδιο λόγο: η οθόνη «Έγγραφα» (243)
     * δείχνει τι έχει ανέβει σε ΟΛΗ τη λίστα μιας φοράς, όχι ένα forContract()
     * ανά γραμμή.
     *
     * @param list<int> $contractIds
     *
     * @return array<int, list<array{doc_kind: string, kind_source: ?string, mime: string}>>
     */
    public function kindsForContracts(array $contractIds): array
    {
        global $wpdb;

        $ids = array_values(array_unique(array_filter(
            array_map(static fn ($id): int => (int) $id, $contractIds),
            static fn (int $id): bool => $id > 0
        )));

        if ($ids === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT contract_id, doc_kind, kind_source, mime
                 FROM %i WHERE contract_id IN ({$placeholders})
                 ORDER BY id",
                [$this->table, ...$ids]
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        $out = [];

        foreach ($rows as $row) {
            $out[(int) $row['contract_id']][] = [
                'doc_kind'    => (string) $row['doc_kind'],
                'kind_source' => $row['kind_source'] !== null ? (string) $row['kind_source'] : null,
                'mime'        => (string) $row['mime'],
            ];
        }

        return $out;
    }

    /**
     * Συμβάσεις -- ΟΛΟΥ του συστήματος, όχι μιας εμβέλειας -- που έχουν
     * τουλάχιστον ένα αρχείο που κανείς δεν έχει κρίνει ακόμα. Υπάρχει ΜΟΝΟ
     * για το background sweep (`DocumentsSweep`, 243): οι παλιές αιτήσεις που
     * κανείς δεν ξανανοίγει δεν θα περνούσαν ΠΟΤΕ από το pendingKindReview()
     * -- εκείνο θέλει μια συγκεκριμένη σύμβαση, το sweep δεν ξέρει ποιες
     * υπάρχουν παρά μόνο ρωτώντας τη βάση.
     *
     * Χωρίς εμβέλεια σκόπιμα, όπως το purgeOrphans(): το sweep δεν ανήκει σε
     * κανέναν συνεργάτη, τρέχει για όλους.
     *
     * @param list<string> $mimes
     *
     * @return list<int>
     */
    public function contractsPendingKindReview(array $mimes, int $limit): array
    {
        global $wpdb;

        if ($mimes === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($mimes), '%s'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<string> $ids */
        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT contract_id FROM {$this->table}
                 WHERE kind_source IS NULL AND mime IN ({$placeholders})
                   AND path != '' AND contract_id IS NOT NULL
                 ORDER BY contract_id ASC
                 LIMIT " . max(1, $limit),
                $mimes
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return array_map('intval', $ids);
    }

    public function latestPathOfKind(int $contractId, string $kind): ?string
    {
        global $wpdb;

        /** @var list<string> $paths */
        $paths = $wpdb->get_col(
            $wpdb->prepare(
                'SELECT path FROM %i WHERE contract_id = %d AND doc_kind = %s ORDER BY id DESC',
                $this->table,
                $contractId,
                $kind
            )
        );

        foreach ($paths as $path) {
            if ($path !== '' && $this->storage->contains($path)) {
                return $path;
            }
        }

        return null;
    }

    /**
     * Record a stored document against a contract.
     *
     * `protected` is always 1: everything written since the secure directory
     * exists lives there, and the flag is what tells serve() to stream it
     * through the signed endpoint instead of looking for a media attachment.
     *
     * @return int The new file id, or 0 when the insert failed.
     */
    public function attach(
        int $contractId,
        string $kind,
        string $filename,
        string $mime,
        string $path,
        ?string $expiresAt = null,
    ): int {
        global $wpdb;

        $wpdb->insert($this->table, [
            'contract_id'   => $contractId,
            'attachment_id' => null,
            'doc_kind'      => $kind,
            'filename'      => $filename,
            'mime'          => $mime,
            'path'          => $path,
            'protected'     => 1,
            'expires_at'    => $expiresAt,
        ]);

        return (int) $wpdb->insert_id;
    }

    /**
     * Replace the single document of a given kind on a contract.
     *
     * Used for the signature: a contract has one, and re-signing must not leave
     * the previous drawing behind — on disk as well as in the row. It did not,
     * until FileRepositoryTest caught it: the old row was deleted but its bytes
     * were not, unlike every other removal path in this class. The bytes go
     * first now, the same as purgeGenerated(), purgeForContracts() and
     * purgeOrphans().
     *
     * @return int The new file id, or 0 when the insert failed.
     */
    public function replaceKind(int $contractId, string $kind, string $filename, string $mime, string $path): int
    {
        global $wpdb;

        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, path, attachment_id FROM %i WHERE contract_id = %d AND doc_kind = %s',
                $this->table,
                $contractId,
                $kind
            ),
            ARRAY_A
        );

        $this->deleteBytes($rows);

        $wpdb->delete($this->table, ['contract_id' => $contractId, 'doc_kind' => $kind]);

        return $this->attach($contractId, $kind, $filename, $mime, $path);
    }

    /**
     * Σβήνει όλα τα έγγραφα ενός `doc_kind`, bytes και σειρές -- χωρίς
     * αντικατάσταση. Βγήκε από το `replaceKind()`: το «διάγραψε ό,τι υπάρχει
     * για αυτό το kind» ήταν ήδη το πρώτο του μισό, εδώ απλώς δεν ακολουθεί
     * `attach()`.
     *
     * Ο λόγος που υπάρχει: `SignLinkController` το χρειάζεται για να
     * επιτρέψει σε ΈΝΑΝ ρόλο του COMBO να ξαναϋπογράψει (π.χ. λάθος που
     * εντοπίστηκε αμέσως μετά) χωρίς να πειράξει την υπογραφή του άλλου
     * ρόλου -- κάτι που το ήδη υπάρχον «ξαναστείλε» (SignLinkController::create,
     * confirm_resend) κάνει σε επίπεδο ΣΥΜΒΑΣΗΣ (μηδενίζει `signed_at`), όχι
     * σε επίπεδο ρόλου. Το `SignatureState::forContract()` διαβάζει "ποιος
     * έχει υπογράψει" από την ύπαρξη αυτών ακριβώς των αρχείων, οπότε η
     * διαγραφή είναι αρκετή -- καμία νέα στήλη/σημαία.
     *
     * @return int Πόσες σειρές διαγράφηκαν.
     */
    public function deleteKind(int $contractId, string $kind): int
    {
        global $wpdb;

        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, path, attachment_id FROM %i WHERE contract_id = %d AND doc_kind = %s',
                $this->table,
                $contractId,
                $kind
            ),
            ARRAY_A
        );

        $this->deleteBytes($rows);

        return (int) $wpdb->delete($this->table, ['contract_id' => $contractId, 'doc_kind' => $kind]);
    }

    /**
     * Ποια είδη υπογραφής υπάρχουν, για ΠΟΛΛΕΣ συμβάσεις μαζί.
     *
     * Ένα ερώτημα, όσες συμβάσεις κι αν είναι. Υπάρχει ακριβώς γι' αυτό: η
     * λίστα συμβάσεων θέλει να ξέρει ποιες αιτήσεις περιμένουν ακόμα τη
     * δεύτερη υπογραφή, και η προφανής γραφή -- μια `latestPathOfKind()` ανά
     * γραμμή ανά ρόλο -- είναι 400 ερωτήματα σε λίστα 200 γραμμών. Ίδιο
     * μοτίβο batch με το `withOwnerNames()` του `ContractsReadController`,
     * για τον ίδιο λόγο.
     *
     * Επιστρέφει ΜΟΝΟ τα είδη που ζητήθηκαν και μόνο για συμβάσεις που έχουν
     * τουλάχιστον ένα: μια σύμβαση χωρίς καμία υπογραφή απλώς λείπει από τον
     * πίνακα, δεν έχει άδεια γραμμή.
     *
     * @param list<int>    $contractIds
     * @param list<string> $kinds
     *
     * @return array<int, list<string>> contract_id => τα doc_kind που υπάρχουν
     */
    public function signatureKindsFor(array $contractIds, array $kinds): array
    {
        global $wpdb;

        $ids = array_values(array_unique(array_filter(
            array_map(static fn ($id): int => (int) $id, $contractIds),
            static fn (int $id): bool => $id > 0
        )));

        if ($ids === [] || $kinds === []) {
            return [];
        }

        $idPlaceholders   = implode(',', array_fill(0, count($ids), '%d'));
        $kindPlaceholders = implode(',', array_fill(0, count($kinds), '%s'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT contract_id, doc_kind
                 FROM %i WHERE contract_id IN ({$idPlaceholders}) AND doc_kind IN ({$kindPlaceholders})",
                [$this->table, ...$ids, ...$kinds]
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        $found = [];

        foreach ($rows as $row) {
            $found[(int) $row['contract_id']][] = (string) $row['doc_kind'];
        }

        return $found;
    }

    /**
     * Remove the documents a build produced, bytes included.
     *
     * Which kinds count as generated is the caller's to say. Everything the
     * customer or the agent uploaded has its own doc_kind and must survive a
     * rebuild untouched: losing a scanned ID card because somebody pressed
     * save twice would be unrecoverable, since the original was never anywhere
     * else.
     *
     * Two details that are not decoration. The prefix goes through esc_like(),
     * so the underscore in `form_` matches an underscore rather than any
     * character. And the delete names the ids that were read, not the
     * condition they were read by — a second build starting in between would
     * otherwise have its fresh rows deleted by this one.
     *
     * @return int Number of rows removed.
     */
    public function purgeGenerated(int $contractId, string $kind, string $sheetPrefix): int
    {
        global $wpdb;

        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, path, attachment_id FROM %i
                 WHERE contract_id = %d AND (doc_kind = %s OR doc_kind LIKE %s)',
                $this->table,
                $contractId,
                $kind,
                $wpdb->esc_like($sheetPrefix) . '%'
            ),
            ARRAY_A
        );

        if ($rows === []) {
            return 0;
        }

        $this->deleteBytes($rows);

        $ids          = array_map(static fn (array $row): int => (int) $row['id'], $rows);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        $wpdb->query(
            $wpdb->prepare("DELETE FROM {$this->table} WHERE id IN ({$placeholders})", $ids)
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return count($ids);
    }

    /**
     * Remove every document belonging to the given contracts, bytes included.
     *
     * @param list<int> $contractIds
     *
     * @return int Number of rows removed.
     */
    public function purgeForContracts(array $contractIds): int
    {
        global $wpdb;

        $ids = array_values(array_unique(array_filter(array_map('intval', $contractIds))));

        if ($ids === []) {
            return 0;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, path, attachment_id FROM {$this->table} WHERE contract_id IN ({$placeholders})",
                $ids
            ),
            ARRAY_A
        );

        $this->deleteBytes($rows);

        $removed = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table} WHERE contract_id IN ({$placeholders})",
                $ids
            )
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return $removed === false ? 0 : (int) $removed;
    }

    /**
     * Remove documents whose contract no longer exists.
     *
     * These are the leftovers from every deletion made before this class
     * existed. Also worth running periodically: a crash between the row delete
     * and the unlink leaves exactly this shape of debris.
     *
     * @return int Number of rows removed.
     */
    public function purgeOrphans(): int
    {
        global $wpdb;

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            "SELECT f.id, f.path, f.attachment_id
             FROM {$this->table} f
             LEFT JOIN {$this->contractsTable} c ON c.id = f.contract_id
             WHERE f.contract_id IS NOT NULL AND c.id IS NULL",
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        if ($rows === []) {
            return 0;
        }

        $this->deleteBytes($rows);

        $ids          = array_map(static fn (array $r): int => (int) $r['id'], $rows);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        $wpdb->query(
            $wpdb->prepare("DELETE FROM {$this->table} WHERE id IN ({$placeholders})", $ids)
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return count($ids);
    }

    /**
     * Τι κρατάει ο δίσκος για αυτές τις συμβάσεις, χωρίς να σβήσει τίποτα.
     *
     * Διαβάζεται ΠΡΙΝ διαγραφεί η σύμβαση. Το foreign key `files.contract_id`
     * είναι ON DELETE CASCADE, οπότε τη στιγμή που φεύγει η σύμβαση φεύγουν και
     * οι γραμμές — και μαζί τους η μόνη ένδειξη ποια αρχεία υπήρχαν. Χωρίς αυτό
     * το στιγμιότυπο, τα σαρωμένα δελτία ταυτότητας μένουν στον δίσκο χωρίς
     * τίποτα να τα δείχνει.
     *
     * @param list<int> $contractIds
     *
     * @return list<array<string, mixed>>
     */
    public function recordsForContracts(array $contractIds): array
    {
        global $wpdb;

        $ids = array_values(array_unique(array_filter(array_map('intval', $contractIds))));

        if ($ids === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        // phpcs:disable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders
        /** @var list<array<string, mixed>> $rows */
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, path, attachment_id FROM {$this->table} WHERE contract_id IN ({$placeholders})",
                $ids
            ),
            ARRAY_A
        );
        // phpcs:enable WordPress.DB.PreparedSQL, WordPress.DB.PreparedSQLPlaceholders

        return $rows;
    }

    /**
     * Σβήνει τα bytes ενός στιγμιότυπου από recordsForContracts().
     *
     * Ασφαλές να τρέξει δύο φορές: το wp_delete_file() σε αρχείο που δεν
     * υπάρχει δεν κάνει τίποτα.
     *
     * @param list<array<string, mixed>> $records
     */
    public function forgetBytes(array $records): void
    {
        $this->deleteBytes($records);
    }

    /**
     * @param list<array<string, mixed>> $rows
     */
    private function deleteBytes(array $rows): void
    {
        foreach ($rows as $row) {
            $path = (string) ($row['path'] ?? '');

            if ($path !== '' && $this->storage->contains($path)) {
                wp_delete_file($path);
            }

            // Legacy documents that still live in the media library.
            $attachmentId = (int) ($row['attachment_id'] ?? 0);

            if ($attachmentId > 0) {
                wp_delete_attachment($attachmentId, true);
            }
        }
    }
}
