<?php

/**
 * Every migration, in the order they must run.
 *
 * Append only. Reordering or renaming an entry that has shipped will make live
 * sites either re-run a change or skip one, because the id is the only record
 * that something already happened.
 *
 * @package EnergyCRM
 */

declare(strict_types=1);

namespace EnergyCRM\Persistence\Schema;

use EnergyCRM\Persistence\Schema\Migrations\AddContractAddresses;
use EnergyCRM\Persistence\Schema\Migrations\AddContractListIndexes;
use EnergyCRM\Persistence\Schema\Migrations\AddCustomerAfmIndex;
use EnergyCRM\Persistence\Schema\Migrations\AddComboEnergyContactColumns;
use EnergyCRM\Persistence\Schema\Migrations\AddComboMobileContactColumns;
use EnergyCRM\Persistence\Schema\Migrations\AddCustomerContactPhoneColumn;
use EnergyCRM\Persistence\Schema\Migrations\CreateCustomerEventsTable;
use EnergyCRM\Persistence\Schema\Migrations\CreateCustomerNotesTable;
use EnergyCRM\Persistence\Schema\Migrations\CreateRequestKeysTable;
use EnergyCRM\Persistence\Schema\Migrations\AddCustomerPhoneIndex;
use EnergyCRM\Persistence\Schema\Migrations\AddForeignKeys;
use EnergyCRM\Persistence\Schema\Migrations\AddGuaranteeRuleForeignKeys;
use EnergyCRM\Persistence\Schema\Migrations\AddIntakeColumns;
use EnergyCRM\Persistence\Schema\Migrations\AddPayoutAmountColumn;
use EnergyCRM\Persistence\Schema\Migrations\AddProgramCodeColumn;
use EnergyCRM\Persistence\Schema\Migrations\AddProviderRefColumn;
use EnergyCRM\Persistence\Schema\Migrations\AddProviderStatusMapColumn;
use EnergyCRM\Persistence\Schema\Migrations\AddSupplyNumberIndex;
use EnergyCRM\Persistence\Schema\Migrations\AddEventStatusIndex;
use EnergyCRM\Persistence\Schema\Migrations\AddFileExpiryColumn;
use EnergyCRM\Persistence\Schema\Migrations\AddFileKindSourceColumns;
use EnergyCRM\Persistence\Schema\Migrations\AddTrackKeyColumn;
use EnergyCRM\Persistence\Schema\Migrations\DropIbanFromExtras;
use EnergyCRM\Persistence\Schema\Migrations\EnsureInnoDb;
use EnergyCRM\Persistence\Schema\Migrations\EnsureLegacyColumns;
use EnergyCRM\Persistence\Schema\Migrations\FixProviderEnergyTypes;
use EnergyCRM\Persistence\Schema\Migrations\MigrateStatusVocabulary;
use EnergyCRM\Persistence\Schema\Migrations\MigrateStatusesToPaperLists;
use EnergyCRM\Persistence\Schema\Migrations\SeedProtergiaCatalogue2026;
use EnergyCRM\Persistence\Schema\Migrations\SeedProtergiaPicasso;
use EnergyCRM\Persistence\Schema\Migrations\MoveMeterAddressOutOfExtras;
use EnergyCRM\Persistence\Schema\Migrations\SeedMobilePrograms;
use EnergyCRM\Persistence\Schema\Migrations\SeedOrizonPlans;
use EnergyCRM\Persistence\Schema\Migrations\SeedProtergiaBizPlans;
use EnergyCRM\Persistence\Schema\Migrations\SeedProtergiaGasPlans;
use EnergyCRM\Persistence\Schema\Migrations\SeedProtergiaHomePlans;
use EnergyCRM\Persistence\Schema\Migrations\SeedProviderGrants;
use EnergyCRM\Persistence\Schema\Migrations\DedupeProgramsByCode;
use EnergyCRM\Persistence\Schema\Migrations\SeedVoltonPlans;
use EnergyCRM\Persistence\Schema\Migrations\PurgeOrphanFiles;
use EnergyCRM\Persistence\Schema\Migrations\RetargetContractListIndexToUpdatedAt;
use EnergyCRM\Persistence\Schema\Migrations\WidenEncryptedColumns;
use EnergyCRM\Persistence\Schema\Migrations\WidenCustomerPhoneColumn;

final class MigrationList
{
    private function __construct()
    {
    }

    /** @return list<Migration> */
    public static function all(): array
    {
        return [
            new EnsureLegacyColumns(),
            new PurgeOrphanFiles(),
            new EnsureInnoDb(),
            new AddForeignKeys(),
            new AddContractAddresses(),
            new MoveMeterAddressOutOfExtras(),
            new AddContractListIndexes(),
            new FixProviderEnergyTypes(),
            new SeedMobilePrograms(),
            new AddCustomerAfmIndex(),
            new WidenEncryptedColumns(),
            new AddProgramCodeColumn(),
            new SeedOrizonPlans(),
            new SeedProtergiaHomePlans(),
            new DropIbanFromExtras(),
            new AddPayoutAmountColumn(),
            new AddTrackKeyColumn(),
            new AddEventStatusIndex(),
            new WidenCustomerPhoneColumn(),
            new AddCustomerPhoneIndex(),
            new AddIntakeColumns(),
            new AddProviderStatusMapColumn(),
            new AddSupplyNumberIndex(),
            new AddProviderRefColumn(),
            new RetargetContractListIndexToUpdatedAt(),
            new AddFileExpiryColumn(),
            new AddGuaranteeRuleForeignKeys(),
            new SeedVoltonPlans(),
            new DedupeProgramsByCode(),
            new AddComboEnergyContactColumns(),
            new AddFileKindSourceColumns(),
            new AddComboMobileContactColumns(),
            new AddCustomerContactPhoneColumn(),
            new CreateCustomerNotesTable(),
            new CreateCustomerEventsTable(),
            new MigrateStatusVocabulary(),
            new CreateRequestKeysTable(),
            new SeedProviderGrants(),
            new SeedProtergiaBizPlans(),
            new SeedProtergiaGasPlans(),
            new MigrateStatusesToPaperLists(),
            new SeedProtergiaCatalogue2026(),
            new SeedProtergiaPicasso(),
        ];
    }
}
