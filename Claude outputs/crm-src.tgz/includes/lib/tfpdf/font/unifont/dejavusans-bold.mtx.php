<?php
$name='DejaVuSans-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262148,
  'FontBBox' => '[-1069 -415 1975 1174]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='includes/lib/tfpdf/font/unifont/DejaVuSans-Bold.ttf';
$originalsize=704128;
$fontkey='dejavuB';
?>