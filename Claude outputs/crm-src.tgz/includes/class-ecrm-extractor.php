<?php
/**
 * Document extractor — the AI core.
 *
 * Takes one or more uploaded documents (ταυτότητα + λογαριασμός παρόχου),
 * sends them to the Claude Messages API as image/document blocks, and asks
 * for a strict JSON object of customer + supply fields to pre-fill the form.
 *
 * The model is told to return ONLY JSON (no prose, no markdown fences), and
 * we parse defensively. Anything it can't read is returned as null so the
 * agent fills it in manually.
 *
 * @package EnergyCRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ECRM_Extractor {

	const API_URL = 'https://api.anthropic.com/v1/messages';
	const API_VER = '2023-06-01';

	/**
	 * Default model — overridable via settings.
	 *
	 * Sonnet over Opus deliberately: reading an ID card and a utility bill into
	 * a fixed set of fields is well within its vision capability, at a fraction
	 * of the cost per application. On this workload the cost difference lands
	 * straight on the margin per contract.
	 */
	const DEFAULT_MODEL = 'claude-sonnet-5';

	/**
	 * Μοντέλο για το chat του AlfrAId και της Βάσης Γνώσης.
	 *
	 * Απαντά σε σύντομες ερωτήσεις πάνω σε κείμενο που του δίνουμε, χωρίς
	 * όραση και χωρίς JSON που πρέπει να βγει σωστό στο γράμμα. Το Haiku
	 * αρκεί και κοστίζει πολύ λιγότερο. Η εξαγωγή εγγράφων μένει στο
	 * DEFAULT_MODEL, γιατί εκεί η ακρίβεια πάνω στα στοιχεία μετράει.
	 */
	/** Μεγάλη πλευρά εικόνας (px) πάνω από την οποία μικραίνει πριν σταλεί. */
	const MAX_IMAGE_EDGE = 1568;

	const DEFAULT_CHAT_MODEL = 'claude-haiku-4-5';

	/** Fields we expect back. Keep in sync with the customers table + form. */
	public static function fields(): array {
		return [
			'customer_type', 'afm', 'doy', 'first_name', 'last_name', 'father_name',
			'company_name', 'adt', 'birth_date', 'region', 'city', 'street',
			'street_no', 'postal_code', 'phone', 'mobile', 'email',
			'supply_number', 'meter_number', 'invoice_code',
			// Εταιρικά στοιχεία από ΓΕΜΗ/καταστατικό/βεβαίωση έναρξης.
			// Ζουν στο extra_json, όπως και τα της κινητής.
			'kad', 'gemi',
			// Κινητή τηλεφωνία. Δεν είναι στήλες -- ζουν στο extra_json της
			// σύμβασης (data-extra="1" στη φόρμα). Ο εξαγωγέας δεν ξέρει πού
			// καταλήγουν, και σωστά: δουλειά του είναι να ΔΙΑΒΑΣΕΙ.
			'sim_number', 'mobile_msisdn',
		];
	}

	/**
	 * Run extraction over a set of files.
	 *
	 * @param array $files Each: ['path'=>abs path, 'mime'=>mime, 'kind'=>id_card|provider_bill|other]
	 * @return array{ok:bool, data?:array, raw?:string, error?:string}
	 */
	public static function extract( array $files ): array {
		$api_key = self::api_key();
		if ( empty( $api_key ) ) {
			return [ 'ok' => false, 'error' => 'Δεν έχει οριστεί Claude API key. Ρυθμίσεις → Energy CRM.' ];
		}
		if ( empty( $files ) ) {
			return [ 'ok' => false, 'error' => 'Δεν δόθηκαν αρχεία.' ];
		}

		$content = [];

		// Lead with the instruction text, then attach each document.
		$content[] = [ 'type' => 'text', 'text' => self::prompt() ];

		foreach ( $files as $f ) {
			$block = self::file_to_block( $f );
			if ( $block ) {
				// Label each doc so the model knows which is which.
				$labels = [
					'id_card'       => 'ΕΓΓΡΑΦΟ: Ταυτότητα/Διαβατήριο',
					'provider_bill' => 'ΕΓΓΡΑΦΟ: Λογαριασμός παρόχου',
					'telecom_bill'  => 'ΕΓΓΡΑΦΟ: Λογαριασμός τηλεφωνίας',
					'sim_card'      => 'ΕΓΓΡΑΦΟ: Κάρτα SIM (φωτογραφία της πλαστικής βάσης)',
				];
				// Για τα υπόλοιπα είδη, η ετικέτα του καταλόγου («Ε9», «ΓΕΜΗ /
				// Καταστατικό» κ.λπ.) -- βοηθά το μοντέλο να ξέρει τι κοιτάει.
				$label  = $labels[ $f['kind'] ] ?? ( 'ΕΓΓΡΑΦΟ: ' . ECRM_Docs::label( (string) $f['kind'] ) );
				$content[] = [ 'type' => 'text', 'text' => $label ];
				$content[] = $block;
			}
		}

		if ( count( $content ) <= 1 ) {
			return [ 'ok' => false, 'error' => 'Τα αρχεία δεν διαβάστηκαν (μη υποστηριζόμενος τύπος).' ];
		}

		$body = [
			'model'      => self::model(),
			// Ήταν 1500 και δεν έφτανε. Δοκιμή στο live 29/09 με λογαριασμό
			// Vodafone: η απάντηση κόπηκε στο «"postal_» και απορρίφθηκε ως
			// άκυρο JSON. Τα ελληνικά κοστίζουν περισσότερα tokens ανά γράμμα, και
			// ό,τι σκεφτεί το μοντέλο πριν απαντήσει μετράει στο ίδιο όριο.
			// Πληρώνεται μόνο ό,τι χρησιμοποιηθεί, οπότε το περιθώριο δεν κοστίζει.
			'max_tokens' => 4096,
			'messages'   => [
				[ 'role' => 'user', 'content' => $content ],
			],
		];

		$resp = wp_remote_post( self::API_URL, [
			// Measured at ~7.5s for two scaled-down documents; ten would still
			// leave room for the largest applications. Thirty is the ceiling
			// for a call that has gone wrong, and it matters because a stuck
			// call holds one of the extraction slots for its whole length —
			// at sixty it held one for a minute over a request that was never
			// going to answer.
			'timeout' => 30,
			'headers' => [
				'content-type'      => 'application/json',
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VER,
			],
			'body'    => wp_json_encode( $body ),
		] );

		if ( is_wp_error( $resp ) ) {
			return [ 'ok' => false, 'error' => 'Σφάλμα σύνδεσης: ' . $resp->get_error_message() ];
		}

		$code = wp_remote_retrieve_response_code( $resp );
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( $code !== 200 ) {
			$msg = $json['error']['message'] ?? ( 'HTTP ' . $code );
			return [ 'ok' => false, 'error' => 'Claude API: ' . $msg ];
		}

		// Concatenate any text blocks from the assistant response.
		$text = '';
		foreach ( ( $json['content'] ?? [] ) as $blk ) {
			if ( ( $blk['type'] ?? '' ) === 'text' ) {
				$text .= $blk['text'];
			}
		}

		// Κομμένη απάντηση: να λέει ότι κόπηκε, όχι «άκυρο JSON» που στέλνει
		// όποιον ψάχνει να κοιτάξει το prompt αντί για το όριο.
		if ( 'max_tokens' === ( $json['stop_reason'] ?? '' ) ) {
			return [ 'ok' => false, 'error' => 'Η απάντηση του AI κόπηκε στο όριο max_tokens.', 'raw' => $text ];
		}

		$data = self::parse_json( $text );
		if ( null === $data ) {
			return [ 'ok' => false, 'error' => 'Δεν επιστράφηκε έγκυρο JSON.', 'raw' => $text ];
		}

		return [ 'ok' => true, 'data' => self::normalize( $data ), 'raw' => $text ];
	}

	/**
	 * Τι ΕΙΝΑΙ το κάθε αρχείο -- όχι τι γράφει μέσα.
	 *
	 * Ξεχωριστή μέθοδος από την extract(), όχι επιπλέον κλειδί στο fields():
	 * ο ExtractionController κάνει loop πάνω στο fields() για να γράψει σε
	 * στήλες πελάτη και σύμβασης, οπότε ένα «τι είδους έγγραφο» εκεί μέσα θα
	 * προσπαθούσε να γραφτεί ως πεδίο του πελάτη. Δύο ερωτήματα, δύο μέθοδοι.
	 *
	 * Το prompt είναι σκόπιμα μικρό και η απάντηση επίσης: δεν ζητά τιμές
	 * πεδίων, μόνο κατηγορία και βεβαιότητα. Μια αίτηση με δέκα έγγραφα
	 * κοστίζει κλάσμα αυτού που κοστίζει μία πλήρης εξαγωγή.
	 *
	 * Η βεβαιότητα ζητείται ρητά επειδή ΧΩΡΙΣ αυτήν το μοντέλο θα έδινε πάντα
	 * μια απάντηση, και μια αβέβαιη απάντηση εδώ αλλάζει ετικέτα σε φάκελο με
	 * δικαιολογητικά. Ποιο κατώφλι μετράει το αποφασίζει το
	 * Domain\Document\KindVerdict, όχι αυτή η μέθοδος.
	 *
	 * @param array $files Each: ['path'=>abs path, 'mime'=>mime]
	 * @return array{ok:bool, kinds?:array<int,array{kind:?string,confidence:?string}>, raw?:string, error?:string}
	 */
	public static function classify( array $files ): array {
		$api_key = self::api_key();
		if ( empty( $api_key ) ) {
			return [ 'ok' => false, 'error' => 'Δεν έχει οριστεί Claude API key.' ];
		}
		if ( empty( $files ) ) {
			return [ 'ok' => false, 'error' => 'Δεν δόθηκαν αρχεία.' ];
		}

		$content = [ [ 'type' => 'text', 'text' => self::classify_prompt() ] ];
		$slots   = [];

		foreach ( array_values( $files ) as $i => $f ) {
			$block = self::file_to_block( $f );
			if ( ! $block ) {
				continue;
			}
			// Αριθμημένη ετικέτα: η σειρά της απάντησης δεν αφήνεται στην τύχη,
			// γιατί μια μετατοπισμένη σειρά θα έδινε σε κάθε αρχείο την ετικέτα
			// του διπλανού του.
			$content[] = [ 'type' => 'text', 'text' => 'ΑΡΧΕΙΟ ' . ( count( $slots ) + 1 ) ];
			$content[] = $block;
			$slots[]   = $i;
		}

		if ( ! $slots ) {
			return [ 'ok' => false, 'error' => 'Τα αρχεία δεν διαβάστηκαν (μη υποστηριζόμενος τύπος).' ];
		}

		$resp = wp_remote_post( self::API_URL, [
			'timeout' => 30,
			'headers' => [
				'content-type'      => 'application/json',
				'x-api-key'         => $api_key,
				'anthropic-version' => self::API_VER,
			],
			'body'    => wp_json_encode( [
				'model'      => self::model(),
				'max_tokens' => 400,
				'messages'   => [ [ 'role' => 'user', 'content' => $content ] ],
			] ),
		] );

		if ( is_wp_error( $resp ) ) {
			return [ 'ok' => false, 'error' => 'Σφάλμα σύνδεσης: ' . $resp->get_error_message() ];
		}

		$code = wp_remote_retrieve_response_code( $resp );
		$json = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( 200 !== $code ) {
			$msg = $json['error']['message'] ?? ( 'HTTP ' . $code );
			return [ 'ok' => false, 'error' => 'Claude API: ' . $msg ];
		}

		$text = '';
		foreach ( ( $json['content'] ?? [] ) as $blk ) {
			if ( 'text' === ( $blk['type'] ?? '' ) ) {
				$text .= $blk['text'];
			}
		}

		$data = self::parse_json( $text );
		if ( null === $data ) {
			return [ 'ok' => false, 'error' => 'Δεν επιστράφηκε έγκυρο JSON.', 'raw' => $text ];
		}

		return [ 'ok' => true, 'kinds' => self::classify_slots( $data, $slots ), 'raw' => $text ];
	}

	/**
	 * Η απάντηση του μοντέλου, γυρισμένη στους δείκτες των ΑΡΧΙΚΩΝ αρχείων.
	 *
	 * Το μοντέλο μετράει τα αρχεία που του δόθηκαν (1..ν)· ο καλών μετράει τα
	 * αρχεία που έστειλε -- και τα δύο σύνολα διαφέρουν μόλις ένα αρχείο δεν
	 * διαβαστεί. Το $slots κρατά την αντιστοιχία, ώστε μια απάντηση να μη
	 * χρεωθεί ποτέ σε λάθος έγγραφο.
	 *
	 * @param array $data  Το JSON του μοντέλου.
	 * @param array $slots Θέση στο prompt => δείκτης στα αρχεία του καλούντος.
	 * @return array<int,array{kind:?string,confidence:?string}>
	 */
	private static function classify_slots( array $data, array $slots ): array {
		$rows = $data['files'] ?? $data;
		$out  = [];

		if ( ! is_array( $rows ) ) {
			return $out;
		}

		foreach ( array_values( $rows ) as $pos => $row ) {
			if ( ! is_array( $row ) || ! isset( $slots[ $pos ] ) ) {
				continue;
			}

			$kind = $row['kind'] ?? null;
			$conf = $row['confidence'] ?? null;

			$out[ $slots[ $pos ] ] = [
				'kind'       => is_string( $kind ) ? sanitize_key( $kind ) : null,
				'confidence' => is_string( $conf ) ? sanitize_key( $conf ) : null,
			];
		}

		return $out;
	}

	/** Το prompt της αναγνώρισης -- κατηγορία και βεβαιότητα, τίποτα άλλο. */
	private static function classify_prompt(): string {
		return <<<PROMPT
Θα σου δοθούν φωτογραφίες/PDF εγγράφων από ελληνικό φάκελο συμβολαίου ενέργειας ή κινητής, αριθμημένα ΑΡΧΕΙΟ 1, ΑΡΧΕΙΟ 2 κ.ο.κ. Πες μου ΜΟΝΟ τι είδος έγγραφο είναι το καθένα.

Επέστρεψε ΜΟΝΟ ένα JSON object, χωρίς markdown και χωρίς κείμενο πριν ή μετά, με αυτή ακριβώς τη μορφή:
{"files":[{"kind":"id_card","confidence":"high"},{"kind":"provider_bill","confidence":"low"}]}

Ενα αντικείμενο ΑΝΑ αρχείο, με την ΙΔΙΑ σειρά που σου δόθηκαν.

Επιτρεπτές τιμές του kind:
- "id_card" — ελληνική αστυνομική ταυτότητα ή διαβατήριο (μπρος ή πίσω όψη).
- "provider_bill" — λογαριασμός ρεύματος ή αερίου από πάροχο (ΔΕΗ, Protergia, Ήρων, ΦΥΣΙΚΟ ΑΕΡΙΟ κ.λπ.), με αριθμό παροχής ή κατανάλωση.
- "telecom_bill" — λογαριασμός κινητής, σταθερής ή internet (Vodafone, Cosmote, Nova κ.λπ.), χωρίς αριθμό παροχής ρεύματος/αερίου.
- "sim_card" — φωτογραφία της πλαστικής βάσης κάρτας SIM, με ICCID/barcode.
- "other" — ΟΤΙΔΗΠΟΤΕ άλλο: εξουσιοδότηση, Ε9, πιστοποιητικό, συμπληρωμένο έντυπο παρόχου, άσχετη φωτογραφία.

Επιτρεπτές τιμές του confidence: "high", "medium", "low".
Δώσε "high" ΜΟΝΟ αν αναγνωρίζεις καθαρά το έγγραφο από τη μορφή και το περιεχόμενό του. Αν το χαρτί είναι θολό, κομμένο, μισοφωτισμένο ή απλά δεν είσαι σίγουρος, δώσε "low" ή "medium" — μια λάθος βέβαιη απάντηση αλλάζει την κατάταξη ενός δικαιολογητικού και μπλοκάρει ή ξεμπλοκάρει αίτηση.
PROMPT;
	}

	// ---------------------------------------------------------------------
	// Prompt
	// ---------------------------------------------------------------------
	private static function prompt(): string {
		$keys = implode( ', ', self::fields() );
		return <<<PROMPT
Είσαι βοηθός καταχώρισης για ελληνικό CRM ενεργειακών συμβολαίων και συμβολαίων κινητής. Θα σου δοθούν φωτογραφίες/PDF εγγράφων: ταυτότητα ή διαβατήριο, λογαριασμοί ρεύματος/αερίου/τηλεφωνίας, κάρτα SIM, αλλά και οποιοδήποτε άλλο έγγραφο του πελάτη — Ε9, ΓΕΜΗ ή καταστατικό, βεβαίωση έναρξης εργασιών, εξουσιοδότηση, αποδεικτικό κατοικίας, πιστοποιητικά. Διάβασε ΟΛΑ τα έγγραφα και εξήγαγε ό,τι στοιχείο του πελάτη βρίσκεις σε οποιοδήποτε από αυτά.

Επέστρεψε ΜΟΝΟ ένα JSON object — χωρίς markdown, χωρίς σχόλια, χωρίς κείμενο πριν ή μετά. Τα κλειδιά πρέπει να είναι ακριβώς αυτά: {$keys}.

Κανόνες:
- customer_type: ένα από "individual" (ιδιώτης), "sole_prop" (ατομική επιχείρηση), "company" (εταιρεία). Αν αμφιβάλλεις, "individual".
- birth_date: μορφή YYYY-MM-DD. Αν δεν υπάρχει, null.
- afm: 9 ψηφία ΑΦΜ. supply_number: ο αριθμός παροχής/ΗΚΑΣΠ από τον λογαριασμό.
- Διεύθυνση: σπάσε σε street (οδός), street_no (αριθμός), city (πόλη), region (νομός), postal_code (ΤΚ).
- sim_number: το ICCID της κάρτας SIM — 19 ή 20 ψηφία, τυπωμένο στην πλαστική βάση, συνήθως δίπλα σε barcode και ξεκινά με 89. Επίστρεψέ το ΜΟΝΟ ως ψηφία, χωρίς κενά ή παύλες. Αν διαβάζονται λιγότερα από 19 ψηφία, βάλε null αντί για μισό αριθμό: ένα κομμένο ICCID αποτυγχάνει σιωπηλά στην ενεργοποίηση.
- mobile_msisdn: ο αριθμός κινητού που τυπώνεται στη βάση της SIM, αν υπάρχει. Δεν είναι το ίδιο με το mobile (το προσωπικό τηλέφωνο του πελάτη από την ταυτότητα ή τον λογαριασμό).
- Ο λογαριασμός μπορεί να είναι ρεύματος, αερίου ή τηλεφωνίας (Vodafone, Cosmote, Nova κ.λπ.). Από όλους διαβάζεις τα στοιχεία του πελάτη· supply_number και meter_number υπάρχουν μόνο σε ρεύμα/αέριο — σε λογαριασμό τηλεφωνίας είναι null.
- ΑΓΝΟΗΣΕ τα στοιχεία του ίδιου του παρόχου: η κεφαλίδα γράφει την επωνυμία, τον ΑΦΜ και τη διεύθυνση της εταιρείας (π.χ. «VODAFONE-ΠΑΝΑΦΟΝ … Α.Φ.Μ.: 094349850»). Αυτά ΔΕΝ είναι του πελάτη. Ο πελάτης είναι στο «Στοιχεία Συνδρομητή/Πελάτη».
- Οι ελληνικοί λογαριασμοί γράφουν το όνομα ως ΕΠΩΝΥΜΟ ΟΝΟΜΑ ΠΑΤΡΩΝΥΜΟ. «Ον/μο/Επωνυμία: ΠΑΠΑΔΟΠΟΥΛΟΣ ΓΕΩΡΓΙΟΣ ΙΩΑΝΝΗΣ» σημαίνει last_name ΠΑΠΑΔΟΠΟΥΛΟΣ, first_name ΓΕΩΡΓΙΟΣ, father_name ΙΩΑΝΝΗΣ.
- «Α.Φ.Μ./Δ.Ο.Υ.: 123456789 / ΙΩΝΙΑΣ ΘΕΣΣΑΛΟΝΙΚΗΣ» σημαίνει afm 123456789 και doy ΙΩΝΙΑΣ ΘΕΣΣΑΛΟΝΙΚΗΣ.
- Διεύθυνση: πάρε τη διεύθυνση του πελάτη (Έδρα, Κατοικία ή Διεύθυνση παροχής), ΟΧΙ τη διεύθυνση αποστολής που τυπώνεται για τον φάκελο, αν διαφέρουν.
- customer_type: φυσικό πρόσωπο με Επάγγελμα/δραστηριότητα στον λογαριασμό → "sole_prop". Επωνυμία με Α.Ε., Ε.Π.Ε., Ι.Κ.Ε., Ο.Ε., Ε.Ε. → "company" (και τότε company_name).
- Σε λογαριασμό κινητής οι αριθμοί των συνδέσεων ΔΕΝ είναι το τηλέφωνο επικοινωνίας του πελάτη· άφησε mobile null εκτός αν γράφεται ρητά ως τηλέφωνο επικοινωνίας.
- company_name, kad (Κ.Α.Δ. κύριας δραστηριότητας), gemi (αριθμός Γ.Ε.ΜΗ.): από ΓΕΜΗ, καταστατικό ή βεβαίωση έναρξης. Σε εταιρεία, first_name/last_name είναι ο νόμιμος εκπρόσωπος.
- Αν δύο έγγραφα δίνουν διαφορετική τιμή για το ίδιο πεδίο, προτίμησε την ταυτότητα για τα προσωπικά στοιχεία και τον λογαριασμό για τη διεύθυνση και τον αριθμό παροχής.
- Σε εξουσιοδότηση, τα στοιχεία είναι του ΠΕΛΑΤΗ (αυτού που εξουσιοδοτεί), όχι του εξουσιοδοτούμενου.
- Για ό,τι ΔΕΝ διαβάζεται καθαρά, βάλε null. ΜΗΝ μαντεύεις και ΜΗΝ εφευρίσκεις τιμές.
- Κράτα ελληνικούς χαρακτήρες ως έχουν (μην τους κάνεις transliteration).

Παράδειγμα σχήματος εξόδου:
{"customer_type":"individual","afm":"123456789","doy":"Δ ΑΘΗΝΩΝ","first_name":"ΓΕΩΡΓΙΟΣ","last_name":"ΠΑΠΑΔΟΠΟΥΛΟΣ","father_name":"ΙΩΑΝΝΗΣ","company_name":null,"adt":"ΑΒ123456","birth_date":"1985-04-12","region":"ΑΤΤΙΚΗΣ","city":"ΑΘΗΝΑ","street":"ΕΡΜΟΥ","street_no":"15","postal_code":"10563","phone":null,"mobile":"6900000000","email":null,"supply_number":"0199999990001","meter_number":null,"invoice_code":null,"sim_number":null,"mobile_msisdn":null,"kad":null,"gemi":null}
PROMPT;
	}

	// ---------------------------------------------------------------------
	// File -> Claude content block
	// ---------------------------------------------------------------------
	private static function file_to_block( array $f ): ?array {
		$path = $f['path'] ?? '';
		$mime = $f['mime'] ?? '';
		if ( ! $path || ! file_exists( $path ) ) {
			return null;
		}

		$raw = file_get_contents( $path );
		if ( false === $raw ) {
			return null;
		}

		// Φωτογραφία κινητού: 4000+ px που το API θα μίκραινε ούτως ή άλλως.
		// Μικραίνει εδώ, ώστε να μη ταξιδεύουν 5 MB base64 για κάθε έγγραφο.
		if ( in_array( $mime, [ 'image/jpeg', 'image/png', 'image/webp' ], true ) ) {
			[ $raw, $mime ] = self::shrink_image( $raw, $mime );
		}
		$b64 = base64_encode( $raw );

		// PDFs go as a "document" block; images as "image".
		if ( $mime === 'application/pdf' || str_ends_with( strtolower( $path ), '.pdf' ) ) {
			return [
				'type'   => 'document',
				'source' => [ 'type' => 'base64', 'media_type' => 'application/pdf', 'data' => $b64 ],
			];
		}

		$image_mimes = [ 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ];
		if ( in_array( $mime, $image_mimes, true ) ) {
			return [
				'type'   => 'image',
				'source' => [ 'type' => 'base64', 'media_type' => $mime, 'data' => $b64 ],
			];
		}

		return null;
	}

	/**
	 * Μικραίνει εικόνα που η μεγάλη της πλευρά ξεπερνά το MAX_IMAGE_EDGE.
	 *
	 * Το API μικραίνει μόνο του ό,τι ξεπερνά ~1568 px, άρα ούτε ευκρίνεια
	 * χάνεται ούτε tokens γλιτώνουν· κερδίζουμε μεταφορά και χρόνο. Σε ό,τι
	 * δεν είναι σίγουρο (χωρίς GD, αποτυχία, εικόνα που δεν μεγαλώνει ή
	 * δεν μικραίνει) επιστρέφεται το αρχικό όπως ήταν.
	 *
	 * @return array{0:string,1:string} [bytes, mime]
	 */
	public static function shrink_image( string $raw, string $mime ): array {
		if ( ! function_exists( 'imagecreatefromstring' ) ) {
			return [ $raw, $mime ];
		}

		$size = @getimagesizefromstring( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! is_array( $size ) || max( $size[0], $size[1] ) <= self::MAX_IMAGE_EDGE ) {
			return [ $raw, $mime ];
		}

		$src = @imagecreatefromstring( $raw ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $src ) {
			return [ $raw, $mime ];
		}

		// Η επανακωδικοποίηση πετάει το EXIF, άρα η στροφή της φωτογραφίας
		// του κινητού πρέπει να εφαρμοστεί εδώ, αλλιώς το έγγραφο φτάνει πλάγιο.
		if ( 'image/jpeg' === $mime && function_exists( 'exif_read_data' ) ) {
			$exif  = @exif_read_data( 'data://image/jpeg;base64,' . base64_encode( $raw ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$angle = [ 3 => 180, 6 => -90, 8 => 90 ][ (int) ( $exif['Orientation'] ?? 1 ) ] ?? 0;
			if ( 0 !== $angle ) {
				$rotated = imagerotate( $src, $angle, 0 );
				if ( $rotated ) {
					$src = $rotated;
				}
			}
		}

		$w     = imagesx( $src );
		$h     = imagesy( $src );
		$ratio = self::MAX_IMAGE_EDGE / max( $w, $h );
		$dst   = imagecreatetruecolor( max( 1, (int) round( $w * $ratio ) ), max( 1, (int) round( $h * $ratio ) ) );
		if ( ! $dst ) {
			return [ $raw, $mime ];
		}

		// Λευκό φόντο: το διάφανο PNG/WebP θα έβγαινε μαύρο σε JPEG.
		imagefill( $dst, 0, 0, (int) imagecolorallocate( $dst, 255, 255, 255 ) );
		imagecopyresampled( $dst, $src, 0, 0, 0, 0, imagesx( $dst ), imagesy( $dst ), $w, $h );

		ob_start();
		$ok  = imagejpeg( $dst, null, 85 );
		$out = (string) ob_get_clean();

		// Να μην επιστρέψουμε κάτι μεγαλύτερο από αυτό που πήραμε.
		if ( ! $ok || '' === $out || strlen( $out ) >= strlen( $raw ) ) {
			return [ $raw, $mime ];
		}

		return [ $out, 'image/jpeg' ];
	}

	// ---------------------------------------------------------------------
	// Parsing helpers
	// ---------------------------------------------------------------------
	private static function parse_json( string $text ): ?array {
		$text = trim( $text );
		// Strip accidental ```json fences if the model adds them.
		$text = preg_replace( '/^```(?:json)?|```$/m', '', $text );
		$text = trim( $text );

		$data = json_decode( $text, true );
		if ( is_array( $data ) ) {
			return $data;
		}

		// Fallback: grab the first {...} block.
		if ( preg_match( '/\{.*\}/s', $text, $m ) ) {
			$data = json_decode( $m[0], true );
			if ( is_array( $data ) ) {
				return $data;
			}
		}
		return null;
	}

	/** Keep only known fields, coerce empties to null, sanitize. */
	private static function normalize( array $data ): array {
		$out = [];
		foreach ( self::fields() as $key ) {
			$val = $data[ $key ] ?? null;
			if ( is_string( $val ) ) {
				$val = trim( $val );
				if ( $val === '' || strtolower( $val ) === 'null' ) {
					$val = null;
				}
			}
			$out[ $key ] = is_scalar( $val ) ? sanitize_text_field( (string) $val ) : null;
		}
		return $out;
	}

	// ---------------------------------------------------------------------
	// Settings accessors
	// ---------------------------------------------------------------------
	public static function api_key(): string {
		return \EnergyCRM\Services::secrets()->get( 'claude_api_key' );
	}

	public static function chat_model(): string {
		$m = (string) get_option( ECRM_PREFIX . 'claude_chat_model', '' );
		return $m !== '' ? $m : self::DEFAULT_CHAT_MODEL;
	}

	public static function model(): string {
		$m = (string) get_option( ECRM_PREFIX . 'claude_model', '' );
		return $m !== '' ? $m : self::DEFAULT_MODEL;
	}
}
